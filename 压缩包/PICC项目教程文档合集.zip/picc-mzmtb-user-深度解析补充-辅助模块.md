# PICC人保健康权限管理系统 - 深度解析补充篇：辅助模块与BaseServiceImpl

> 🎯 本章补充解析项目中的辅助模块（AccountRecord、SensitiveWords、SystemInfo）以及BaseServiceImpl通用CRUD能力。

---

## 一、BaseServiceImpl —— 所有Service的"万能基类"

### 🎯 一句话人话
> 🏠 就像超市的自助收银机——提供一套标准操作（增删改查），每个柜台不用自己造收银机，直接用就行。

### BaseServiceImpl提供的通用方法

| 方法 | 干什么 | 对应SQL |
|------|--------|---------|
| insert(T entity) | 插入一条记录 | INSERT INTO ... |
| insertSelective(T entity) | 选择性插入（只插非空字段） | INSERT INTO ... (非空字段) |
| selectByPrimaryKey(id) | 按主键查询 | SELECT * WHERE id = ? |
| select(T entity) | 按条件查询 | SELECT * WHERE ... |
| selectAll() | 查询所有 | SELECT * |
| updateByPrimaryKey(T entity) | 按主键更新 | UPDATE ... WHERE id = ? |
| deleteByPrimaryKey(id) | 按主键删除 | DELETE WHERE id = ? |

### 🏠 打比方
BaseServiceImpl就像一个**万能遥控器**——不管你管的是电视、空调还是音响，开机、关机、调音量这些基础操作都是一样的。每个具体的Service只需要实现自己特有的"高级功能"。

---

## 二、AccountRecordServiceImpl —— 账号操作记录服务

### 🎯 一句话人话
> 🏠 就像银行的监控摄像头——记录谁在什么时候对哪个账号做了什么操作（启用/禁用）。

### 没有自定义方法？
是的！AccountRecordServiceImpl是一个空壳类，只继承了BaseServiceImpl<AccountRecord>。所有操作都走通用CRUD。

### 实际使用场景
在UserInfoServiceImpl.enableUser()中被调用：
```java
// 禁用/启用用户时，自动记录操作日志
AccountRecord accountRecord = new AccountRecord();
accountRecord.setAccount(privilegeUserInfo.getAccount());    // 被操作的账号
accountRecord.setAccountid(privilegeUserInfo.getId());       // 被操作的用户ID
accountRecord.setReason("经办人修改");                        // 操作原因
accountRecord.setUpdateaccount("经办人");                     // 操作人
accountRecord.setType("1");                                  // 操作类型
accountRecord.setEnable(privilegeUserInfo.getEnable()==0 ? "T":"F");  // T=禁用, F=启用
accountRecordService.save(accountRecord);
```

### 数据流向
```
管理员点击"禁用用户"
  → UserInfoApi.enableUser()
  → UserInfoServiceImpl.enableUser()
  → AccountRecordService.save()  ← 记录操作日志
  → 数据库 privilege_account_record 表
```

### ⚠️ 发现的问题
- **操作人固定写死为"经办人"**，应该从UserUtils获取当前操作人的真实账号
- **操作类型固定为"1"**，缺少类型枚举定义
- **没有查询接口**，记录了日志但没有API可以查看

---

## 三、SensitiveWordsServiceImpl —— 敏感词服务

### 🎯 一句话人话
> 🏠 就像论坛的违禁词过滤器——创建账号时不允许包含admin、root、system等敏感词。

### 同样没有自定义方法
SensitiveWordsServiceImpl也是空壳类，继承BaseServiceImpl<SensitiveWords>。

### 实际使用场景
在UserInfoServiceImpl.create()中被调用：
```java
// 创建用户时校验账号是否包含敏感词
String userAccount = privilegeUserInfo.getAccount();
List<SensitiveWords> sensitiveWordsList = sensitiveWordsDao.selectWords();
if (CollectionUtils.isNotEmpty(sensitiveWordsList)){
    for (SensitiveWords words : sensitiveWordsList) {
        if (userAccount.contains(words.getWord())) {
            throw new CustomException("账号包含敏感词");
        }
    }
}
```

### 敏感词列表（从代码推断）
- admin、user、system、manager、supervisor、root、postgres等系统保留词

### ⚠️ 发现的问题
- **没有管理接口**：敏感词的增删改查没有暴露API，只能通过数据库直接操作
- **匹配方式为contains**：如果敏感词是"admin"，那"badminton"也会被拦截（误杀）
- **缺少模糊匹配**：应该支持精确匹配和正则匹配两种模式

---

## 四、PrivilegeSystemInfoServiceImpl —— 系统信息服务

### 🎯 一句话人话
> 🏠 就像应用商店的分类列表——记录有哪些系统可供机构订阅。

### 没有自定义方法
同样是空壳类。自定义查询在SysInfoServiceImpl中实现。

### 数据流向
```
系统信息（门诊慢特病系统、综合查询系统...）
  → 被机构订阅（privilege_org_system）
  → 被菜单关联（privilege_menu_info.system_id）
  → 被角色资源关联（privilege_role_resource.system_id）
```

---

## 五、SysInfoServiceImpl —— 系统信息查询服务

### 源码位置
`/tmp/picc-mzmtb-user/picchealth-privilege-server/src/main/java/com/picchealth/module/sys/service/impl/SysInfoServiceImpl.java`

### 方法：querySysInfo(PrivilegeSystemInfoVo vo)

> 🎯 **一句话人话**：查询系统列表，支持按系统名称模糊搜索。

#### 📥 参数
| 参数 | 说明 | 举例 |
|------|------|------|
| sysName | 系统名称（模糊查询） | "门诊" |
| pageIndex | 页码 | 1 |
| pageSize | 每页条数 | 10 |

#### 📤 返回
`ResultPage<PrivilegeSystemInfoDto>` —— 分页的系统列表

#### 📖 内部步骤
1. 创建查询条件对象
2. 如果sysName不为空，设置模糊查询条件
3. 调用Mapper查询
4. 将PO转为DTO返回

---

## 六、辅助模块改进建议

| 模块 | 问题 | 建议 |
|------|------|------|
| AccountRecord | 操作人写死"经办人" | 改为UserUtils.getUser().getUserAccount() |
| AccountRecord | 没有查询API | 添加查询接口供审计使用 |
| AccountRecord | 操作类型无枚举 | 定义AccountRecordTypeEnum |
| SensitiveWords | 没有管理API | 添加CRUD接口 |
| SensitiveWords | contains误杀 | 改为精确匹配或正则匹配 |
| SystemInfo | 只有一个查询方法 | 可添加系统的新增/编辑/删除 |

---

## 七、项目Service层完整清单

| Service | 有自定义方法？ | 方法数 | 复杂度 |
|---------|-------------|-------|--------|
| OrgInfoServiceImpl | ✅ | 12 | 🔴 高（query()200行） |
| UserInfoServiceImpl | ✅ | 15 | 🔴 高（setAuths复杂） |
| RoleInfoServiceImpl | ✅ | 12 | 🟡 中 |
| MenuInfoServiceImpl | ✅ | 10+ | 🟡 中 |
| PrivilegeMenuInfoServiceImpl | ✅ | 若干 | 🟢 低 |
| PrivilegeMenuServiceServiceImpl | ✅ | 若干 | 🟢 低 |
| SysInfoServiceImpl | ✅ | 1 | 🟢 低 |
| MoveServiceImpl | ✅ | 3 | 🟡 中（迁移逻辑） |
| AccountRecordServiceImpl | ❌ | 0（继承BaseService） | 🟢 最低 |
| SensitiveWordsServiceImpl | ❌ | 0（继承BaseService） | 🟢 最低 |
| PrivilegeSystemInfoServiceImpl | ❌ | 0（继承BaseService） | 🟢 最低 |
| PrivilegeOrgSystemServiceImpl | ❌ | 0（继承BaseService） | 🟢 最低 |

**统计**：12个Service类，其中8个有自定义方法，4个为空壳（纯CRUD走BaseService）。
