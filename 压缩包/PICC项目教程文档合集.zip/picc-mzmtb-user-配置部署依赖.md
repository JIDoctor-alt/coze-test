# PICC 权限管理系统 - 配置文件 / 部署 / 依赖 小白解析

---

## ⚙️ 配置文件 - 系统怎么启动

> 🏠 配置文件就像公司的**规章制度手册**：告诉系统用什么端口、连什么数据库、开什么功能。

### application.yml - 主配置（总规章制度）

| 配置项 | 值 | 含义 | 生活比喻 |
|--------|-----|------|----------|
| server.port | 9092 | 服务端口号 | 公司的门牌号 |
| spring.profiles.active | dev | 当前使用哪套环境配置 | 用哪个分公司的制度 |
| spring.application.name | picc-mzmtb-user | 服务名称 | 公司注册名 |
| apollo.bootstrap.enabled | true | 启用Apollo配置中心 | 用集团统一制度管理平台 |
| apollo.bootstrap.eagerLoad.enabled | true | 启动阶段就加载配置 | 开门前先把制度贴好 |

> 💡 **Apollo配置中心**：人保的统一配置管理平台。就像集团的制度发布平台，不用改代码就能调整配置。本地yml只写基础信息，详细配置都在Apollo上。

### 各环境配置对比

| 环境 | 文件 | Apollo命名空间 | Apollo地址 | 说明 |
|------|------|----------------|------------|------|
| dev（开发） | application-dev.yml | application-local.properties | 10.57.16.41:8080 | 程序员本地开发用 |
| test（测试） | application-test.yml | application-test.properties | 10.57.16.41:8080 | 测试团队验证用 |
| uat（验收） | application-uat.yml | application-uat.properties | 10.57.16.41:8080 | 业务人员验收用 |
| prod（生产） | application-prod.yml | application.properties | 10.34.80.145:8080 | 真正对外服务的环境 |

> 💡 注意：生产环境的Apollo地址不同（北中心），说明是独立的配置中心实例，和生产环境物理隔离。

### bootstrap.yml - 启动引导配置

> 🏠 就像开业前要先办**营业执照**，bootstrap.yml在Spring Boot正式启动前就加载

```yaml
spring:
  application:
    name: picc-mzmtb-user
server:
  port: 9092
```

> 💡 bootstrap.yml 比 application.yml 更早加载，主要用来配置Apollo等需要在启动阶段就准备好的东西。

### logback-spring.xml - 日志配置

> 🏠 就像公司装的**监控摄像头**，记录谁什么时候干了什么

| 配置项 | 值 | 含义 |
|--------|-----|------|
| LOG_HOME | /data/log/app | 日志存放目录 |
| MAX_FILE_SIZE | 100MB | 单个日志文件最大100MB |
| MAX_HISTORY | 7 | 保留7天日志 |
| TOTAL_SIZE_CAP | 500MB | 日志总共最多占500MB |
| 日志格式 | [时间][线程][级别][traceId][主机][服务名][类名][消息] | 包含全链路追踪信息 |

> 💡 日志里带了 `pGlobalTraceId`、`pParentTraceId`、`pLocalTraceId`，这是微服务全链路追踪三件套：就像快递的"始发站→中转站→终点站"追踪码。

### app.properties - Apollo应用标识

```properties
app.id=@app.id@
apollo.meta=@meta@
```
> 这里的 `@xxx@` 是Maven编译时替换的占位符，构建时自动填入实际值。

---

## 📦 项目依赖 - 用了什么库

> 🏠 pom.xml就像公司的**采购清单**，列出了项目需要引入的所有工具和组件

### 技术栈总览

| 技术 | 版本 | 干嘛的 | 生活比喻 |
|------|------|--------|----------|
| Java | 8 | 编程语言 | 工作语言 |
| pdfc-parent | 4.2.6.0 | 人保统一开发框架 | 公司标准工装 |
| Spring Cloud | (由pdfc管理) | 微服务框架 | 集团办公系统 |
| MyBatis | (由pdfc-mybatis管理) | 数据库操作框架 | 仓库管理员 |
| Apollo | (由pdfc-config管理) | 配置中心 | 集团制度发布平台 |
| Redis/Redisson | 3.13.4 | 缓存+分布式锁 | 冰箱+门锁 |
| Druid | 1.0.11 | 数据库连接池 | 银行窗口排队系统 |
| GaussDB | 3.0.0-spc1000 | 华为高斯数据库 | 仓库（华为牌） |
| FastJSON | 1.2.72 | JSON处理 | 翻译官（中英互译） |
| Knife4j | 2.0.0 | API文档工具 | 接口说明书 |
| Lombok | 1.18.30 | 代码简化工具 | 自动填表机 |
| j2cache | 2.7.7 | 两级缓存框架 | 冰箱+冷冻库 |
| BES（宝兰德） | 9.5.5.007 | 国产中间件服务器 | 国产办公大楼 |
| Log4j | 1.2.13 | 日志框架 | 监控录像机 |

### 关键依赖解释

**1. pdfc-parent（统一开发框架）**
> 🏠 就像集团统一采购的办公套件：办公桌、电脑、电话都标准化了，所有分公司用同一套。

**2. GaussDB（华为高斯数据库）**
> 🏠 就像华为牌仓库：不是常见的MySQL/Oracle，而是国产数据库。人保作为国企，用国产数据库是信创要求。

**3. Redisson（分布式锁+缓存）**
> 🏠 Redisson = Redis的加强版：除了当冰箱存东西，还能当"公共厕所锁"（分布式锁），保证同一时间只有一个操作在执行。

**4. BES（宝兰德应用服务器）**
> 🏠 就像国产办公大楼：替代Tomcat的国产中间件，同样是信创要求。注意pom里排除了Tomcat依赖。

**5. j2cache（两级缓存）**
> 🏠 就像冰箱+冷冻库：第一级是本地缓存（冰箱，快但容量小），第二级是Redis（冷冻库，稍慢但容量大），配合使用性能最优。

**6. Knife4j（API文档）**
> 🏠 就像接口说明书：自动生成所有API的在线文档，前端同事可以在线查看和调试，不用每次问后端。

---

## 🐳 部署配置 - 怎么上线

> 🏠 部署就像开连锁店：需要统一装修方案、分配合适的场地、办各种手续

### K8s部署概述

项目在 `config/kubeconfig/` 下有3个K8s配置文件：

| 文件 | 用途 |
|------|------|
| ns-jczx-tyfwzt-dev.yaml | 开发环境K8s配置 |
| ns-jczx-tyfwzt.yaml | 标准环境K8s配置 |
| p-ns-jczx-tyfwzt.yaml | 生产环境K8s配置 |

> `jczx-tyfwzt` = 基础中心-统一服务中台（拼音缩写）

### 部署流程（小白版）

```
1. 程序员写好代码，推送到阿里云Codeup
         ↓
2. CI/CD流水线自动构建（mvn package打jar包）
         ↓
3. 制作Docker镜像（把jar包塞进容器）
         ↓
4. 推送到人保私有镜像仓库
         ↓
5. 通过K8s配置部署到对应环境（dev/test/uat/prod）
         ↓
6. 服务启动，连接Apollo拉取配置，注册到注册中心
         ↓
7. 对外提供服务（端口9092）
```

---

## 🧪 测试 - 怎么验证

> 🏠 测试就像出厂前的**质量检验**，确保迁移功能不会出问题

### 测试类：PrivilegeMoveTest

这是唯一的测试类，专门测试数据迁移功能。

#### 测试方法列表

| 方法 | 测试什么 | 是否危险 |
|------|----------|----------|
| move() | 角色数据迁移 | ⚠️ 会往数据库写数据 |
| moveUserRole() | 用户角色关系迁移 | ⚠️ 会往数据库写数据 |
| passwordBackMD5() | 密码RSA解密→MD5回退 | ⚠️ 会修改用户密码 |

#### 测试详解

**1. move() - 角色迁移测试**
- 从旧表 `sys_role_module_rel` 读取角色和资源数据
- 按角色编码去重（同一角色在不同机构下需要拆分）
- 写入新表 `privilege_role_info` 和 `privilege_role_resource`
- 关键逻辑：相同code的角色会被赋予不同的ID，按序号递增

**2. moveUserRole() - 用户角色迁移测试**
- 必须在 `move()` 之后执行（因为角色ID已经变了）
- 从旧表 `sys_user_role_rel` 读取用户角色关系
- 通过"用户→机构ID"和"旧角色→新角色code"找到新的角色ID
- 写入新表 `privilege_user_role_info`

**3. passwordBackMD5() - 密码回退测试**
- 读取所有用户的RSA加密密码
- 用RSA私钥解密
- 把解密后的明文密码直接存回数据库（实际是MD5值）
- 解密失败的跳过

> ⚠️ **警告**：这些测试不是单元测试，是数据迁移工具！执行时会直接修改数据库，千万不要在测试/生产环境随便跑！

---

## 🔗 完整项目架构总结

```
┌─────────────────────────────────────────────────────┐
│  前端页面 (Vue/React)                                │
│  用户管理 | 机构管理 | 角色管理 | 菜单管理 | 系统管理   │
└──────────────────────┬──────────────────────────────┘
                       │ HTTP POST (所有接口都是POST)
┌──────────────────────▼──────────────────────────────┐
│  API层 (@RestController)                             │
│  UserInfoApi | OrgInfoApi | RoleInfoApi | MenuInfoApi │
│  + @ApiInterceptor (Token验证 + 权限检查)             │
└──────────────────────┬──────────────────────────────┘
┌──────────────────────▼──────────────────────────────┐
│  Service层 (业务逻辑)                                │
│  UserInfoServiceImpl | OrgInfoServiceImpl | ...       │
│  + @Transactional (事务控制)                          │
│  + BeanUtils.copyProperties (对象转换)                 │
└──────────────────────┬──────────────────────────────┘
┌──────────────────────▼──────────────────────────────┐
│  DAO层 (MyBatis Mapper)                              │
│  XML定义SQL → 操作GaussDB数据库                       │
│  + 动态SQL (<if>/<foreach>)                          │
│  + 逻辑删除 (delete_at IS NULL)                       │
└──────────────────────┬──────────────────────────────┘
┌──────────────────────▼──────────────────────────────┐
│  GaussDB数据库 (华为高斯DB)                           │
│  privilege_user_info / org_info / role_info / menu    │
│  org_system / role_resource / menu_service / ...      │
└─────────────────────────────────────────────────────┘

外部依赖：
  Apollo配置中心 → 统一管理所有环境配置
  Redis/Redisson → 缓存 + 分布式锁
  K8s → 容器化部署
  BES宝兰德 → 国产应用服务器
```
