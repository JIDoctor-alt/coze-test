# PICC人保健康权限管理系统 - 新成员Onboarding手册

> 🎯 目标：让一个新加入项目组的开发人员，在2小时内理解项目全貌，能独立开始开发。

---

## 一、项目速览卡

| 项目 | 信息 |
|------|------|
| 项目名称 | 门诊慢特病业务管理信息系统-权限管理服务 |
| 仓库地址 | 阿里云Codeup（私有仓库） |
| 技术栈 | Spring Boot 2.x + MyBatis + GaussDB + Redis + Apollo |
| 服务端口 | 9092 |
| 部署方式 | K8s容器化部署 |
| 应用服务器 | BES宝兰德（信创要求） |
| 数据库 | GaussDB（信创要求，兼容PostgreSQL） |
| 代码规范 | Lombok + PageHelper分页 + 软删除(delete_at) |

---

## 二、5分钟跑起来

### 环境准备
```bash
# 1. JDK 1.8（必须）
java -version  # 确认1.8.x

# 2. Maven 3.6+
mvn -version

# 3. 本地需要有GaussDB或PostgreSQL实例
# 4. 本地需要有Redis
```

### 克隆与启动
```bash
# 克隆仓库
git clone https://codeup.aliyun.com/69708490f7b43e00d4204914/picc-mzmtb-user.git

# 编译打包
cd picc-mzmtb-user
mvn clean package -DskipTests

# 启动（需要先配置数据库和Redis连接）
# 配置文件: picchealth-privilege-server/src/main/resources/application.yml
# Apollo配置中心: 10.57.16.41:8080 (dev环境)

java -jar picchealth-privilege-server/target/picchealth-privilege-server.jar
```

### 常见启动问题

| 问题 | 原因 | 解决 |
|------|------|------|
| 连不上Apollo | VPN未连接 | 先连VPN，Apollo在内网 |
| GaussDB连接失败 | 数据库未配置 | 修改bootstrap.yml指向本地PG |
| Redis连接失败 | Redis未启动 | 启动本地Redis |
| Bean创建失败 | Apollo配置缺失 | 本地开发可临时关闭Apollo |

---

## 三、项目结构速查

```
picc-mzmtb-user/
├── picchealth-privilege-server/     ← 主服务模块（启动类在这里）
│   ├── src/main/java/
│   │   └── com/picchealth/
│   │       ├── config/              ← 配置类（拦截器、过滤器）
│   │       ├── module/
│   │       │   ├── sys/             ← 系统模块（机构、用户、系统）
│   │       │   │   ├── api/         ← Controller层
│   │       │   │   ├── service/     ← Service接口
│   │       │   │   │   └── impl/    ← Service实现
│   │       │   │   ├── vo/          ← 视图对象（给前端看的）
│   │       │   │   └── dto/         ← 数据传输对象
│   │       │   ├── role/            ← 角色模块
│   │       │   └── menu/            ← 菜单模块
│   │       └── utils/               ← 工具类
│   └── src/main/resources/
│       ├── application.yml          ← 主配置
│       └── bootstrap.yml            ← Apollo配置
│
├── picchealth-privilege-db/         ← 数据库模块
│   └── src/main/resources/mapper/   ← MyBatis XML文件
│       └── module/
│           ├── system/              ← 系统模块Mapper
│           └── role/                ← 角色模块Mapper
│
└── pom.xml                          ← Maven父POM
```

---

## 四、核心业务速懂

### 权限模型：三维度交叉

```
维度1: 用户→角色→菜单（你能用哪些功能？）
维度2: 机构→系统→菜单（你所在部门开通了哪些功能？）
维度3: 用户→权限归属→菜单（你的管辖范围能看到哪些数据？）

最终可见 = 维度1 ∩ 维度2 ∩ 维度3
```

### 六大业务模块

| 模块 | 干什么的 | API前缀 | 核心表 |
|------|---------|---------|-------|
| 机构管理 | 管理省/市/县公司层级 | /privilege/org | privilege_org_info |
| 用户管理 | 管理系统用户CRUD | /privilege/user | privilege_user_info |
| 角色管理 | 管理角色及角色权限 | /privilege/role | privilege_role_info |
| 菜单管理 | 管理系统菜单树 | /privilege/menu | privilege_menu_info |
| 系统管理 | 管理业务系统 | /privilege/sys | privilege_system_info |
| 数据迁移 | 旧系统数据迁移工具 | /privilege/move | sys_role_module_rel |

---

## 五、开发规范速记

### 编码约定

| 规范 | 说明 |
|------|------|
| 删除 = 软删除 | 设置delete_at字段，不物理删除 |
| 主键 = UUID | UUIDUtil.getUUID()生成 |
| 分页 = PageHelper | PageHelper.startPage() |
| 密码 = SM4加密 | SM4Util.sm4Encrypt() |
| 用户信息 = UserUtils | UserUtils.getUser()获取当前用户 |
| 异常 = CustomException | 统一抛CustomException |
| 返回 = ApiResponse | 统一用ApiResponse.ok()/fail() |

### 新增接口标准流程

```
1. 在vo/下创建请求VO
2. 在dto/下创建DTO（如需）
3. 在service/下创建Service接口
4. 在service/impl/下实现Service
5. 在api/下创建Controller
6. 在dao/下添加Mapper方法
7. 在mapper XML中添加SQL
8. 测试！
```

### 请求走完一遭的路径

```
前端请求
  → ApiAuthorityFilter（Token校验，只拦截/privilege/user/*）
  → ApiInterceptor（URL权限校验）
  → Controller（参数校验，调用Service）
  → Service（业务逻辑，调用Mapper）
  → Mapper（SQL执行）
  → 数据库（GaussDB）
  → 返回ApiResponse
```

---

## 六、踩坑指南

### 已知坑点

| 坑 | 在哪 | 怎么避 |
|----|------|-------|
| orgName字段传的是ID | OrgQueryVo.orgName | 看注释！传机构ID不是名称 |
| pageNum从0开始=不分页 | PageHelper | pageNum最小传1 |
| 密码默认值在配置里 | defaultPassWord | 默认PICChealth@2020，SM4加密 |
| 机构树默认根ID="1" | defaultId = "1" | parentId="1"代表上级是人保集团 |
| 权限编码88=管理员 | UserInfoServiceImpl | authCode.contains("88")是管理员 |
| Apollo必须连通 | bootstrap.yml | 本地开发可配本地profile |

---

## 七、调试技巧

### 1. Swagger文档
启动后访问：`http://localhost:9092/swagger-ui.html`

### 2. 日志配置
logback-spring.xml控制日志级别，开发环境建议设为DEBUG

### 3. Redis调试
```bash
# 查看当前Token
redis-cli keys "api_token:*"

# 查看用户信息缓存
redis-cli keys "userid:*"

# 清除某个用户的Token（强制重新登录）
redis-cli del "userid:xxx"
```

### 4. 数据库调试
```sql
-- 查看软删除的数据（正常查询看不到）
SELECT * FROM privilege_user_info WHERE delete_at IS NOT NULL;

-- 查看某个用户的所有权限
SELECT u.name, r.name as role_name, m.name as menu_name
FROM privilege_user_info u
JOIN privilege_user_role ur ON u.id = ur.user_id AND ur.delete_at IS NULL
JOIN privilege_role_info r ON ur.role_id = r.id AND r.delete_at IS NULL
JOIN privilege_role_resource rr ON r.id = rr.role_id AND rr.delete_at IS NULL
JOIN privilege_menu_info m ON rr.menu_id = m.id AND m.delete_at IS NULL
WHERE u.account = '要查的账号';
```

---

## 八、关键人物与联系方式

> ⚠️ 请根据实际情况补充

| 角色 | 姓名 | 职责 |
|------|------|------|
| 项目负责人 | ? | 项目整体管理 |
| 后端开发 | jiezhenchi | 用户、机构、迁移模块 |
| 后端开发 | LiuChunlin | 角色、权限模块 |
| DBA | ? | GaussDB维护 |
| 运维 | ? | K8s部署、Apollo配置 |

---

## 九、下一步学习路径

1. 📖 通读 `picc-mzmtb-user-教程文档.md`（主教程，7000+行）
2. 🔧 本地启动项目，用Swagger调通一个接口
3. 📝 阅读OrgInfoServiceImpl.java（最复杂的Service，731行）
4. 🔐 理解权限三维度模型
5. 🗄️ 熟悉17张数据库表的结构和关系
6. 🛡️ 了解安全机制（三道认证关卡）
7. ✏️ 尝试新增一个简单接口（如机构备注修改）

---

## 十、常见问题FAQ

**Q: 为什么用GaussDB不用MySQL？**
A: 信创要求。政府/国企项目必须使用国产数据库，GaussDB是华为的，兼容PostgreSQL语法。

**Q: 为什么用BES宝兰德不用Tomcat？**
A: 同样是信创要求。BES是国产应用服务器，API和Tomcat基本兼容。

**Q: Apollo是什么？为什么要用它？**
A: Apollo是配置中心，把所有环境（dev/test/uat/prod）的配置集中管理，修改配置不需要重启服务。项目里数据库连接、Redis地址等都在Apollo里。

**Q: 为什么所有表都用软删除？**
A: 权限数据是敏感数据，删除后可能需要审计追溯，所以用delete_at标记删除而不是物理删除。

**Q: 同一个角色名在不同机构是不同记录？**
A: 是的。比如"经办员"这个角色在西安和宝鸡是两条不同记录（不同ID），因为每个机构可以自定义角色的权限范围。
