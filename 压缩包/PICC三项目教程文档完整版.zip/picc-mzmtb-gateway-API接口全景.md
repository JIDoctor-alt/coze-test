# PICC门诊慢特病前台服务 API接口全景文档

> **文档目标**：面向零基础小白，清晰呈现前台服务所有API接口的全貌与分类  
> **更新时间**：2025-02-20  
> **文档版本**：v1.0

---

## 一、服务概述

| 项目 | 说明 |
|------|------|
| 服务名称 | picc-mzmtb-gateway（门诊慢特病前台服务） |
| 服务端口 | 9001 |
| 架构特点 | 不直连数据库，通过HTTP转发到业务服务（9091） |
| API类总数 | 104个 |
| VO文件总数 | 361个 |

**核心工作机制**：前台服务通过 `HttpForwardUtil` 工具，将外部请求（REST调用）转发到后台业务服务，由业务服务完成业务处理与数据库操作后，前台服务再将结果返回给调用方。

---

## 二、前台服务角色分析

前台服务在整个系统中的角色可分为四类：

| 角色 | 说明 | 典型特征 |
|------|------|----------|
| **纯转发接口** | 仅做请求转发，不增加业务逻辑 | 直接调用 `HttpForwardUtil.post` |
| **自有业务逻辑接口** | 前台服务包含特定业务处理 | 存在本地数据处理、权限校验等逻辑 |
| **小程序专用接口** | 面向微信小程序的专属接口 | 路径通常包含 `/picchealth/` 或 `/v2/picchealth/` |
| **地市专用接口** | 针对特定地市的定制化接口 | 方法或路径中包含地市编码（BJ、YA、SL、YL、DZ、ZJK、JZ、JC、XYA等）或地市版本标识（YH、SL等） |

> **说明**：本手册所列接口均来自前台服务模块，实际业务处理由后台服务完成。

---

## 三、业务域全景与统计（11个域）

| 业务域 | 接口类数 | 接口方法数 |
|--------|----------|------------|
| 登录认证 | 2 | 1 |
| 申报管理 | 23 | 28 |
| 审批管理 | 4 | 0 |
| 发卡管理 | 3 | 1 |
| 处方管理 | 5 | 10 |
| 药店管理 | 10 | 0 |
| 专家管理 | 1 | 0 |
| 数据查询 | 37 | 33 |
| 定时任务 | 1 | 45 |
| 外部接口 | 6 | 0 |
| 系统运维 | 10 | 13 |

---

## 四、各业务域接口清单

> **提示**：路径为前台服务对外路径，多数通过 `HttpForwardUtil` 转发到后台业务服务。部分接口存在“YH”“SL”等地市版本标识，表示针对该地市的优化版本。

### 4.1 登录认证（2类）

- `LoginApi`（类路径：`/Login`）
  - doLogin（登录）
  - getUser（根据登录token获取用户信息）
  - logOut（登出/注销）
  - update（修改密码）
  - updateDz
  - getUserList
  - queryUserInfoByRole
  - queryUserInfoByIds
  - register
  - check（拼图校验）
  - signOut
  - getMobile
- `XcxLoginApi`（小程序登录）

### 4.2 申报管理（23类）

- `MbDeclareApi`（类路径：`/MbDeclare`）
  - query（查询线下申报记录）
  - declare（线下申报）
  - slCheck（商洛线下申报）
  - bjYaYlCheck（宝鸡、延安、榆林医保资格校验）
  - declareYH（线下申报 优化）
  - queryYH（查询线下申报记录 优化）
  - VIPQueryChronicBalance
  - 其他地市/优化方法（SL、YH等）
- `VipMbDeclareFirstTrialApi`（类路径：`/MbDeclareFirstTrial`）
  - queryMbDeclareListInFirstTrail
  - updateMbDeclareFirstApprovalInfo
  - SL、ZJK、YH等地市版本方法
- `XcxDeclareApi`（类路径：`/v2/picchealth/`）
  - queryDeclareComList
  - queryIcdList
  - mbDeclare
  - YiBaoCheck
- `MtbDeclareListApi`
- `MtbMbDeclareApi`
- `XcxIndexApi`（类路径：`/v2/picchealth`）
  - getWeiXinUserStatus
  - ForeignUserRegistAndLogin
  - getBanner
  - queryMBDeclare
- 其他申报相关类（如 `MtbDeclareCancelApi`、`MbDeclareSwitchApi` 等）

### 4.3 审批管理（4类）

- `VipMbDeclareReviewApi`
- `MbApprovalFileApi`
- `MbReviewApi`
- `ActivitiApi`（工作流备注、操作轨迹、资料回退等）

### 4.4 发卡管理（3类）

- `MbmzSendCardApi`（类路径：`/mbmzSendCard`）
- `MbmzCardStatusReportApi`
- `MbUserExtApi`（查询发卡列表、重置密码等）

### 4.5 处方管理（5类）

- `MbPrescriptionManagementApi`（类路径：`/prescription`）
  - 多地市版本（YL、BJ、YA等）
  - 查看/上传处方、处方驳回、录入完成、药品查询与存储
- `VipPrescriptionApi`
- `CxPrescriptionPoolApi`
- `YaPrescriptionPoolApi`（类路径：`/prescription`）
  - pushdata、queryPre、queryPreBj 等
- `MtbPrescriptionManagementApi`

### 4.6 药店管理（10类）

- `VipDrugstoreChargeAddApi`（类路径：`/vipDrugstoreChargeAdd`）
  - queryAccountInfoForYD（查询账户信息用于药店）
  - queryDrugstoreProduct
  - calculateClaim
  - getVipAccounthosByAccountid
- `VipDrugstoreChargeAddNewApi`
- `VipDrugstoreChargeListAdminApi`
- `VipDrugstoreChargeListApi`
- `VipDrugstoreOrderReportApi`
  - queryVipMerchantName
  - getDrugstoreOrderReportList
  - exportDrugstoreOrderReportList
- `VipDrugstoreProductListApi`
  - queryProductList
- `DrugstoreOrderReportApi`
- `DrugstoreOrderPrintApi`
- `DrugstoreDetailReportApi`

### 4.7 专家管理（1类）

- `VipMbDeclareExpertAssignApi`
- `DizMbDeclareExpertAssignApi`（类路径：`/MbDeclareExpertAssign`）
  - DizqueryIcdListQEQ
  - DizupdateExpert
  - DizupdateExpertCancel
  - DizqueryMbDeclarePhysicalCompleteListYH
  - DizqueryMbExpertList
  - DizgetDiseaseNameList

### 4.8 数据查询（37类）

- `MbDataListApi`（类路径：`/MbDataList`）
  - queryVipCardType
  - queryOutBjHosList
  - query
  - edit
  - selectGridRow
  - getVipAccountHos
  - queryBjDrugList
  - getPrescription
- `MbDataStatisticsApi`
  - 宝鸡/延安数据统计查询与导出
  - 账号导出权限查询
- `VipAccountDataApi`
- `VipAccountInfoApi`
- `VipAccountMbmzListApi`
- `VipMoneyFlowSelectApi`
- `VipRecordBjApi`
- `VipMbmzStatusLogListApi`
- `MbYearCheckApi`
- `MbInfoHistoryApi`
- `MbInfoUpdateApi`
- `MbFilingImportRecordApi`
- `MtbDataStatisticsApi`
- `TFilingManApi`
- `VipOrgBankinfoApi`
- `VipPhysicalOrgApi`
- `FilingManApi`
  - filing、filingBack、queryFiling、export
- `PersonDivisionApi`
- `VipChronicPayApi`
- `VipIntelligentApi`
- `VipJkdaApi`
- `WqxOutInterfaceApi`
- `SxMbDeclareApi`
- `TMbRecordApi`
- `XjsApi`

### 4.9 定时任务（1类）

- `SchedulingApi`（类路径：`/scheduling`）
  - vipMbmzStatusTask
  - BJAutoFilingTask
  - BJRecordTask
  - BJfilingSynchronize
  - slYearCheckTask
  - bjMedicPORResearchTask
  - bjMedicPutOnRecTask
  - BJops
  - BJDelFilingTask
  - detectionSwitchTask
  - drugSynchronizedTask
  - 等共45个定时任务方法

### 4.10 外部接口（6类）

- `RestfulApi`（类路径：`/restful/system`）
  - info、healthCheck 等
- `BaojiApi`（类路径：`/medicalcheckup`）
  - VIPUPReport（体检报告推送）
- `YaPrescriptionPoolApi`（类路径：`/prescription`）
  - pushdata、queryPre、queryPreBj
- `OcrApi`
- `SendMessageApi`
- `YihuServiceApi`
- `WqxStructuredDataApi`

### 4.11 系统运维（10类）

- `Activiti6Api`（类路径：`/activiti6`）
  - deploy（工作流发布）
- `ActivitiApi`（类路径：`/activiti`）
  - addComment（添加备注）
  - getComments（查询备注列表）
  - getHistories（查询操作轨迹列表）
  - meansBack（资料回退）
- `CodeNameApi`（类路径：`/codename`）
  - getCodeName
  - getDistrictCodeList
  - getCodeList
  - getCodes
- `LogAuditApi`（类路径：`/logAudit`）
  - queryLog
- `OpsApi`（类路径：`/ops`）
- `MbImportApi`
  - upload、download、query、地市模板与错误下载等
- `MbUpdateApi`
- `MtbImportApi`
- `MtbUpdateApi`
- `MtbFileApi`
- `MtbInfoMosaicApi`

---

## 五、接口调用流程示例（小白向）

1. 前端发起REST请求（如POST http://host:9001/Login/doLogin）  
2. 前台服务接收请求，必要时进行预处理（如Token校验、参数清洗）  
3. 前台服务通过 `HttpForwardUtil` 将请求转发至后台业务服务（http://host:9091/...）  
4. 后台业务服务完成业务逻辑、数据库操作，返回结果  
5. 前台服务接收结果，经过必要的数据处理与格式转换后返回给前端

---

## 六、敏感信息与合规说明

- 本文档已对内部实现细节进行适当抽象与脱敏，不包含密码、密钥、个人隐私等敏感信息  
- 所有接口路径均来源于源码中的注解定义  
- 文档仅供内部学习与参考，请勿泄露给外部人员

---

## 七、附录：地市与版本标识对照

| 标识 | 含义 |
|------|------|
| BJ | 宝鸡 |
| YA | 延安 |
| SL | 商洛 |
| YL | 榆林 |
| DZ | 达州 |
| ZJK | 张家口 |
| JZ | 晋中 |
| JC | 晋城 |
| XYA | 咸阳 |
| YH | 优化（通用优化版本标识） |

---

**文档结束**。如有疑问，请参考源码或咨询项目负责人。


---

## 八、完整API类清单（104类）

> 以下为所有API类的完整路径与方法列表，按模块分组

### 8.1 基础模块（base）
| 类名 | RequestMapping | 方法数 | 说明 |
|------|----------------|--------|------|
| BaseApi | - | 0 | 基类，无接口 |

### 8.2 呼叫模块（call）
| 类名 | RequestMapping | 方法数 | 说明 |
|------|----------------|--------|------|
| CallApi | /call | 0 | 呼叫服务 |

### 8.3 地市专用（diz）
| 类名 | RequestMapping | 方法数 | 说明 |
|------|----------------|--------|------|
| DizMbDeclareExpertAssignApi | /MbDeclareExpertAssign | 0 | 地市专家分配 |

### 8.4 数据视图（dpview）
| 类名 | RequestMapping | 方法数 | 说明 |
|------|----------------|--------|------|
| DpViewApi | /dpViewQuery | 0 | 数据查询视图 |

### 8.5 药店管理（drugstore）- 10类
| 类名 | RequestMapping | 方法数 | 说明 |
|------|----------------|--------|------|
| VipDrugstoreChargeAddApi | /vipDrugstoreChargeAdd | 0 | 药店收费新增 |
| VipDrugstoreChargeAddNewApi | /vipDrugstoreChargeAddNew | 0 | 药店收费新增(新) |
| VipDrugstoreChargeListAdminApi | /vipDrugstoreChargeListAdmin | 0 | 药店收费清单(管理) |
| VipDrugstoreChargeListApi | /vipDrugstoreChargeList | 0 | 药店收费清单 |
| VipDrugstoreOrderReportApi | /vipDrugstoreOrderReport | 0 | 药店订单报表 |
| VipDrugstoreProductListApi | /vipDrugstoreProductList | 0 | 药店产品列表 |
| DrugstoreOrderReportApi | /drugstoreOrderReport | 0 | 药店订单报表 |
| DrugstoreOrderPrintApi | /drugstoreOrderPrint | 0 | 药店订单打印 |
| DrugstoreDetailReportApi | /drugstoreDetailReport | 0 | 药店明细报表 |

### 8.6 日志审计（logaudit）
| 类名 | RequestMapping | 方法数 | 说明 |
|------|----------------|--------|------|
| LogAuditApi | /logAudit | 0 | 日志审计查询 |

### 8.7 慢特病管理（mb）- 核心模块
| 类名 | RequestMapping | 方法数 | 说明 |
|------|----------------|--------|------|
| ActivitiApi | /activiti | 0 | 工作流(操作轨迹、资料回退) |
| Activiti6Api | /activiti6 | 0 | 工作流v6(流程发布) |
| CodeNameApi | /codename | 0 | 编码名称查询 |
| ConsultationOnlineApi | /rest/consultationOnline | 0 | 在线咨询 |
| CxPrescriptionPoolApi | /cxPrescription | 0 | 处方池(重新筛选) |
| FilingManApi | /filingMan | 0 | 备案人管理 |
| LoginApi | /Login | 0 | 登录认证(13个方法) |
| MbApprovalFileApi | /MbApprovalFile | 0 | 审批附件 |
| MbApprovalFileExpertApi | /MbApprovalFileExpert | 0 | 专家审批附件 |
| MbDataListApi | /MbDataList | 0 | 数据列表查询 |
| MbDataStatisticsApi | /MbDataStatistics | 0 | 数据统计 |
| MbDeclareApi | /MbDeclare | 0 | 线下申报(多地市版本) |
| MbDeclareSwitchApi | /MbDeclareSwitch | 0 | 申报开关 |
| MbImportApi | /MbImport | 0 | 导入功能 |
| MbmzCardStatusReportApi | /MbCardStatusReport | 0 | 慢病卡状态报表 |
| MbmzInfoHistoryApi | /MbInfoHistory | 0 | 信息历史 |
| MbmzInfoUpdateApi | /mbmzInfoUpdate | 1 | 图片处理(唯一自有逻辑) |
| MbmzSendCardApi | /mbmzSendCard | 0 | 发卡管理 |
| MbMzSettlementReportApi | /MbSettlementReport | 0 | 结算报表 |
| MbPrescriptionManagementApi | /MbPrescriptionManagement | 0 | 处方管理 |
| MbReviewApi | /MbReview | 0 | 审批审核 |
| MbUpdateApi | /MbUpdate | 0 | 信息更新 |
| MbUserExtApi | /MbUser | 0 | 用户扩展 |
| MbYearCheckApi | /MbYearCheck | 0 | 年审管理 |
| MtbFilingImportRecordApi | /FilingImportRecord | 0 | 备案导入记录 |
| OpsApi | /ops | 0 | 运维操作 |
| PersonDivisionApi | /personDivision | 0 | 人员归属 |
| SxMbDeclareApi | /vipSxMbDeclare | 0 | 商洛申报 |
| TMbRecordApi | /tMbRecord | 0 | 备案记录 |
| VipAccountDataApi | /vipAccountDataList | 0 | 账户数据 |
| VipAccountInfoApi | /vipAccount | 0 | 账户信息 |
| VipAccountMbmzListApi | /vipAccountMbmzList | 0 | 账户慢病列表 |
| VipChronicPayApi | /rest/VipChronicAccount | 0 | 慢病账户支付 |
| VipIntelligentApi | /intelligent | 0 | 智能服务 |
| VipJkdaApi | /jkdaService | 0 | 健康档案 |
| VipMbDeclareDifferenceApi | /VipMbDeclareDifference | 0 | 申报差异 |
| VipMbDeclareExpertAssignApi | /MbDeclareExpertAssign | 0 | 专家分配 |
| VipMbDeclareFileViewNewApi | /MbDeclareFileView | 0 | 文件查看 |
| VipMbDeclareFirstTrialApi | /MbDeclareFirstTrial | 0 | 初审管理 |
| VipMbDeclareForDocApi | /Doctor | 0 | 医生端申报 |
| VipMbDeclareForProfApi | /vipMbDeclareForProf | 0 | 专家端申报 |
| VipMbdeclareInfoApi | /vipMbDeclarePhysicalAssign | 0 | 体检分配 |
| VipMbdeclareInfoOptApi | /opt/vipMbDeclarePhysicalAssign | 0 | 体检分配(运营) |
| VipMbDeclareListApi | /vipMbDeclareList | 0 | 申报列表 |
| VipMbDeclareReviewApi | /vipMbDeclareReview | 0 | 申报审核 |
| VipMbDeclareServiceApi | /mb/auditform | 0 | 审核表单 |
| VipMBDeclareXcxApi | /picchealth | 0 | 小程序申报 |
| VipMbExpertListApi | /MbExpertList | 0 | 专家列表 |
| VipMbmzStatusLogListApi | /vipMbmzStatusLogList | 0 | 状态日志 |
| VipMoneyFlowSelectApi | /vipMoneyFlowSelect | 0 | 资金流水 |
| VipOrgBankinfoApi | /vipOrgBankinfo | 0 | 机构银行信息 |
| VipPhysicalOrgApi | /PhysicalOrg | 0 | 体检机构 |
| VipPrescriptionApi | /MbPrescription | 0 | 处方管理 |
| VipRecordBjApi | /RecordBj | 0 | 宝鸡备案 |
| VipReviewYaApi | /VipReviewYa | 0 | 延安审核 |
| WqxOutInterfaceApi | /WqxOutInterface | 0 | 外部接口 |

### 8.8 慢特病管理-mtb（mtb）- 15类
| 类名 | RequestMapping | 方法数 | 说明 |
|------|----------------|--------|------|
| DocDeclareApi | /Doctor | 0 | 医生申报 |
| MtbDataStatisticsApi | /MbDataStatistics | 0 | 数据统计 |
| MtbDeclareCancelApi | /MbDeclareCancel | 0 | 申报取消 |
| MtbDeclareExpertAssignApi | /MbDeclareExpertAssign | 0 | 专家分配 |
| MtbDeclareListApi | /vipMbDeclareList | 0 | 申报列表 |
| MtbdeclarePhysicalApi | /opt/vipMbDeclarePhysicalAssign | 0 | 体检分配 |
| MtbDeclareSwitchApi | /MbDeclareSwitch | 0 | 申报开关 |
| MtbDrugApi | /MbDrug | 0 | 药品管理 |
| MtbExtLoginApi | /Login | 0 | 外部登录 |
| MtbFileApi | /MbDeclareFileView | 0 | 文件管理 |
| MtbImportApi | /MbImport | 0 | 数据导入 |
| MtbInfoMosaicApi | /opt/infoMosaic | 0 | 信息脱敏 |
| MtbMbDeclareApi | /MbDeclare | 0 | 申报管理 |
| MtbPrescriptionManagementApi | /MbPrescriptionManagement | 0 | 处方管理 |
| MtbUpdateApi | /vipUpdateInfo | 0 | 信息更新 |
| MtbVipMbDeclareFirstTrialApi | /MbDeclareFirstTrial | 0 | 初审管理 |
| ProfDeclareApi | /vipMbDeclareForProf | 0 | 专家申报 |
| TFilingManApi | /filingMan | 0 | 备案人 |
| XcxDeclareApi | /picchealth/ | 0 | 小程序申报 |
| XcxIndexApi | /picchealth | 0 | 小程序首页 |
| XcxLoginApi | /picchealth/ | 0 | 小程序登录 |
| XjsApi | /xjs | 0 | 忻州专用 |
| ZipDownloadApi | /zipdownload | 0 | 批量下载 |

### 8.9 外部服务（outservice）
| 类名 | RequestMapping | 方法数 | 说明 |
|------|----------------|--------|------|
| YihuServiceApi | - | 0 | 医互服务 |

### 8.10 RESTful接口（restful）- 6类
| 类名 | RequestMapping | 方法数 | 说明 |
|------|----------------|--------|------|
| BaojiApi | /medicalcheckup | 0 | 宝鸡体检 |
| OcrApi | /ocr | 0 | OCR识别 |
| RestfulApi | /restful/system | 0 | 系统接口 |
| SendMessageApi | /rest/messageSend | 0 | 消息发送 |
| WqxStructuredDataApi | /structured | 0 | 结构化数据 |
| YaPrescriptionPoolApi | /prescription | 0 | 延安处方池 |

### 8.11 排班调度（schedualing）
| 类名 | RequestMapping | 方法数 | 说明 |
|------|----------------|--------|------|
| SchedulingApi | /scheduling | 45 | 定时任务(45个方法) |

### 8.12 测试模块（test）
| 类名 | RequestMapping | 方法数 | 说明 |
|------|----------------|--------|------|
| Viph5Api | /viph5 | 0 | H5测试 |

---

## 九、核心发现总结

### 9.1 转发模式分析
- **纯转发类**：103个（99%）- 直接调用`HttpForwardUtil.post/get`
- **自有逻辑类**：1个（1%）- `MbmzInfoUpdateApi.getPictureResult`（图片处理）

### 9.2 高频后端路径
```
/MbDeclare      - 申报管理（最多API类复用）
/MbPrescription - 处方管理
/vipMbDeclare   - VIP申报
/Login          - 登录（多版本）
/codename       - 编码查询
```

### 9.3 地市专用标识
| 标识 | 地市 | 用途 |
|-----|------|------|
| BJ | 宝鸡 | 医保审核、备案 |
| YA | 延安 | 审核、处方 |
| SL | 商洛 | 年审、申报 |
| YL | 榆林 | 处方、审核 |
| DZ | 达州 | 申报 |
| ZJK | 张家口 | 初审 |
| JZ | 晋中 | 申报 |
| JC | 晋城 | 申报 |
| XYA | 咸阳 | 申报 |
| XJS | 忻州 | 专项接口 |
| YH | 优化版 | 通用优化版本 |

---

**文档更新**：v2.0 - 补充完整API类清单
