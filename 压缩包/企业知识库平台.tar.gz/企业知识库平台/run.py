#!/usr/bin/env python3
"""
企业知识库平台 - 启动脚本
"""

import uvicorn
from src.core.config.settings import settings


def main():
    """启动服务"""
    uvicorn.run(
        "src.api.app:app",
        host="0.0.0.0",
        port=8080,
        reload=settings.DEBUG,
        log_level="info"
    )


if __name__ == "__main__":
    main()
