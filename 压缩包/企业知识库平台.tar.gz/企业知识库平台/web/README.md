# 企业知识库平台 - 前端管理系统

基于 Vue3 + TypeScript + Ant Design Vue 的企业知识库平台前端管理系统。

## 技术栈

- **Vue 3** - 渐进式 JavaScript 框架
- **TypeScript** - JavaScript 的超集，提供类型检查
- **Vite** - 下一代前端构建工具
- **Ant Design Vue** - 企业级 UI 组件库
- **Vue Router** - Vue.js 官方路由管理器
- **Pinia** - 新一代状态管理库
- **Axios** - HTTP 请求库

## 项目结构

```
web/
├── src/
│   ├── api/              # API 接口
│   │   ├── auth.ts       # 认证接口
│   │   ├── document.ts   # 文档接口
│   │   ├── knowledgeBase.ts  # 知识库接口
│   │   └── user.ts       # 用户接口
│   ├── assets/           # 静态资源
│   ├── components/       # 公共组件
│   │   ├── common/       # 通用组件
│   │   ├── header/       # 头部组件
│   │   └── sider/        # 侧边栏组件
│   ├── layouts/          # 布局组件
│   │   └── MainLayout.vue  # 主布局
│   ├── router/           # 路由配置
│   │   └── index.ts
│   ├── stores/           # 状态管理
│   │   ├── index.ts      # store 入口
│   │   ├── menu.ts       # 菜单状态
│   │   └── user.ts       # 用户状态
│   ├── styles/           # 全局样式
│   │   └── index.less
│   ├── utils/            # 工具函数
│   │   └── request.ts    # axios 封装
│   ├── views/            # 页面
│   │   ├── login/        # 登录页
│   │   ├── dashboard/    # 仪表盘
│   │   ├── user/         # 用户管理
│   │   ├── knowledge-base/  # 知识库管理
│   │   ├── document/     # 文档管理
│   │   └── permission/   # 权限管理
│   ├── App.vue           # 根组件
│   └── main.ts           # 入口文件
├── .env.development     # 开发环境变量
├── .env.production      # 生产环境变量
├── index.html           # HTML 模板
├── package.json
├── tsconfig.app.json
└── vite.config.ts
```

## 快速开始

### 安装依赖

```bash
cd web
npm install
```

### 开发模式

```bash
npm run dev
```

### 构建生产版本

```bash
npm run build
```

### 预览生产构建

```bash
npm run preview
```

## 功能模块

### 1. 登录页面
- 用户名/密码登录
- 记住密码功能
- 表单验证

### 2. 仪表盘
- 统计数据卡片
- 文档处理趋势图表
- 知识库分布饼图
- 最近活动列表

### 3. 用户管理
- 用户列表展示
- 用户搜索和筛选
- 新增/编辑用户
- 用户删除

### 4. 知识库管理
- 知识库列表
- 搜索功能
- 新建/编辑知识库
- 删除知识库

### 5. 文档管理
- 文档列表
- 状态筛选
- 文件上传
- 文档查看和删除

### 6. 权限管理
- 角色管理
- 权限配置
- 用户权限分配

## 配置说明

### API 代理配置

在 `vite.config.ts` 中配置代理：

```typescript
server: {
  proxy: {
    '/api': {
      target: 'http://localhost:8080',
      changeOrigin: true
    }
  }
}
```

### 环境变量

- `.env.development` - 开发环境
- `.env.production` - 生产环境

## 开发指南

### 添加新页面

1. 在 `src/views/` 下创建页面组件
2. 在 `src/router/index.ts` 中添加路由配置
3. 在侧边栏菜单中添加对应菜单项

### 添加 API 接口

1. 在 `src/api/` 下创建接口文件
2. 定义接口类型和请求方法
3. 在组件中导入使用

### 添加状态管理

1. 在 `src/stores/` 下创建 store 文件
2. 使用 `defineStore` 定义 store
3. 在组件中通过 `useXxxStore` 使用

## 注意事项

- 请在安装完依赖后运行项目
- 确保后端 API 服务已启动
- 开发环境下 API 代理到 `http://localhost:8080`
