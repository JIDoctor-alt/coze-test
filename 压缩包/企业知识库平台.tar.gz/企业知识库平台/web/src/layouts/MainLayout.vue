<template>
  <a-layout class="main-layout">
    <!-- 侧边栏 -->
    <a-layout-sider
      v-model:collapsed="menuStore.collapsed"
      :trigger="null"
      collapsible
      class="layout-sider"
    >
      <div class="logo">
        <span v-if="!menuStore.collapsed" class="logo-text">📚 知识库</span>
        <span v-if="!menuStore.collapsed" class="logo-text">知识库平台</span>
        <span v-else class="logo-text-collapsed">KB</span>
      </div>
      <a-menu
        v-model:selectedKeys="menuStore.selectedKeys"
        v-model:openKeys="menuStore.openKeys"
        theme="dark"
        mode="inline"
        @click="handleMenuClick"
      >
        <a-menu-item key="dashboard">
          <DashboardOutlined />
          <span>仪表盘</span>
        </a-menu-item>
        <a-menu-item key="user">
          <UserOutlined />
          <span>用户管理</span>
        </a-menu-item>
        <a-menu-item key="knowledge-base">
          <BookOutlined />
          <span>知识库管理</span>
        </a-menu-item>
        <a-menu-item key="document">
          <FileTextOutlined />
          <span>文档管理</span>
        </a-menu-item>
        <a-menu-item key="permission">
          <SafetyOutlined />
          <span>权限管理</span>
        </a-menu-item>
      </a-menu>
    </a-layout-sider>

    <a-layout>
      <!-- 头部 -->
      <a-layout-header class="layout-header">
        <div class="header-left">
          <MenuUnfoldOutlined v-if="menuStore.collapsed" class="trigger" @click="menuStore.toggleCollapsed" />
          <MenuFoldOutlined v-else class="trigger" @click="menuStore.toggleCollapsed" />
        </div>
        <div class="header-right">
          <a-dropdown>
            <div class="user-info">
              <a-avatar :src="userStore.userInfo?.avatar" />
              <span class="username">{{ userStore.userInfo?.username || 'Admin' }}</span>
            </div>
            <template #overlay>
              <a-menu>
                <a-menu-item key="profile">
                  <UserOutlined />
                  个人中心
                </a-menu-item>
                <a-menu-divider />
                <a-menu-item key="logout" @click="handleLogout">
                  <LogoutOutlined />
                  退出登录
                </a-menu-item>
              </a-menu>
            </template>
          </a-dropdown>
        </div>
      </a-layout-header>

      <!-- 内容区 -->
      <a-layout-content class="layout-content">
        <router-view v-slot="{ Component }">
          <transition name="fade" mode="out-in">
            <component :is="Component" />
          </transition>
        </router-view>
      </a-layout-content>
    </a-layout>
  </a-layout>
</template>

<script setup lang="ts">
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { useMenuStore } from '@/stores/menu'
import {
  MenuUnfoldOutlined,
  MenuFoldOutlined,
  DashboardOutlined,
  UserOutlined,
  BookOutlined,
  FileTextOutlined,
  SafetyOutlined,
  LogoutOutlined
} from '@ant-design/icons-vue'

const router = useRouter()
const userStore = useUserStore()
const menuStore = useMenuStore()

const handleMenuClick = ({ key }: { key: string }) => {
  router.push(`/${key}`)
}

const handleLogout = () => {
  userStore.logout()
  router.push('/login')
}
</script>

<style scoped lang="less">
.main-layout {
  min-height: 100vh;
}

.layout-sider {
  .logo {
    height: 64px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 16px;
    background: rgba(255, 255, 255, 0.1);
    
    img {
      height: 32px;
      margin-right: 8px;
    }
    
    .logo-text {
      color: #fff;
      font-size: 18px;
      font-weight: bold;
    }
    
    .logo-text-collapsed {
      color: #fff;
      font-size: 18px;
      font-weight: bold;
    }
  }
}

.layout-header {
  background: #fff;
  padding: 0 24px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1);

  .trigger {
    font-size: 18px;
    cursor: pointer;
    transition: color 0.3s;
    
    &:hover {
      color: #1890ff;
    }
  }

  .user-info {
    display: flex;
    align-items: center;
    cursor: pointer;
    
    .username {
      margin-left: 8px;
    }
  }
}

.layout-content {
  margin: 24px;
  padding: 24px;
  background: #fff;
  border-radius: 8px;
  min-height: calc(100vh - 112px);
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
