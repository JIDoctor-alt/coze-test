<template>
  <router-view />
</template>

<script setup lang="ts">
import { onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'

const router = useRouter()
const userStore = useUserStore()

onMounted(() => {
  // 路由守卫
  router.beforeEach((to, from, next) => {
    if (to.path !== '/login' && !userStore.isLoggedIn()) {
      next('/login')
    } else if (to.path === '/login' && userStore.isLoggedIn()) {
      next('/dashboard')
    } else {
      next()
    }
  })
})
</script>

<style>
#app {
  min-height: 100%;
}
</style>
