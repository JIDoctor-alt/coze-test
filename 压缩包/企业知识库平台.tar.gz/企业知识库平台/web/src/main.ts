import { createApp } from 'vue'
import Antd from 'ant-design-vue'
import 'ant-design-vue/dist/reset.css'
import App from './App.vue'
import router from './router'
import { setupStore } from './stores'
import './styles/index.less'

const app = createApp(App)

// 安装插件
app.use(Antd)
app.use(router)
setupStore(app)

app.mount('#app')
