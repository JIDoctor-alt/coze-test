import { defineStore } from 'pinia'
import { ref } from 'vue'

export interface MenuItem {
  key: string
  label: string
  icon?: string
  path?: string
  children?: MenuItem[]
}

export const useMenuStore = defineStore('menu', () => {
  const collapsed = ref<boolean>(false)
  const selectedKeys = ref<string[]>(['dashboard'])
  const openKeys = ref<string[]>([])

  const toggleCollapsed = () => {
    collapsed.value = !collapsed.value
  }

  const setSelectedKeys = (keys: string[]) => {
    selectedKeys.value = keys
  }

  const setOpenKeys = (keys: string[]) => {
    openKeys.value = keys
  }

  return {
    collapsed,
    selectedKeys,
    openKeys,
    toggleCollapsed,
    setSelectedKeys,
    setOpenKeys
  }
})
