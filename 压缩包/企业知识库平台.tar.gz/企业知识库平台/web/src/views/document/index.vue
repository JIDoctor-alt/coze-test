<template>
  <div class="document-management">
    <div class="header-actions">
      <a-space>
        <a-input-search
          v-model:value="searchKeyword"
          placeholder="搜索文档标题"
          style="width: 250px"
          @search="handleSearch"
        />
        <a-select
          v-model:value="filterStatus"
          placeholder="处理状态"
          style="width: 120px"
          allowClear
          @change="handleSearch"
        >
          <a-select-option value="pending">待处理</a-select-option>
          <a-select-option value="processing">处理中</a-select-option>
          <a-select-option value="completed">已完成</a-select-option>
          <a-select-option value="failed">失败</a-select-option>
        </a-select>
      </a-space>
      <a-space>
        <a-upload
          :before-upload="handleBeforeUpload"
          :show-upload-list="false"
        >
          <a-button type="primary">
            <template #icon><UploadOutlined /></template>
            上传文档
          </a-button>
        </a-upload>
      </a-space>
    </div>

    <a-table
      :columns="columns"
      :data-source="tableData"
      :loading="loading"
      :pagination="pagination"
      @change="handleTableChange"
      row-key="id"
      style="margin-top: 16px"
    >
      <template #bodyCell="{ column, record }">
        <template v-if="column.key === 'title'">
          <a @click="handleView(record)">{{ record.title }}</a>
        </template>
        <template v-if="column.key === 'type'">
          <a-tag :color="getTypeColor(record.type)">
            {{ record.type.toUpperCase() }}
          </a-tag>
        </template>
        <template v-if="column.key === 'status'">
          <a-badge :status="getStatusBadge(record.status)" />
          {{ getStatusText(record.status) }}
        </template>
        <template v-if="column.key === 'action'">
          <a-space>
            <a @click="handleView(record)">查看</a>
            <a-divider type="vertical" />
            <a @click="handleRetry(record)" v-if="record.status === 'failed'">重试</a>
            <a-popconfirm
              v-if="record.status !== 'processing'"
              title="确定要删除该文档吗?"
              @confirm="handleDelete(record.id)"
            >
              <a style="color: #ff4d4f">删除</a>
            </a-popconfirm>
          </a-space>
        </template>
      </template>
    </a-table>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { message } from 'ant-design-vue'
import { UploadOutlined } from '@ant-design/icons-vue'
import type { UploadProps } from 'ant-design-vue'

interface Document {
  id: string
  title: string
  knowledgeBaseId: string
  knowledgeBaseName: string
  type: string
  size: number
  status: 'pending' | 'processing' | 'completed' | 'failed'
  createTime: string
}

const loading = ref(false)
const searchKeyword = ref('')
const filterStatus = ref<string>()

const pagination = reactive({
  current: 1,
  pageSize: 10,
  total: 0
})

const columns = [
  { title: 'ID', dataIndex: 'id', key: 'id', width: 80 },
  { title: '标题', dataIndex: 'title', key: 'title' },
  { title: '所属知识库', dataIndex: 'knowledgeBaseName', key: 'knowledgeBaseName', width: 150 },
  { title: '类型', key: 'type', width: 80 },
  { title: '大小', dataIndex: 'size', key: 'size', width: 100 },
  { title: '状态', key: 'status', width: 100 },
  { title: '创建时间', dataIndex: 'createTime', key: 'createTime', width: 180 },
  { title: '操作', key: 'action', width: 150 }
]

const tableData = ref<Document[]>([])

const getTypeColor = (type: string) => {
  const colors: Record<string, string> = {
    pdf: 'red',
    docx: 'blue',
    txt: 'green',
    xlsx: 'orange'
  }
  return colors[type.toLowerCase()] || 'default'
}

const getStatusBadge = (status: string) => {
  const badges: Record<string, string> = {
    pending: 'default',
    processing: 'processing',
    completed: 'success',
    failed: 'error'
  }
  return badges[status] || 'default'
}

const getStatusText = (status: string) => {
  const texts: Record<string, string> = {
    pending: '待处理',
    processing: '处理中',
    completed: '已完成',
    failed: '失败'
  }
  return texts[status] || status
}

const formatSize = (bytes: number) => {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB'
  return (bytes / (1024 * 1024)).toFixed(2) + ' MB'
}

const fetchData = () => {
  loading.value = true
  setTimeout(() => {
    tableData.value = [
      { id: '1', title: '产品手册.pdf', knowledgeBaseId: '1', knowledgeBaseName: '产品知识库', type: 'pdf', size: 2048576, status: 'completed', createTime: '2024-01-15 10:30' },
      { id: '2', title: '技术规范.docx', knowledgeBaseId: '2', knowledgeBaseName: '技术文档库', type: 'docx', size: 512000, status: 'processing', createTime: '2024-01-15 09:15' },
      { id: '3', title: '培训资料.txt', knowledgeBaseId: '3', knowledgeBaseName: '培训资料库', type: 'txt', size: 102400, status: 'pending', createTime: '2024-01-14 16:45' },
      { id: '4', title: '数据报表.xlsx', knowledgeBaseId: '1', knowledgeBaseName: '产品知识库', type: 'xlsx', size: 307200, status: 'failed', createTime: '2024-01-14 14:20' }
    ]
    // 更新显示大小
    tableData.value.forEach(item => {
      item.size = formatSize(item.size) as any
    })
    pagination.total = 4
    loading.value = false
  }, 500)
}

const handleSearch = () => {
  pagination.current = 1
  fetchData()
}

const handleTableChange = (pag: any) => {
  pagination.current = pag.current
  pagination.pageSize = pag.pageSize
  fetchData()
}

const handleBeforeUpload: UploadProps['beforeUpload'] = (file) => {
  message.success(`上传文件: ${file.name}`)
  return false
}

const handleView = (record: Document) => {
  message.info(`查看文档: ${record.title}`)
}

const handleRetry = (record: Document) => {
  message.success(`重试处理: ${record.title}`)
  fetchData()
}

const handleDelete = (id: string) => {
  message.success('删除成功')
  fetchData()
}

onMounted(() => {
  fetchData()
})
</script>

<style scoped lang="less">
.document-management {
  .header-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
}
</style>
