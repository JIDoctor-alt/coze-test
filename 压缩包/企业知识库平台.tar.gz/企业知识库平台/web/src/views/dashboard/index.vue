<template>
  <div class="dashboard">
    <a-row :gutter="[16, 16]">
      <a-col :xs="24" :sm="12" :md="6" v-for="item in statCards" :key="item.key">
        <a-card :bordered="false" class="stat-card">
          <div class="stat-content">
            <div class="stat-info">
              <p class="stat-title">{{ item.title }}</p>
              <p class="stat-value">{{ item.value }}</p>
            </div>
            <div class="stat-icon" :style="{ background: item.color }">
              <component :is="item.icon" />
            </div>
          </div>
        </a-card>
      </a-col>
    </a-row>

    <a-row :gutter="[16, 16]" style="margin-top: 16px">
      <a-col :xs="24" :lg="16">
        <a-card title="文档处理趋势" :bordered="false">
          <div ref="chartRef" class="chart-container"></div>
        </a-card>
      </a-col>
      <a-col :xs="24" :lg="8">
        <a-card title="知识库分布" :bordered="false">
          <div ref="pieChartRef" class="chart-container"></div>
        </a-card>
      </a-col>
    </a-row>

    <a-row :gutter="[16, 16]" style="margin-top: 16px">
      <a-col :xs="24">
        <a-card title="最近活动" :bordered="false">
          <a-table
            :columns="columns"
            :data-source="recentActivities"
            :pagination="false"
          >
            <template #bodyCell="{ column, record }">
              <template v-if="column.key === 'status'">
                <a-tag :color="getStatusColor(record.status)">
                  {{ getStatusText(record.status) }}
                </a-tag>
              </template>
            </template>
          </a-table>
        </a-card>
      </a-col>
    </a-row>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, h } from 'vue'
import {
  UserOutlined,
  FileTextOutlined,
  BookOutlined,
  TeamOutlined
} from '@ant-design/icons-vue'

const chartRef = ref<HTMLElement>()
const pieChartRef = ref<HTMLElement>()

const statCards = ref([
  { key: 'users', title: '用户总数', value: '1,234', icon: UserOutlined, color: '#1890ff' },
  { key: 'documents', title: '文档总数', value: '5,678', icon: FileTextOutlined, color: '#52c41a' },
  { key: 'knowledge', title: '知识库数量', value: '89', icon: BookOutlined, color: '#faad14' },
  { key: 'active', title: '在线用户', value: '156', icon: TeamOutlined, color: '#f5222d' }
])

const columns = [
  { title: '操作人', dataIndex: 'operator', key: 'operator' },
  { title: '操作类型', dataIndex: 'action', key: 'action' },
  { title: '对象', dataIndex: 'target', key: 'target' },
  { title: '时间', dataIndex: 'time', key: 'time' },
  { title: '状态', key: 'status' }
]

const recentActivities = ref([
  { key: '1', operator: '张三', action: '上传文档', target: '产品手册.pdf', time: '2024-01-15 10:30', status: 'completed' },
  { key: '2', operator: '李四', action: '创建知识库', target: '技术文档库', time: '2024-01-15 09:15', status: 'completed' },
  { key: '3', operator: '王五', action: '删除文档', target: '旧版本.docx', time: '2024-01-14 16:45', status: 'completed' },
  { key: '4', operator: '赵六', action: '编辑权限', target: '财务知识库', time: '2024-01-14 14:20', status: 'pending' }
])

const getStatusColor = (status: string) => {
  const colors: Record<string, string> = {
    completed: 'green',
    pending: 'orange',
    failed: 'red'
  }
  return colors[status] || 'default'
}

const getStatusText = (status: string) => {
  const texts: Record<string, string> = {
    completed: '已完成',
    pending: '处理中',
    failed: '失败'
  }
  return texts[status] || status
}

onMounted(() => {
  // 图表渲染逻辑可以后续集成 echarts
})
</script>

<style scoped lang="less">
.dashboard {
  .stat-card {
    .stat-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
      
      .stat-info {
        .stat-title {
          color: #999;
          font-size: 14px;
          margin-bottom: 8px;
        }
        
        .stat-value {
          font-size: 24px;
          font-weight: bold;
          color: #333;
        }
      }
      
      .stat-icon {
        width: 56px;
        height: 56px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        
        :deep(.anticon) {
          font-size: 28px;
          color: #fff;
        }
      }
    }
  }
  
  .chart-container {
    height: 300px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #999;
  }
}
</style>
