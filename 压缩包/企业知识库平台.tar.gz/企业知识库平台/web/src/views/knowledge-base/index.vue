<template>
  <div class="knowledge-base-management">
    <div class="header-actions">
      <a-space>
        <a-input-search
          v-model:value="searchKeyword"
          placeholder="搜索知识库名称"
          style="width: 250px"
          @search="handleSearch"
        />
      </a-space>
      <a-button type="primary" @click="handleAdd">
        <template #icon><PlusOutlined /></template>
        新建知识库
      </a-button>
    </div>

    <a-table
      :columns="columns"
      :data-source="tableData"
      :loading="loading"
      :pagination="pagination"
      @change="handleTableChange"
      row-key="id"
      style="margin-top: 16px"
    >
      <template #bodyCell="{ column, record }">
        <template v-if="column.key === 'status'">
          <a-tag :color="record.status === 'active' ? 'green' : 'red'">
            {{ record.status === 'active' ? '启用' : '禁用' }}
          </a-tag>
        </template>
        <template v-if="column.key === 'action'">
          <a-space>
            <a @click="handleView(record)">查看</a>
            <a-divider type="vertical" />
            <a @click="handleEdit(record)">编辑</a>
            <a-divider type="vertical" />
            <a-popconfirm
              title="确定要删除该知识库吗?"
              @confirm="handleDelete(record.id)"
            >
              <a style="color: #ff4d4f">删除</a>
            </a-popconfirm>
          </a-space>
        </template>
      </template>
    </a-table>

    <a-modal
      v-model:open="modalVisible"
      :title="isEdit ? '编辑知识库' : '新建知识库'"
      @ok="handleSubmit"
      @cancel="handleCancel"
      width="600px"
    >
      <a-form
        ref="formRef"
        :model="formState"
        :label-col="{ span: 6 }"
        :wrapper-col="{ span: 16 }"
      >
        <a-form-item label="知识库名称" name="name" :rules="[{ required: true, message: '请输入知识库名称' }]">
          <a-input v-model:value="formState.name" placeholder="请输入知识库名称" />
        </a-form-item>
        <a-form-item label="描述" name="description">
          <a-textarea v-model:value="formState.description" placeholder="请输入描述" :rows="4" />
        </a-form-item>
        <a-form-item label="状态" name="status">
          <a-switch v-model:checked="formState.status" checked-children="启用" un-checked-children="禁用" />
        </a-form-item>
      </a-form>
    </a-modal>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { message } from 'ant-design-vue'
import { PlusOutlined } from '@ant-design/icons-vue'

interface KnowledgeBase {
  id: string
  name: string
  description: string
  documentCount: number
  status: 'active' | 'inactive'
  createTime: string
  updateTime: string
}

const loading = ref(false)
const searchKeyword = ref('')
const modalVisible = ref(false)
const isEdit = ref(false)
const formRef = ref()

const formState = reactive<Partial<KnowledgeBase>>({
  name: '',
  description: '',
  status: 'active'
})

const pagination = reactive({
  current: 1,
  pageSize: 10,
  total: 0
})

const columns = [
  { title: 'ID', dataIndex: 'id', key: 'id', width: 80 },
  { title: '名称', dataIndex: 'name', key: 'name' },
  { title: '描述', dataIndex: 'description', key: 'description', ellipsis: true },
  { title: '文档数', dataIndex: 'documentCount', key: 'documentCount', width: 100 },
  { title: '状态', key: 'status', width: 100 },
  { title: '创建时间', dataIndex: 'createTime', key: 'createTime', width: 180 },
  { title: '操作', key: 'action', width: 180 }
]

const tableData = ref<KnowledgeBase[]>([])

const fetchData = () => {
  loading.value = true
  setTimeout(() => {
    tableData.value = [
      { id: '1', name: '产品知识库', description: '公司产品相关文档', documentCount: 120, status: 'active', createTime: '2024-01-01', updateTime: '2024-01-15' },
      { id: '2', name: '技术文档库', description: '技术文档和规范', documentCount: 85, status: 'active', createTime: '2024-01-05', updateTime: '2024-01-14' },
      { id: '3', name: '培训资料库', description: '员工培训资料', documentCount: 45, status: 'inactive', createTime: '2023-12-20', updateTime: '2024-01-10' }
    ]
    pagination.total = 3
    loading.value = false
  }, 500)
}

const handleSearch = () => {
  pagination.current = 1
  fetchData()
}

const handleTableChange = (pag: any) => {
  pagination.current = pag.current
  pagination.pageSize = pag.pageSize
  fetchData()
}

const handleAdd = () => {
  isEdit.value = false
  Object.assign(formState, { name: '', description: '', status: 'active' })
  modalVisible.value = true
}

const handleView = (record: KnowledgeBase) => {
  message.info(`查看知识库: ${record.name}`)
}

const handleEdit = (record: KnowledgeBase) => {
  isEdit.value = true
  Object.assign(formState, record)
  modalVisible.value = true
}

const handleSubmit = async () => {
  try {
    await formRef.value.validate()
    message.success(isEdit.value ? '编辑成功' : '创建成功')
    modalVisible.value = false
    fetchData()
  } catch (error) {
    console.error(error)
  }
}

const handleCancel = () => {
  modalVisible.value = false
  formRef.value?.resetFields()
}

const handleDelete = (id: string) => {
  message.success('删除成功')
  fetchData()
}

onMounted(() => {
  fetchData()
})
</script>

<style scoped lang="less">
.knowledge-base-management {
  .header-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
}
</style>
