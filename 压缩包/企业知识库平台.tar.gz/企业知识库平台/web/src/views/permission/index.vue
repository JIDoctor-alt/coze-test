<template>
  <div class="permission-management">
    <a-tabs v-model:activeKey="activeTab">
      <a-tab-pane key="roles" tab="角色管理">
        <div class="tab-header">
          <a-button type="primary" @click="handleAddRole">
            <template #icon><PlusOutlined /></template>
            新增角色
          </a-button>
        </div>
        <a-table
          :columns="roleColumns"
          :data-source="roles"
          :loading="loading"
          row-key="id"
          style="margin-top: 16px"
        >
          <template #bodyCell="{ column, record }">
            <template v-if="column.key === 'permissions'">
              <a-tag v-for="perm in record.permissions.slice(0, 3)" :key="perm" color="blue">
                {{ perm }}
              </a-tag>
              <a-tag v-if="record.permissions.length > 3">+{{ record.permissions.length - 3 }}</a-tag>
            </template>
            <template v-if="column.key === 'action'">
              <a-space>
                <a @click="handleEditRole(record)">编辑</a>
                <a-divider type="vertical" />
                <a @click="handleConfigPermission(record)">配置权限</a>
              </a-space>
            </template>
          </template>
        </a-table>
      </a-tab-pane>

      <a-tab-pane key="permissions" tab="权限配置">
        <a-card title="权限树" :bordered="false">
          <a-tree
            v-model:selectedKeys="selectedKeys"
            v-model:checkedKeys="checkedKeys"
            checkable
            :tree-data="permissionTree"
          />
        </a-card>
      </a-tab-pane>

      <a-tab-pane key="users" tab="用户权限">
        <a-table
          :columns="userPermColumns"
          :data-source="userPermissions"
          :loading="loading"
          row-key="id"
          style="margin-top: 16px"
        >
          <template #bodyCell="{ column, record }">
            <template v-if="column.key === 'roles'">
              <a-tag v-for="role in record.roles" :key="role" color="green">
                {{ role }}
              </a-tag>
            </template>
            <template v-if="column.key === 'action'">
              <a @click="handleEditUserPermission(record)">编辑权限</a>
            </template>
          </template>
        </a-table>
      </a-tab-pane>
    </a-tabs>

    <a-modal
      v-model:open="modalVisible"
      :title="isEditRole ? '编辑角色' : '新增角色'"
      @ok="handleSubmitRole"
      @cancel="handleCancelRole"
    >
      <a-form
        ref="roleFormRef"
        :model="roleFormState"
        :label-col="{ span: 6 }"
        :wrapper-col="{ span: 16 }"
      >
        <a-form-item label="角色名称" name="name" :rules="[{ required: true }]">
          <a-input v-model:value="roleFormState.name" placeholder="请输入角色名称" />
        </a-form-item>
        <a-form-item label="角色描述" name="description">
          <a-input v-model:value="roleFormState.description" placeholder="请输入角色描述" />
        </a-form-item>
      </a-form>
    </a-modal>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { message } from 'ant-design-vue'
import { PlusOutlined } from '@ant-design/icons-vue'

interface Role {
  id: string
  name: string
  description: string
  permissions: string[]
  userCount: number
}

interface UserPermission {
  id: string
  username: string
  email: string
  roles: string[]
  lastLogin: string
}

const activeTab = ref('roles')
const loading = ref(false)
const modalVisible = ref(false)
const isEditRole = ref(false)
const roleFormRef = ref()
const selectedKeys = ref<string[]>([])
const checkedKeys = ref<string[]>([])

const roleFormState = reactive({
  name: '',
  description: ''
})

const roleColumns = [
  { title: '角色ID', dataIndex: 'id', key: 'id', width: 100 },
  { title: '角色名称', dataIndex: 'name', key: 'name' },
  { title: '描述', dataIndex: 'description', key: 'description' },
  { title: '权限', key: 'permissions' },
  { title: '用户数', dataIndex: 'userCount', key: 'userCount', width: 100 },
  { title: '操作', key: 'action', width: 180 }
]

const userPermColumns = [
  { title: '用户名', dataIndex: 'username', key: 'username' },
  { title: '邮箱', dataIndex: 'email', key: 'email' },
  { title: '角色', key: 'roles' },
  { title: '最后登录', dataIndex: 'lastLogin', key: 'lastLogin' },
  { title: '操作', key: 'action', width: 120 }
]

const roles = ref<Role[]>([])
const userPermissions = ref<UserPermission[]>([])

const permissionTree = ref([
  {
    title: '系统管理',
    key: 'system',
    children: [
      { title: '用户管理', key: 'system:user' },
      { title: '角色管理', key: 'system:role' },
      { title: '权限管理', key: 'system:permission' }
    ]
  },
  {
    title: '知识库管理',
    key: 'knowledge',
    children: [
      { title: '查看知识库', key: 'knowledge:view' },
      { title: '创建知识库', key: 'knowledge:create' },
      { title: '编辑知识库', key: 'knowledge:edit' },
      { title: '删除知识库', key: 'knowledge:delete' }
    ]
  },
  {
    title: '文档管理',
    key: 'document',
    children: [
      { title: '上传文档', key: 'document:upload' },
      { title: '下载文档', key: 'document:download' },
      { title: '删除文档', key: 'document:delete' }
    ]
  }
])

const fetchRoles = () => {
  loading.value = true
  setTimeout(() => {
    roles.value = [
      { id: '1', name: '超级管理员', description: '拥有系统所有权限', permissions: ['system:user', 'system:role', 'system:permission', 'knowledge:view', 'knowledge:create', 'knowledge:edit', 'knowledge:delete', 'document:upload', 'document:download', 'document:delete'], userCount: 2 },
      { id: '2', name: '知识库管理员', description: '管理知识库和文档', permissions: ['knowledge:view', 'knowledge:create', 'knowledge:edit', 'document:upload', 'document:download'], userCount: 5 },
      { id: '3', name: '普通用户', description: '查看和下载文档', permissions: ['knowledge:view', 'document:download'], userCount: 20 }
    ]
    loading.value = false
  }, 500)
}

const fetchUserPermissions = () => {
  loading.value = true
  setTimeout(() => {
    userPermissions.value = [
      { id: '1', username: 'admin', email: 'admin@example.com', roles: ['超级管理员'], lastLogin: '2024-01-15 10:30' },
      { id: '2', username: 'user1', email: 'user1@example.com', roles: ['知识库管理员'], lastLogin: '2024-01-14 16:45' },
      { id: '3', username: 'user2', email: 'user2@example.com', roles: ['普通用户'], lastLogin: '2024-01-13 09:20' }
    ]
    loading.value = false
  }, 500)
}

const handleAddRole = () => {
  isEditRole.value = false
  Object.assign(roleFormState, { name: '', description: '' })
  modalVisible.value = true
}

const handleEditRole = (record: Role) => {
  isEditRole.value = true
  Object.assign(roleFormState, record)
  modalVisible.value = true
}

const handleConfigPermission = (record: Role) => {
  activeTab.value = 'permissions'
  checkedKeys.value = record.permissions
}

const handleSubmitRole = async () => {
  try {
    await roleFormRef.value.validate()
    message.success(isEditRole.value ? '编辑成功' : '创建成功')
    modalVisible.value = false
    fetchRoles()
  } catch (error) {
    console.error(error)
  }
}

const handleCancelRole = () => {
  modalVisible.value = false
  roleFormRef.value?.resetFields()
}

const handleEditUserPermission = (record: UserPermission) => {
  message.info(`编辑用户权限: ${record.username}`)
}

onMounted(() => {
  fetchRoles()
  fetchUserPermissions()
})
</script>

<style scoped lang="less">
.permission-management {
  .tab-header {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 16px;
  }
}
</style>
