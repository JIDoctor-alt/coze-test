<template>
  <div class="user-management">
    <div class="header-actions">
      <a-space>
        <a-input-search
          v-model:value="searchKeyword"
          placeholder="搜索用户名或邮箱"
          style="width: 250px"
          @search="handleSearch"
        />
        <a-select
          v-model:value="filterRole"
          placeholder="选择角色"
          style="width: 120px"
          allowClear
          @change="handleSearch"
        >
          <a-select-option value="admin">管理员</a-select-option>
          <a-select-option value="user">普通用户</a-select-option>
          <a-select-option value="guest">访客</a-select-option>
        </a-select>
        <a-select
          v-model:value="filterStatus"
          placeholder="选择状态"
          style="width: 120px"
          allowClear
          @change="handleSearch"
        >
          <a-select-option value="active">启用</a-select-option>
          <a-select-option value="inactive">禁用</a-select-option>
        </a-select>
      </a-space>
      <a-button type="primary" @click="handleAdd">
        <template #icon><PlusOutlined /></template>
        新增用户
      </a-button>
    </div>

    <a-table
      :columns="columns"
      :data-source="tableData"
      :loading="loading"
      :pagination="pagination"
      @change="handleTableChange"
      row-key="id"
      style="margin-top: 16px"
    >
      <template #bodyCell="{ column, record }">
        <template v-if="column.key === 'avatar'">
          <a-avatar :src="record.avatar" :size="40">
            {{ record.username?.charAt(0).toUpperCase() }}
          </a-avatar>
        </template>
        <template v-if="column.key === 'role'">
          <a-tag :color="getRoleColor(record.role)">
            {{ getRoleText(record.role) }}
          </a-tag>
        </template>
        <template v-if="column.key === 'status'">
          <a-badge :status="record.status === 'active' ? 'success' : 'default'" />
          {{ record.status === 'active' ? '启用' : '禁用' }}
        </template>
        <template v-if="column.key === 'action'">
          <a-space>
            <a @click="handleEdit(record)">编辑</a>
            <a-divider type="vertical" />
            <a-popconfirm
              title="确定要删除该用户吗?"
              @confirm="handleDelete(record.id)"
            >
              <a style="color: #ff4d4f">删除</a>
            </a-popconfirm>
          </a-space>
        </template>
      </template>
    </a-table>

    <a-modal
      v-model:open="modalVisible"
      :title="isEdit ? '编辑用户' : '新增用户'"
      @ok="handleSubmit"
      @cancel="handleCancel"
    >
      <a-form
        ref="formRef"
        :model="formState"
        :label-col="{ span: 6 }"
        :wrapper-col="{ span: 16 }"
      >
        <a-form-item label="用户名" name="username" :rules="[{ required: true }]">
          <a-input v-model:value="formState.username" placeholder="请输入用户名" />
        </a-form-item>
        <a-form-item label="邮箱" name="email" :rules="[{ required: true, type: 'email' }]">
          <a-input v-model:value="formState.email" placeholder="请输入邮箱" />
        </a-form-item>
        <a-form-item label="角色" name="role" :rules="[{ required: true }]">
          <a-select v-model:value="formState.role" placeholder="请选择角色">
            <a-select-option value="admin">管理员</a-select-option>
            <a-select-option value="user">普通用户</a-select-option>
            <a-select-option value="guest">访客</a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item label="状态" name="status">
          <a-switch v-model:checked="formState.status" checked-children="启用" un-checked-children="禁用" />
        </a-form-item>
      </a-form>
    </a-modal>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { message } from 'ant-design-vue'
import { PlusOutlined } from '@ant-design/icons-vue'

interface User {
  id: string
  username: string
  email: string
  avatar?: string
  role: 'admin' | 'user' | 'guest'
  status: 'active' | 'inactive'
  createTime: string
}

const loading = ref(false)
const searchKeyword = ref('')
const filterRole = ref<string>()
const filterStatus = ref<string>()
const modalVisible = ref(false)
const isEdit = ref(false)
const formRef = ref()

const formState = reactive<Partial<User>>({
  username: '',
  email: '',
  role: 'user',
  status: 'active'
})

const pagination = reactive({
  current: 1,
  pageSize: 10,
  total: 0
})

const columns = [
  { title: '头像', key: 'avatar', width: 80 },
  { title: '用户名', dataIndex: 'username', key: 'username' },
  { title: '邮箱', dataIndex: 'email', key: 'email' },
  { title: '角色', key: 'role', width: 100 },
  { title: '状态', key: 'status', width: 100 },
  { title: '创建时间', dataIndex: 'createTime', key: 'createTime' },
  { title: '操作', key: 'action', width: 150 }
]

const tableData = ref<User[]>([])

const getRoleColor = (role: string) => {
  const colors: Record<string, string> = {
    admin: 'red',
    user: 'blue',
    guest: 'gray'
  }
  return colors[role] || 'default'
}

const getRoleText = (role: string) => {
  const texts: Record<string, string> = {
    admin: '管理员',
    user: '普通用户',
    guest: '访客'
  }
  return texts[role] || role
}

const fetchData = () => {
  loading.value = true
  // 模拟数据
  setTimeout(() => {
    tableData.value = [
      { id: '1', username: 'admin', email: 'admin@example.com', role: 'admin', status: 'active', createTime: '2024-01-01' },
      { id: '2', username: 'user1', email: 'user1@example.com', role: 'user', status: 'active', createTime: '2024-01-10' },
      { id: '3', username: 'guest1', email: 'guest@example.com', role: 'guest', status: 'inactive', createTime: '2024-01-12' }
    ]
    pagination.total = 3
    loading.value = false
  }, 500)
}

const handleSearch = () => {
  pagination.current = 1
  fetchData()
}

const handleTableChange = (pag: any) => {
  pagination.current = pag.current
  pagination.pageSize = pag.pageSize
  fetchData()
}

const handleAdd = () => {
  isEdit.value = false
  Object.assign(formState, { username: '', email: '', role: 'user', status: 'active' })
  modalVisible.value = true
}

const handleEdit = (record: User) => {
  isEdit.value = true
  Object.assign(formState, record)
  modalVisible.value = true
}

const handleSubmit = async () => {
  try {
    await formRef.value.validate()
    message.success(isEdit.value ? '编辑成功' : '新增成功')
    modalVisible.value = false
    fetchData()
  } catch (error) {
    console.error(error)
  }
}

const handleCancel = () => {
  modalVisible.value = false
  formRef.value?.resetFields()
}

const handleDelete = (id: string) => {
  message.success('删除成功')
  fetchData()
}

onMounted(() => {
  fetchData()
})
</script>

<style scoped lang="less">
.user-management {
  .header-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
}
</style>
