import { request } from './request'

export interface User {
  id: string
  username: string
  email: string
  role: 'admin' | 'user' | 'guest'
  status: 'active' | 'inactive'
  createTime: string
  lastLoginTime?: string
}

export interface UserListParams {
  page: number
  pageSize: number
  keyword?: string
  role?: string
  status?: string
}

export const userApi = {
  getUserList: (params: UserListParams) => request.get<{ list: User[]; total: number }>('/users', { params }),
  getUser: (id: string) => request.get<User>(`/users/${id}`),
  createUser: (data: Partial<User>) => request.post<User>('/users', data),
  updateUser: (id: string, data: Partial<User>) => request.put<User>(`/users/${id}`, data),
  deleteUser: (id: string) => request.delete(`/users/${id}`)
}
