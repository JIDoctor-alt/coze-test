import { request } from './request'

export interface LoginParams {
  username: string
  password: string
}

export interface LoginResult {
  token: string
  userInfo: {
    id: string
    username: string
    email: string
    avatar?: string
    role: string
  }
}

export const loginApi = {
  login: (params: LoginParams) => request.post<LoginResult>('/auth/login', params),
  logout: () => request.post('/auth/logout'),
  getUserInfo: () => request.get<LoginResult['userInfo']>('/auth/userinfo')
}
