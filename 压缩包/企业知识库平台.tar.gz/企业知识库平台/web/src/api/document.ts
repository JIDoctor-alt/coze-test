import { request } from './request'

export interface Document {
  id: string
  title: string
  knowledgeBaseId: string
  knowledgeBaseName: string
  type: string
  size: number
  status: 'pending' | 'processing' | 'completed' | 'failed'
  createTime: string
  updateTime: string
}

export interface DocumentListParams {
  page: number
  pageSize: number
  keyword?: string
  knowledgeBaseId?: string
  status?: string
}

export const documentApi = {
  getList: (params: DocumentListParams) => 
    request.get<{ list: Document[]; total: number }>('/documents', { params }),
  getById: (id: string) => request.get<Document>(`/documents/${id}`),
  create: (data: Partial<Document>) => request.post<Document>('/documents', data),
  update: (id: string, data: Partial<Document>) => 
    request.put<Document>(`/documents/${id}`, data),
  delete: (id: string) => request.delete(`/documents/${id}`),
  upload: (formData: FormData) => request.post<Document>('/documents/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })
}
