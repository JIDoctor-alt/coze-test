import { request } from './request'

export interface KnowledgeBase {
  id: string
  name: string
  description: string
  documentCount: number
  status: 'active' | 'inactive'
  createTime: string
  updateTime: string
}

export interface KnowledgeBaseListParams {
  page: number
  pageSize: number
  keyword?: string
}

export const knowledgeBaseApi = {
  getList: (params: KnowledgeBaseListParams) => 
    request.get<{ list: KnowledgeBase[]; total: number }>('/knowledge-bases', { params }),
  getById: (id: string) => request.get<KnowledgeBase>(`/knowledge-bases/${id}`),
  create: (data: Partial<KnowledgeBase>) => request.post<KnowledgeBase>('/knowledge-bases', data),
  update: (id: string, data: Partial<KnowledgeBase>) => 
    request.put<KnowledgeBase>(`/knowledge-bases/${id}`, data),
  delete: (id: string) => request.delete(`/knowledge-bases/${id}`)
}
