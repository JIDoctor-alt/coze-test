-- =============================================================================
-- 企业知识库平台 - 数据库初始化脚本
-- 版本: 1.0.0
-- 描述: 基于权限体系与数据隔离设计文档创建完整的数据库表结构
-- 兼容: MySQL 5.7+ / PostgreSQL 12+
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 第一部分：设置字符集和数据库
-- -----------------------------------------------------------------------------

-- MySQL: 创建数据库（如果使用PostgreSQL请注释此部分）
CREATE DATABASE IF NOT EXISTS `enterprise_knowledge_base`
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_unicode_ci;

USE `enterprise_knowledge_base`;

-- -----------------------------------------------------------------------------
-- 第二部分：系统管理表
-- -----------------------------------------------------------------------------

-- 2.1 租户表 (sys_tenant)
-- 用于多租户隔离，每个租户代表一个独立的企业/组织
CREATE TABLE IF NOT EXISTS `sys_tenant` (
    `id` VARCHAR(64) NOT NULL COMMENT '租户ID(UUID)',
    `name` VARCHAR(128) NOT NULL COMMENT '租户名称',
    `code` VARCHAR(64) NOT NULL UNIQUE COMMENT '租户编码(唯一标识)',
    `isolation_level` TINYINT DEFAULT 1 COMMENT '隔离级别:1-逻辑隔离(共享Schema),2-Schema隔离,3-数据库隔离',
    `logo_url` VARCHAR(512) COMMENT '租户Logo地址',
    `contact_name` VARCHAR(64) COMMENT '联系人姓名',
    `contact_email` VARCHAR(128) COMMENT '联系人邮箱',
    `contact_phone` VARCHAR(20) COMMENT '联系人电话',
    `status` TINYINT DEFAULT 1 COMMENT '状态:0-禁用,1-正常,2-试用,3-过期',
    `expire_time` DATETIME COMMENT '过期时间(NULL表示永不过期)',
    `max_users` INT DEFAULT 100 COMMENT '最大用户数',
    `max_kb_count` INT DEFAULT 50 COMMENT '最大知识库数量',
    `max_storage_bytes` BIGINT DEFAULT 10737418240 COMMENT '最大存储空间(字节),默认10GB',
    `used_storage_bytes` BIGINT DEFAULT 0 COMMENT '已使用存储空间(字节)',
    `config` JSON COMMENT '租户扩展配置(JSON格式)',
    `description` VARCHAR(512) COMMENT '租户描述',
    `create_by` VARCHAR(64) COMMENT '创建者',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_by` VARCHAR(64) COMMENT '更新者',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_code` (`code`),
    KEY `idx_status` (`status`),
    KEY `idx_expire_time` (`expire_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='租户表 - 用于多租户隔离';

-- 2.2 用户表 (sys_user)
-- 存储平台所有用户信息，关联租户和部门
CREATE TABLE IF NOT EXISTS `sys_user` (
    `id` VARCHAR(64) NOT NULL COMMENT '用户ID(UUID)',
    `username` VARCHAR(64) NOT NULL COMMENT '用户名(登录名)',
    `password` VARCHAR(256) NOT NULL COMMENT '密码(加密存储,建议使用BCrypt)',
    `password_salt` VARCHAR(64) COMMENT '密码盐值',
    `real_name` VARCHAR(64) COMMENT '真实姓名',
    `nickname` VARCHAR(64) COMMENT '昵称',
    `email` VARCHAR(128) COMMENT '邮箱地址',
    `phone` VARCHAR(20) COMMENT '手机号码',
    `avatar` VARCHAR(512) COMMENT '头像URL',
    `gender` TINYINT DEFAULT 0 COMMENT '性别:0-未知,1-男,2-女',
    `birthday` DATE COMMENT '生日',
    `tenant_id` VARCHAR(64) NOT NULL COMMENT '所属租户ID',
    `dept_id` VARCHAR(64) COMMENT '所属部门ID',
    `position` VARCHAR(64) COMMENT '职位',
    `status` TINYINT DEFAULT 1 COMMENT '账号状态:0-禁用,1-正常,2-锁定,3-待激活',
    `user_type` TINYINT DEFAULT 1 COMMENT '用户类型:1-普通用户,2-管理员,3-超级管理员',
    `login_ip` VARCHAR(128) COMMENT '最后登录IP',
    `login_date` DATETIME COMMENT '最后登录时间',
    `login_count` INT DEFAULT 0 COMMENT '登录次数',
    `password_expire_time` DATETIME COMMENT '密码过期时间',
    `password_error_count` INT DEFAULT 0 COMMENT '密码错误次数',
    `lock_expire_time` DATETIME COMMENT '账号锁定过期时间',
    `last_active_time` DATETIME COMMENT '最后活跃时间',
    `source` VARCHAR(32) DEFAULT 'manual' COMMENT '用户来源:manual-手动创建,ldap-LDAP同步,oauth-OAuth授权,sso-SSO单点登录',
    `external_id` VARCHAR(128) COMMENT '外部系统ID(用于LDAP/OAuth同步)',
    `attrs` JSON COMMENT '扩展属性(JSON格式)',
    `create_by` VARCHAR(64) COMMENT '创建者',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_by` VARCHAR(64) COMMENT '更新者',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` TINYINT DEFAULT 0 COMMENT '软删除标记:0-未删除,1-已删除',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_tenant_username` (`tenant_id`, `username`),
    KEY `idx_tenant_id` (`tenant_id`),
    KEY `idx_dept_id` (`dept_id`),
    KEY `idx_email` (`email`),
    KEY `idx_phone` (`phone`),
    KEY `idx_status` (`status`),
    KEY `idx_create_time` (`create_time`),
    KEY `idx_external_id` (`external_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户表';

-- 2.3 部门表 (sys_department)
-- 组织架构树形结构，支持多级部门
CREATE TABLE IF NOT EXISTS `sys_department` (
    `id` VARCHAR(64) NOT NULL COMMENT '部门ID(UUID)',
    `dept_name` VARCHAR(64) NOT NULL COMMENT '部门名称',
    `dept_code` VARCHAR(64) COMMENT '部门编码',
    `parent_id` VARCHAR(64) COMMENT '父部门ID',
    `parent_ids` VARCHAR(512) COMMENT '父部门ID链(格式: /1/2/3/)',
    `level` INT DEFAULT 1 COMMENT '部门层级(1为顶级)',
    `order_num` INT DEFAULT 0 COMMENT '排序号(同级部门排序)',
    `leader_id` VARCHAR(64) COMMENT '部门负责人用户ID',
    `leader_name` VARCHAR(64) COMMENT '部门负责人姓名',
    `contact_phone` VARCHAR(20) COMMENT '部门联系电话',
    `contact_email` VARCHAR(128) COMMENT '部门联系邮箱',
    `tenant_id` VARCHAR(64) NOT NULL COMMENT '所属租户ID',
    `status` TINYINT DEFAULT 1 COMMENT '状态:0-禁用,1-正常',
    `is_hidden` TINYINT DEFAULT 0 COMMENT '是否隐藏:0-否,1-是(隐藏后用户不可见)',
    `attrs` JSON COMMENT '扩展属性',
    `create_by` VARCHAR(64) COMMENT '创建者',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_by` VARCHAR(64) COMMENT '更新者',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` TINYINT DEFAULT 0 COMMENT '软删除标记:0-未删除,1-已删除',
    PRIMARY KEY (`id`),
    KEY `idx_tenant_id` (`tenant_id`),
    KEY `idx_parent_id` (`parent_id`),
    KEY `idx_status` (`status`),
    KEY `idx_dept_code` (`dept_code`),
    CONSTRAINT `fk_dept_parent` FOREIGN KEY (`parent_id`) REFERENCES `sys_department` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='部门表 - 组织架构';

-- 2.4 角色表 (sys_role)
-- RBAC核心表，角色关联权限和用户
CREATE TABLE IF NOT EXISTS `sys_role` (
    `id` VARCHAR(64) NOT NULL COMMENT '角色ID(UUID)',
    `role_name` VARCHAR(64) NOT NULL COMMENT '角色名称',
    `role_key` VARCHAR(64) NOT NULL COMMENT '角色标识(程序中使用,唯一)',
    `role_type` VARCHAR(32) DEFAULT 'business' COMMENT '角色类型:system-系统级,tenant-租户级,business-业务角色',
    `role_sort` INT DEFAULT 0 COMMENT '显示顺序',
    `data_scope` TINYINT DEFAULT 5 COMMENT '数据权限范围:1-全部数据,2-自定义数据,3-本部门数据,4-本部门及下级,5-仅本人数据,6-标签过滤',
    `data_scope_depts` TEXT COMMENT '自定义数据权限部门IDs(JSON数组)',
    `data_scope_kbs` TEXT COMMENT '自定义可访问知识库IDs(JSON数组)',
    `max_security_level` VARCHAR(32) DEFAULT '内部' COMMENT '最大可查看密级:公开,内部,秘密,机密',
    `status` TINYINT DEFAULT 1 COMMENT '状态:0-禁用,1-正常',
    `is_default` TINYINT DEFAULT 0 COMMENT '是否为默认角色:0-否,1-是(新用户自动分配)',
    `is_system` TINYINT DEFAULT 0 COMMENT '是否系统内置:0-否,1-是(不可删除)',
    `tenant_id` VARCHAR(64) NOT NULL COMMENT '所属租户ID',
    `remark` VARCHAR(512) COMMENT '备注说明',
    `attrs` JSON COMMENT '扩展属性',
    `create_by` VARCHAR(64) COMMENT '创建者',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_by` VARCHAR(64) COMMENT '更新者',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` TINYINT DEFAULT 0 COMMENT '软删除标记:0-未删除,1-已删除',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_tenant_role_key` (`tenant_id`, `role_key`),
    KEY `idx_tenant_id` (`tenant_id`),
    KEY `idx_status` (`status`),
    KEY `idx_role_type` (`role_type`),
    KEY `idx_is_default` (`is_default`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='角色表';

-- 2.5 权限表 (sys_permission)
-- 存储所有权限点，支持菜单、按钮、API、数据权限
CREATE TABLE IF NOT EXISTS `sys_permission` (
    `id` VARCHAR(64) NOT NULL COMMENT '权限ID(UUID)',
    `permission_code` VARCHAR(128) NOT NULL UNIQUE COMMENT '权限标识(程序中使用,格式:模块:资源:操作)',
    `permission_name` VARCHAR(64) NOT NULL COMMENT '权限名称(显示用)',
    `permission_type` VARCHAR(32) NOT NULL COMMENT '权限类型:menu-菜单,button-按钮,api-API接口,data-数据权限',
    `resource_type` VARCHAR(32) COMMENT '资源类型:kb-知识库,doc-文档,system-系统管理,user-用户管理',
    `parent_id` VARCHAR(64) COMMENT '父权限ID(用于菜单树形结构)',
    `parent_ids` VARCHAR(256) COMMENT '父权限ID链',
    `level` INT DEFAULT 1 COMMENT '权限层级',
    `order_num` INT DEFAULT 0 COMMENT '排序号',
    `path` VARCHAR(256) COMMENT '路由路径(菜单)',
    `component` VARCHAR(256) COMMENT '组件路径(前端组件)',
    `component_name` VARCHAR(128) COMMENT '组件名称',
    `icon` VARCHAR(64) COMMENT '图标',
    `is_visible` TINYINT DEFAULT 1 COMMENT '是否显示菜单:0-隐藏,1-显示',
    `is_cache` TINYINT DEFAULT 0 COMMENT '是否缓存:0-否,1-是',
    `is_external` TINYINT DEFAULT 0 COMMENT '是否外链:0-否,1-是',
    `external_url` VARCHAR(512) COMMENT '外链地址',
    `status` TINYINT DEFAULT 1 COMMENT '状态:0-禁用,1-正常',
    `is_system` TINYINT DEFAULT 0 COMMENT '是否系统内置:0-否,1-是',
    `requires_permission` VARCHAR(64) COMMENT '需要的权限标识',
    `attrs` JSON COMMENT '扩展属性:按钮颜色/快捷键等',
    `create_by` VARCHAR(64) COMMENT '创建者',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_by` VARCHAR(64) COMMENT '更新者',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` TINYINT DEFAULT 0 COMMENT '软删除标记:0-未删除,1-已删除',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_permission_code` (`permission_code`),
    KEY `idx_parent_id` (`parent_id`),
    KEY `idx_resource_type` (`resource_type`),
    KEY `idx_permission_type` (`permission_type`),
    KEY `idx_status` (`status`),
    CONSTRAINT `fk_permission_parent` FOREIGN KEY (`parent_id`) REFERENCES `sys_permission` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='权限表';

-- 2.6 用户-角色关联表 (sys_user_role)
-- 用户与角色的多对多关系
CREATE TABLE IF NOT EXISTS `sys_user_role` (
    `id` VARCHAR(64) NOT NULL COMMENT '关联ID(UUID)',
    `user_id` VARCHAR(64) NOT NULL COMMENT '用户ID',
    `role_id` VARCHAR(64) NOT NULL COMMENT '角色ID',
    `tenant_id` VARCHAR(64) NOT NULL COMMENT '租户ID(冗余,便于查询)',
    `expire_time` DATETIME COMMENT '授权过期时间(NULL表示永不过期)',
    `create_by` VARCHAR(64) COMMENT '授权者',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '授权时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_role` (`user_id`, `role_id`),
    KEY `idx_role_id` (`role_id`),
    KEY `idx_tenant_id` (`tenant_id`),
    KEY `idx_expire_time` (`expire_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户和角色关联表';

-- 2.7 角色-权限关联表 (sys_role_permission)
-- 角色与权限的多对多关系
CREATE TABLE IF NOT EXISTS `sys_role_permission` (
    `id` VARCHAR(64) NOT NULL COMMENT '关联ID(UUID)',
    `role_id` VARCHAR(64) NOT NULL COMMENT '角色ID',
    `permission_id` VARCHAR(64) NOT NULL COMMENT '权限ID',
    `create_by` VARCHAR(64) COMMENT '授权者',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '授权时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_role_permission` (`role_id`, `permission_id`),
    KEY `idx_permission_id` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='角色和权限关联表';

-- 2.8 用户-部门关联表 (sys_user_department)
-- 用户与部门的多对多关系(一个用户可属于多个部门)
CREATE TABLE IF NOT EXISTS `sys_user_department` (
    `id` VARCHAR(64) NOT NULL COMMENT '关联ID(UUID)',
    `user_id` VARCHAR(64) NOT NULL COMMENT '用户ID',
    `dept_id` VARCHAR(64) NOT NULL COMMENT '部门ID',
    `tenant_id` VARCHAR(64) NOT NULL COMMENT '租户ID',
    `is_primary` TINYINT DEFAULT 0 COMMENT '是否主部门:0-否,1-是',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_dept` (`user_id`, `dept_id`),
    KEY `idx_dept_id` (`dept_id`),
    KEY `idx_tenant_id` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户和部门关联表';

-- -----------------------------------------------------------------------------
-- 第三部分：知识库和文档表
-- -----------------------------------------------------------------------------

-- 3.1 知识库表 (kb_knowledge_base)
-- 核心业务表，存储知识库基本信息
CREATE TABLE IF NOT EXISTS `kb_knowledge_base` (
    `id` VARCHAR(64) NOT NULL COMMENT '知识库ID(UUID)',
    `name` VARCHAR(128) NOT NULL COMMENT '知识库名称',
    `code` VARCHAR(64) COMMENT '知识库编码',
    `description` TEXT COMMENT '知识库描述',
    `tenant_id` VARCHAR(64) NOT NULL COMMENT '所属租户ID',
    `owner_id` VARCHAR(64) COMMENT '负责人用户ID',
    `owner_name` VARCHAR(64) COMMENT '负责人姓名',
    `embedding_model` VARCHAR(64) DEFAULT 'text-embedding-ada-002' COMMENT '向量化模型',
    `vector_dimension` INT DEFAULT 1536 COMMENT '向量维度',
    `index_type` VARCHAR(32) DEFAULT 'hnsw' COMMENT '索引类型:hnsw,ivf,flat',
    `status` TINYINT DEFAULT 1 COMMENT '状态:0-禁用,1-正常,2-构建中',
    `is_public` TINYINT DEFAULT 0 COMMENT '是否公共知识库:0-否,1-是(租户内可见)',
    `is_active` TINYINT DEFAULT 1 COMMENT '是否启用:0-停用,1-启用',
    `permission_type` VARCHAR(32) DEFAULT 'private' COMMENT '权限模式:private-私有,public-公开,rbac-角色权限',
    `storage_path` VARCHAR(512) COMMENT '文件存储路径',
    `chunk_size` INT DEFAULT 512 COMMENT '文档分块大小(Token)',
    `overlap_size` INT DEFAULT 50 COMMENT '分块重叠大小(Token)',
    `doc_count` INT DEFAULT 0 COMMENT '文档数量',
    `chunk_count` INT DEFAULT 0 COMMENT '切片数量',
    `vector_count` INT DEFAULT 0 COMMENT '向量数量',
    `storage_size` BIGINT DEFAULT 0 COMMENT '存储大小(字节)',
    `config` JSON COMMENT '知识库配置(JSON)',
    `metadata_schema` JSON COMMENT '元数据Schema定义',
    `create_by` VARCHAR(64) COMMENT '创建者',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_by` VARCHAR(64) COMMENT '更新者',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` TINYINT DEFAULT 0 COMMENT '软删除标记:0-未删除,1-已删除',
    PRIMARY KEY (`id`),
    KEY `idx_tenant_id` (`tenant_id`),
    KEY `idx_owner_id` (`owner_id`),
    KEY `idx_status` (`status`),
    KEY `idx_is_public` (`is_public`),
    KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='知识库表';

-- 3.2 文档表 (kb_document)
-- 存储文档基本信息，关联知识库和分类
CREATE TABLE IF NOT EXISTS `kb_document` (
    `id` VARCHAR(64) NOT NULL COMMENT '文档ID(UUID)',
    `title` VARCHAR(256) NOT NULL COMMENT '文档标题',
    `content` LONGTEXT COMMENT '文档内容(富文本/纯文本)',
    `summary` TEXT COMMENT '文档摘要',
    `kb_id` VARCHAR(64) NOT NULL COMMENT '所属知识库ID',
    `tenant_id` VARCHAR(64) NOT NULL COMMENT '所属租户ID',
    `category_id` VARCHAR(64) COMMENT '所属分类ID',
    `creator_id` VARCHAR(64) NOT NULL COMMENT '创建者ID',
    `creator_name` VARCHAR(64) COMMENT '创建者姓名',
    `dept_id` VARCHAR(64) COMMENT '所属部门ID(用于数据权限)',
    `security_level` VARCHAR(32) DEFAULT '内部' COMMENT '密级:公开,内部,秘密,机密',
    `status` TINYINT DEFAULT 1 COMMENT '状态:0-草稿,1-已发布,2-已归档,3-待审核,4-已拒绝',
    `doc_type` VARCHAR(32) DEFAULT 'text' COMMENT '文档类型:text-文本,markdown,html,pdf,word,excel,ppt,image,url',
    `file_type` VARCHAR(32) COMMENT '文件类型扩展名',
    `file_size` BIGINT COMMENT '文件大小(字节)',
    `file_path` VARCHAR(512) COMMENT '原始文件存储路径',
    `file_hash` VARCHAR(64) COMMENT '文件Hash(MD5/SHA256)',
    `vector_ids` TEXT COMMENT '向量ID列表(JSON数组)',
    `chunk_count` INT DEFAULT 0 COMMENT '分块数量',
    `metadata` JSON COMMENT '元数据(JSON)',
    `tags` VARCHAR(512) COMMENT '标签(JSON数组字符串)',
    `custom_fields` JSON COMMENT '自定义字段(JSON)',
    `version` INT DEFAULT 1 COMMENT '版本号',
    `parent_id` VARCHAR(64) COMMENT '父文档ID(用于文档树)',
    `sort_order` INT DEFAULT 0 COMMENT '排序号',
    `view_count` INT DEFAULT 0 COMMENT '浏览次数',
    `like_count` INT DEFAULT 0 COMMENT '点赞次数',
    `comment_count` INT DEFAULT 0 COMMENT '评论次数',
    `score` DECIMAL(3,2) DEFAULT 0.00 COMMENT '平均评分',
    `published_at` DATETIME COMMENT '发布时间',
    `expire_time` DATETIME COMMENT '过期时间',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` TINYINT DEFAULT 0 COMMENT '软删除标记:0-未删除,1-已删除',
    PRIMARY KEY (`id`),
    KEY `idx_kb_id` (`kb_id`),
    KEY `idx_tenant_id` (`tenant_id`),
    KEY `idx_creator_id` (`creator_id`),
    KEY `idx_dept_id` (`dept_id`),
    KEY `idx_category_id` (`category_id`),
    KEY `idx_status` (`status`),
    KEY `idx_security_level` (`security_level`),
    KEY `idx_parent_id` (`parent_id`),
    KEY `idx_create_time` (`create_time`),
    KEY `idx_published_at` (`published_at`),
    KEY `idx_tags` (`tags`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='文档表';

-- 3.3 文档切片表 (kb_document_chunk)
-- 文档向量化切分后的片段，用于RAG检索
CREATE TABLE IF NOT EXISTS `kb_document_chunk` (
    `id` VARCHAR(64) NOT NULL COMMENT '切片ID(UUID)',
    `doc_id` VARCHAR(64) NOT NULL COMMENT '所属文档ID',
    `kb_id` VARCHAR(64) NOT NULL COMMENT '所属知识库ID',
    `tenant_id` VARCHAR(64) NOT NULL COMMENT '所属租户ID',
    `chunk_index` INT NOT NULL COMMENT '切片索引(同一文档内从0开始)',
    `content` TEXT NOT NULL COMMENT '切片内容',
    `content_length` INT COMMENT '内容长度(Token/字符)',
    `vector_id` VARCHAR(128) COMMENT '向量数据库中的ID',
    `vector` BLOB COMMENT '向量数据(可选,也可存向量库)',
    `metadata` JSON COMMENT '元数据:位置信息、来源等',
    `position_start` INT COMMENT '在原文档中的起始位置',
    `position_end` INT COMMENT '在原文档中的结束位置',
    `is_deleted` TINYINT DEFAULT 0 COMMENT '是否删除:0-存在,1-已删除',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    KEY `idx_doc_id` (`doc_id`),
    KEY `idx_kb_id` (`kb_id`),
    KEY `idx_tenant_id` (`tenant_id`),
    KEY `idx_vector_id` (`vector_id`),
    KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='文档切片表';

-- 3.4 文档分类表 (kb_category)
-- 文档分类树形结构
CREATE TABLE IF NOT EXISTS `kb_category` (
    `id` VARCHAR(64) NOT NULL COMMENT '分类ID(UUID)',
    `category_name` VARCHAR(64) NOT NULL COMMENT '分类名称',
    `category_code` VARCHAR(64) COMMENT '分类编码',
    `kb_id` VARCHAR(64) NOT NULL COMMENT '所属知识库ID',
    `tenant_id` VARCHAR(64) NOT NULL COMMENT '所属租户ID',
    `parent_id` VARCHAR(64) COMMENT '父分类ID',
    `parent_ids` VARCHAR(256) COMMENT '父分类ID链',
    `level` INT DEFAULT 1 COMMENT '层级',
    `order_num` INT DEFAULT 0 COMMENT '排序号',
    `icon` VARCHAR(64) COMMENT '图标',
    `status` TINYINT DEFAULT 1 COMMENT '状态:0-禁用,1-正常',
    `create_by` VARCHAR(64) COMMENT '创建者',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_by` VARCHAR(64) COMMENT '更新者',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` TINYINT DEFAULT 0 COMMENT '软删除标记',
    PRIMARY KEY (`id`),
    KEY `idx_kb_id` (`kb_id`),
    KEY `idx_tenant_id` (`tenant_id`),
    KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='文档分类表';

-- 3.5 知识库权限表 (kb_permission)
-- 知识库级别的权限配置，支持用户、角色、部门三个维度
CREATE TABLE IF NOT EXISTS `kb_permission` (
    `id` VARCHAR(64) NOT NULL COMMENT '权限ID(UUID)',
    `kb_id` VARCHAR(64) NOT NULL COMMENT '知识库ID',
    `tenant_id` VARCHAR(64) NOT NULL COMMENT '租户ID',
    `permission_type` VARCHAR(32) NOT NULL COMMENT '授权类型:user-用户,role-角色,dept-部门,all-所有人',
    `target_id` VARCHAR(64) COMMENT '目标ID(用户ID/角色ID/部门ID,type为all时为空)',
    `target_name` VARCHAR(64) COMMENT '目标名称(冗余字段)',
    `permission_level` VARCHAR(32) NOT NULL COMMENT '权限级别:read-读取,write-编辑,manage-管理,owner-所有者',
    `inherit` TINYINT DEFAULT 1 COMMENT '是否向下继承:0-否,1-是(知识库权限自动应用到子文档)',
    `expire_time` DATETIME COMMENT '权限过期时间',
    `is_revoked` TINYINT DEFAULT 0 COMMENT '是否已撤销:0-正常,1-已撤销',
    `create_by` VARCHAR(64) COMMENT '授权者',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '授权时间',
    `update_by` VARCHAR(64) COMMENT '更新者',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_kb_id` (`kb_id`),
    KEY `idx_tenant_id` (`tenant_id`),
    KEY `idx_permission_type` (`permission_type`),
    KEY `idx_target_id` (`target_id`),
    KEY `uk_kb_target` (`kb_id`, `permission_type`, `target_id`),
    KEY `idx_expire_time` (`expire_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='知识库权限表';

-- 3.6 文档权限表 (doc_permission)
-- 文档级别的细粒度权限控制
CREATE TABLE IF NOT EXISTS `doc_permission` (
    `id` VARCHAR(64) NOT NULL COMMENT '权限ID(UUID)',
    `doc_id` VARCHAR(64) NOT NULL COMMENT '文档ID',
    `kb_id` VARCHAR(64) NOT NULL COMMENT '所属知识库ID',
    `tenant_id` VARCHAR(64) NOT NULL COMMENT '租户ID',
    `permission_type` VARCHAR(32) NOT NULL COMMENT '授权类型:user-用户,role-角色,dept-部门,all-公开',
    `target_id` VARCHAR(64) COMMENT '目标ID(用户ID/角色ID/部门ID)',
    `target_name` VARCHAR(64) COMMENT '目标名称',
    `permission_level` VARCHAR(32) NOT NULL COMMENT '权限级别:read-读取,write-编辑,delete-删除,share-分享,manage-管理',
    `share_token` VARCHAR(128) COMMENT '分享令牌(用于外部链接分享)',
    `share_expire_time` DATETIME COMMENT '分享过期时间',
    `is_recursive` TINYINT DEFAULT 0 COMMENT '是否递归应用到子文档:0-否,1-是',
    `expire_time` DATETIME COMMENT '权限过期时间',
    `is_revoked` TINYINT DEFAULT 0 COMMENT '是否已撤销',
    `create_by` VARCHAR(64) COMMENT '授权者',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '授权时间',
    `update_by` VARCHAR(64) COMMENT '更新者',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_doc_id` (`doc_id`),
    KEY `idx_kb_id` (`kb_id`),
    KEY `idx_tenant_id` (`tenant_id`),
    KEY `idx_permission_type` (`permission_type`),
    KEY `idx_target_id` (`target_id`),
    KEY `idx_share_token` (`share_token`),
    KEY `uk_doc_target` (`doc_id`, `permission_type`, `target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='文档权限表';

-- -----------------------------------------------------------------------------
-- 第四部分：系统支撑表
-- -----------------------------------------------------------------------------

-- 4.1 审计日志表 (sys_audit_log)
-- 记录所有敏感操作，用于安全审计和追溯
CREATE TABLE IF NOT EXISTS `sys_audit_log` (
    `id` VARCHAR(64) NOT NULL COMMENT '日志ID(UUID)',
    `tenant_id` VARCHAR(64) NOT NULL COMMENT '租户ID',
    `user_id` VARCHAR(64) COMMENT '操作用户ID',
    `username` VARCHAR(64) COMMENT '操作用户名',
    `user_ip` VARCHAR(128) COMMENT '用户IP地址',
    `user_location` VARCHAR(256) COMMENT '用户地理位置',
    `operation` VARCHAR(64) NOT NULL COMMENT '操作类型',
    `operation_name` VARCHAR(128) COMMENT '操作名称(中文描述)',
    `module` VARCHAR(64) COMMENT '所属模块',
    `resource_type` VARCHAR(64) COMMENT '资源类型',
    `resource_id` VARCHAR(64) COMMENT '资源ID',
    `resource_name` VARCHAR(256) COMMENT '资源名称',
    `request_method` VARCHAR(10) COMMENT 'HTTP方法',
    `request_url` VARCHAR(512) COMMENT '请求URL',
    `request_params` TEXT COMMENT '请求参数(敏感信息脱敏)',
    `request_body` TEXT COMMENT '请求体(脱敏后)',
    `response_code` VARCHAR(32) COMMENT '响应状态码',
    `response_body` TEXT COMMENT '响应内容(脱敏)',
    `user_agent` VARCHAR(512) COMMENT 'User-Agent',
    `browser` VARCHAR(64) COMMENT '浏览器类型',
    `os` VARCHAR(64) COMMENT '操作系统',
    `device` VARCHAR(64) COMMENT '设备类型',
    `status` TINYINT DEFAULT 1 COMMENT '状态:0-失败,1-成功',
    `error_code` VARCHAR(64) COMMENT '错误码',
    `error_msg` TEXT COMMENT '错误信息',
    `execution_time` INT COMMENT '执行时间(毫秒)',
    `trace_id` VARCHAR(64) COMMENT '链路追踪ID',
    `extra_data` JSON COMMENT '扩展数据',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
    PRIMARY KEY (`id`),
    KEY `idx_tenant_id` (`tenant_id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_username` (`username`),
    KEY `idx_operation` (`operation`),
    KEY `idx_module` (`module`),
    KEY `idx_resource_type` (`resource_type`),
    KEY `idx_resource_id` (`resource_id`),
    KEY `idx_status` (`status`),
    KEY `idx_created_at` (`created_at`),
    KEY `idx_trace_id` (`trace_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='审计日志表';

-- 4.2 API令牌表 (sys_api_token)
-- 用于API访问认证，支持多Token和权限范围
CREATE TABLE IF NOT EXISTS `sys_api_token` (
    `id` VARCHAR(64) NOT NULL COMMENT 'Token ID(UUID)',
    `token_name` VARCHAR(128) NOT NULL COMMENT 'Token名称',
    `token_value` VARCHAR(256) NOT NULL UNIQUE COMMENT 'Token值(Hash存储)',
    `token_hash` VARCHAR(128) NOT NULL COMMENT 'Token Hash(SHA256)',
    `tenant_id` VARCHAR(64) NOT NULL COMMENT '所属租户ID',
    `user_id` VARCHAR(64) COMMENT '关联用户ID(可选)',
    `app_id` VARCHAR(64) COMMENT '应用ID(第三方系统标识)',
    `app_name` VARCHAR(128) COMMENT '应用名称',
    `scopes` TEXT COMMENT '权限范围(JSON数组)',
    `allowed_apis` TEXT COMMENT '允许访问的API列表(JSON)',
    `denied_apis` TEXT COMMENT '禁止访问的API列表(JSON)',
    `rate_limit` INT DEFAULT 1000 COMMENT '请求频率限制(次/分钟)',
    `max_requests_per_day` INT COMMENT '每日最大请求次数',
    `status` TINYINT DEFAULT 1 COMMENT '状态:0-禁用,1-正常,2-过期',
    `effective_time` DATETIME COMMENT '生效时间',
    `expire_time` DATETIME COMMENT '过期时间',
    `last_used_time` DATETIME COMMENT '最后使用时间',
    `last_used_ip` VARCHAR(128) COMMENT '最后使用IP',
    `used_count` BIGINT DEFAULT 0 COMMENT '累计使用次数',
    `used_today` INT DEFAULT 0 COMMENT '今日使用次数',
    `used_date` DATE COMMENT '计数日期(用于每日重置)',
    `create_by` VARCHAR(64) COMMENT '创建者',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_by` VARCHAR(64) COMMENT '更新者',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted` TINYINT DEFAULT 0 COMMENT '软删除标记',
    PRIMARY KEY (`id`),
    KEY `idx_token_value` (`token_value`),
    KEY `idx_tenant_id` (`tenant_id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_app_id` (`app_id`),
    KEY `idx_status` (`status`),
    KEY `idx_expire_time` (`expire_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API令牌表';

-- 4.3 登录日志表 (sys_login_log)
-- 记录用户登录行为
CREATE TABLE IF NOT EXISTS `sys_login_log` (
    `id` VARCHAR(64) NOT NULL COMMENT '日志ID(UUID)',
    `tenant_id` VARCHAR(64) NOT NULL COMMENT '租户ID',
    `user_id` VARCHAR(64) COMMENT '用户ID',
    `username` VARCHAR(64) COMMENT '用户名',
    `login_type` VARCHAR(32) DEFAULT 'password' COMMENT '登录方式:password, sms, email, oauth, sso',
    `login_source` VARCHAR(32) COMMENT '登录来源:web, app, api, cli',
    `ip` VARCHAR(128) COMMENT 'IP地址',
    `location` VARCHAR(256) COMMENT '地理位置',
    `browser` VARCHAR(64) COMMENT '浏览器',
    `os` VARCHAR(64) COMMENT '操作系统',
    `device` VARCHAR(64) COMMENT '设备',
    `user_agent` VARCHAR(512) COMMENT 'User-Agent',
    `status` TINYINT DEFAULT 1 COMMENT '登录状态:0-失败,1-成功',
    `fail_reason` VARCHAR(256) COMMENT '失败原因',
    `session_id` VARCHAR(128) COMMENT '会话ID',
    `token` VARCHAR(256) COMMENT '签发的Token',
    `execution_time` INT COMMENT '登录耗时(毫秒)',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '登录时间',
    PRIMARY KEY (`id`),
    KEY `idx_tenant_id` (`tenant_id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_username` (`username`),
    KEY `idx_status` (`status`),
    KEY `idx_login_type` (`login_type`),
    KEY `idx_created_at` (`created_at`),
    KEY `idx_ip` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='登录日志表';

-- -----------------------------------------------------------------------------
-- 第五部分：初始数据
-- -----------------------------------------------------------------------------

-- 5.1 插入默认租户
INSERT INTO `sys_tenant` (`id`, `name`, `code`, `isolation_level`, `status`, `max_users`, `max_kb_count`, `max_storage_bytes`, `description`, `create_by`, `create_time`)
VALUES 
    ('tenant_default', '默认租户', 'default', 1, 1, 1000, 100, 107374182400, '系统默认租户,用于初始化和演示', 'system', NOW());

-- 5.2 插入系统管理员角色
INSERT INTO `sys_role` (`id`, `role_name`, `role_key`, `role_type`, `role_sort`, `data_scope`, `status`, `is_default`, `is_system`, `tenant_id`, `remark`, `create_by`, `create_time`)
VALUES 
    ('role_superadmin', '超级管理员', 'superadmin', 'system', 1, 1, 1, 0, 1, 'tenant_default', '系统超级管理员,拥有所有权限', 'system', NOW()),
    ('role_admin', '租户管理员', 'tenant_admin', 'tenant', 2, 1, 1, 0, 0, 'tenant_default', '租户管理员,管理租户内所有资源', 'system', NOW()),
    ('role_kb_admin', '知识库管理员', 'kb_admin', 'business', 3, 2, 1, 0, 0, 'tenant_default', '知识库管理员,管理指定知识库', 'system', NOW()),
    ('role_editor', '编辑者', 'editor', 'business', 4, 4, 1, 1, 0, 'tenant_default', '内容编辑者,可创建和编辑文档', 'system', NOW()),
    ('role_viewer', '查看者', 'viewer', 'business', 5, 5, 1, 1, 0, 'tenant_default', '普通查看者,仅可查看授权内容', 'system', NOW()),
    ('role_guest', '访客', 'guest', 'business', 6, 5, 1, 0, 0, 'tenant_default', '外部访客,受限访问', 'system', NOW());

-- 5.3 插入系统级权限
INSERT INTO `sys_permission` (`id`, `permission_code`, `permission_name`, `permission_type`, `resource_type`, `parent_id`, `order_num`, `status`, `is_system`, `create_time`)
VALUES 
    -- 系统管理模块
    ('perm_sys_manage', 'sys:manage', '系统管理', 'menu', 'system', NULL, 1, 1, 1, NOW()),
    ('perm_sys_user', 'sys:user', '用户管理', 'menu', 'system', 'perm_sys_manage', 1, 1, 1, NOW()),
    ('perm_sys_user_list', 'sys:user:list', '用户列表', 'button', 'system', 'perm_sys_user', 1, 1, 1, NOW()),
    ('perm_sys_user_create', 'sys:user:create', '创建用户', 'button', 'system', 'perm_sys_user', 2, 1, 1, NOW()),
    ('perm_sys_user_update', 'sys:user:update', '修改用户', 'button', 'system', 'perm_sys_user', 3, 1, 1, NOW()),
    ('perm_sys_user_delete', 'sys:user:delete', '删除用户', 'button', 'system', 'perm_sys_user', 4, 1, 1, NOW()),
    ('perm_sys_role', 'sys:role', '角色管理', 'menu', 'system', 'perm_sys_manage', 2, 1, 1, NOW()),
    ('perm_sys_role_list', 'sys:role:list', '角色列表', 'button', 'system', 'perm_sys_role', 1, 1, 1, NOW()),
    ('perm_sys_role_create', 'sys:role:create', '创建角色', 'button', 'system', 'perm_sys_role', 2, 1, 1, NOW()),
    ('perm_sys_role_update', 'sys:role:update', '修改角色', 'button', 'system', 'perm_sys_role', 3, 1, 1, NOW()),
    ('perm_sys_role_delete', 'sys:role:delete', '删除角色', 'button', 'system', 'perm_sys_role', 4, 1, 1, NOW()),
    ('perm_sys_role_assign', 'sys:role:assign', '分配角色', 'button', 'system', 'perm_sys_role', 5, 1, 1, NOW()),
    ('perm_sys_permission', 'sys:permission', '权限管理', 'menu', 'system', 'perm_sys_manage', 3, 1, 1, NOW()),
    ('perm_sys_tenant', 'sys:tenant', '租户管理', 'menu', 'system', 'perm_sys_manage', 4, 1, 1, NOW()),
    ('perm_sys_audit', 'sys:audit', '审计日志', 'menu', 'system', 'perm_sys_manage', 5, 1, 1, NOW()),
    ('perm_sys_config', 'sys:config', '系统配置', 'menu', 'system', 'perm_sys_manage', 6, 1, 1, NOW()),
    
    -- 租户管理模块
    ('perm_tenant_manage', 'tenant:manage', '租户管理', 'menu', 'system', NULL, 2, 1, 1, NOW()),
    ('perm_tenant_user', 'tenant:user', '用户管理', 'menu', 'system', 'perm_tenant_manage', 1, 1, 1, NOW()),
    ('perm_tenant_dept', 'tenant:dept', '部门管理', 'menu', 'system', 'perm_tenant_manage', 2, 1, 1, NOW()),
    ('perm_tenant_config', 'tenant:config', '租户配置', 'menu', 'system', 'perm_tenant_manage', 3, 1, 1, NOW()),
    
    -- 知识库管理模块
    ('perm_kb_manage', 'kb:manage', '知识库管理', 'menu', 'kb', NULL, 3, 1, 1, NOW()),
    ('perm_kb_list', 'kb:list', '知识库列表', 'button', 'kb', 'perm_kb_manage', 1, 1, 1, NOW()),
    ('perm_kb_create', 'kb:create', '创建知识库', 'button', 'kb', 'perm_kb_manage', 2, 1, 1, NOW()),
    ('perm_kb_update', 'kb:update', '修改知识库', 'button', 'kb', 'perm_kb_manage', 3, 1, 1, NOW()),
    ('perm_kb_delete', 'kb:delete', '删除知识库', 'button', 'kb', 'perm_kb_manage', 4, 1, 1, NOW()),
    ('perm_kb_config', 'kb:config', '知识库配置', 'button', 'kb', 'perm_kb_manage', 5, 1, 1, NOW()),
    ('perm_kb_permission', 'kb:permission', '权限设置', 'button', 'kb', 'perm_kb_manage', 6, 1, 1, NOW()),
    
    -- 文档操作模块
    ('perm_doc_manage', 'doc:manage', '文档管理', 'menu', 'doc', NULL, 4, 1, 1, NOW()),
    ('perm_doc_list', 'doc:list', '文档列表', 'button', 'doc', 'perm_doc_manage', 1, 1, 1, NOW()),
    ('perm_doc_create', 'doc:create', '创建文档', 'button', 'doc', 'perm_doc_manage', 2, 1, 1, NOW()),
    ('perm_doc_update', 'doc:update', '修改文档', 'button', 'doc', 'perm_doc_manage', 3, 1, 1, NOW()),
    ('perm_doc_delete', 'doc:delete', '删除文档', 'button', 'doc', 'perm_doc_manage', 4, 1, 1, NOW()),
    ('perm_doc_read', 'doc:read', '查看文档', 'button', 'doc', 'perm_doc_manage', 5, 1, 1, NOW()),
    ('perm_doc_share', 'doc:share', '分享文档', 'button', 'doc', 'perm_doc_manage', 6, 1, 1, NOW()),
    ('perm_doc_export', 'doc:export', '导出文档', 'button', 'doc', 'perm_doc_manage', 7, 1, 1, NOW()),
    
    -- RAG检索模块
    ('perm_rag_search', 'rag:search', '知识检索', 'api', 'system', NULL, 5, 1, 1, NOW()),
    ('perm_rag_chat', 'rag:chat', '知识问答', 'api', 'system', NULL, 6, 1, 1, NOW());

-- 5.4 为超级管理员角色分配所有权限
INSERT INTO `sys_role_permission` (`id`, `role_id`, `permission_id`, `create_time`)
SELECT CONCAT('rp_sa_', perm.id), 'role_superadmin', perm.id, NOW()
FROM `sys_permission` perm
WHERE perm.status = 1 AND perm.deleted = 0;

-- 5.5 为租户管理员角色分配租户内所有权限
INSERT INTO `sys_role_permission` (`id`, `role_id`, `permission_id`, `create_time`)
SELECT CONCAT('rp_ta_', perm.id), 'role_admin', perm.id, NOW()
FROM `sys_permission` perm
WHERE perm.status = 1 AND perm.deleted = 0
AND (perm.permission_type != 'menu' OR perm.parent_id IS NOT NULL);

-- 5.6 为编辑者角色分配文档相关权限
INSERT INTO `sys_role_permission` (`id`, `role_id`, `permission_id`, `create_time`)
SELECT CONCAT('rp_ed_', perm.id), 'role_editor', perm.id, NOW()
FROM `sys_permission` perm
WHERE perm.permission_code IN (
    'kb:list', 'kb:create', 'kb:update',
    'doc:list', 'doc:create', 'doc:update', 'doc:read',
    'rag:search', 'rag:chat'
);

-- 5.7 为查看者角色分配只读权限
INSERT INTO `sys_role_permission` (`id`, `role_id`, `permission_id`, `create_time`)
SELECT CONCAT('rp_vw_', perm.id), 'role_viewer', perm.id, NOW()
FROM `sys_permission` perm
WHERE perm.permission_code IN (
    'kb:list',
    'doc:list', 'doc:read',
    'rag:search', 'rag:chat'
);

-- 5.8 创建默认管理员账号 (密码: admin123, BCrypt加密)
-- 注意: 生产环境中请修改默认密码
INSERT INTO `sys_user` (
    `id`, `username`, `password`, `real_name`, `email`, `phone`,
    `tenant_id`, `status`, `user_type`, `create_by`, `create_time`
)
VALUES 
    ('user_admin', 'admin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '系统管理员', 'admin@example.com', '13800138000', 'tenant_default', 1, 3, 'system', NOW()),
    ('user_tenant_admin', 'tenant_admin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '租户管理员', 'tenant@example.com', '13800138001', 'tenant_default', 1, 2, 'system', NOW());

-- 5.9 为管理员分配超级管理员角色
INSERT INTO `sys_user_role` (`id`, `user_id`, `role_id`, `tenant_id`, `create_time`)
VALUES 
    ('ur_admin_sa', 'user_admin', 'role_superadmin', 'tenant_default', NOW()),
    ('ur_tenant_admin_ta', 'user_tenant_admin', 'role_admin', 'tenant_default', NOW());

-- 5.10 创建默认部门
INSERT INTO `sys_department` (`id`, `dept_name`, `dept_code`, `parent_id`, `level`, `order_num`, `tenant_id`, `status`, `create_by`, `create_time`)
VALUES 
    ('dept_root', '总公司', 'HQ', NULL, 1, 1, 'tenant_default', 1, 'system', NOW()),
    ('dept_tech', '技术部', 'TECH', 'dept_root', 2, 1, 'tenant_default', 1, 'system', NOW()),
    ('dept_ops', '运维部', 'OPS', 'dept_root', 2, 2, 'tenant_default', 1, 'system', NOW()),
    ('dept_sales', '销售部', 'SALES', 'dept_root', 2, 3, 'tenant_default', 1, 'system', NOW()),
    ('dept_hr', '人力资源部', 'HR', 'dept_root', 2, 4, 'tenant_default', 1, 'system', NOW()),
    ('dept_backend', '后端开发组', 'BACKEND', 'dept_tech', 3, 1, 'tenant_default', 1, 'system', NOW()),
    ('dept_frontend', '前端开发组', 'FRONTEND', 'dept_tech', 3, 2, 'tenant_default', 1, 'system', NOW());

-- 5.11 创建示例知识库
INSERT INTO `kb_knowledge_base` (
    `id`, `name`, `code`, `description`, `tenant_id`, `owner_id`, `owner_name`,
    `embedding_model`, `vector_dimension`, `status`, `is_public`, `permission_type`,
    `chunk_size`, `overlap_size`, `create_by`, `create_time`
)
VALUES 
    ('kb_public', '公共知识库', 'public_kb', '公司公共知识库,所有员工可查阅', 'tenant_default', 'user_admin', '系统管理员', 'text-embedding-ada-002', 1536, 1, 1, 'public', 512, 50, 'system', NOW()),
    ('kb_tech', '技术文档库', 'tech_kb', '技术团队文档,仅技术部成员访问', 'tenant_default', 'user_admin', '系统管理员', 'text-embedding-ada-002', 1536, 1, 0, 'rbac', 512, 50, 'system', NOW());

-- 5.12 创建API Token示例
INSERT INTO `sys_api_token` (
    `id`, `token_name`, `token_value`, `token_hash`, `tenant_id`, `app_name`,
    `scopes`, `rate_limit`, `status`, `effective_time`, `create_by`, `create_time`
)
VALUES 
    ('token_demo', '演示Token', 'demo_token_value_123456', SHA2('demo_token_value_123456', 256), 'tenant_default', 'Demo应用',
     '["rag:search", "rag:chat", "doc:read"]', 100, 1, NOW(), 'system', NOW());

-- -----------------------------------------------------------------------------
-- 第六部分：索引优化 (PostgreSQL兼容)
-- -----------------------------------------------------------------------------

-- 为PostgreSQL创建序列(如果使用PostgreSQL请执行以下语句)
-- CREATE SEQUENCE IF NOT EXISTS sys_tenant_seq;
-- CREATE SEQUENCE IF NOT EXISTS sys_user_seq;
-- ... 以此类推

-- -----------------------------------------------------------------------------
-- 第七部分：视图创建 (可选,用于简化查询)
-- -----------------------------------------------------------------------------

-- 用户完整信息视图
-- CREATE OR REPLACE VIEW v_user_full_info AS
-- SELECT u.*, d.dept_name, t.tenant_name
-- FROM sys_user u
-- LEFT JOIN sys_department d ON u.dept_id = d.id
-- LEFT JOIN sys_tenant t ON u.tenant_id = t.id;

-- 用户权限视图
-- CREATE OR REPLACE VIEW v_user_permissions AS
-- SELECT u.id as user_id, u.username, p.permission_code, p.permission_name
-- FROM sys_user u
-- INNER JOIN sys_user_role ur ON u.id = ur.user_id
-- INNER JOIN sys_role r ON ur.role_id = r.id
-- INNER JOIN sys_role_permission rp ON r.id = rp.role_id
-- INNER JOIN sys_permission p ON rp.permission_id = p.id
-- WHERE u.status = 1 AND r.status = 1 AND p.status = 1;

-- -----------------------------------------------------------------------------
-- 完成提示
-- -----------------------------------------------------------------------------

-- SELECT '数据库初始化完成!' AS message;
-- 
-- -- 验证初始数据
-- SELECT '租户数量' AS item, COUNT(*) AS count FROM sys_tenant
-- UNION ALL
-- SELECT '用户数量', COUNT(*) FROM sys_user
-- UNION ALL
-- SELECT '角色数量', COUNT(*) FROM sys_role
-- UNION ALL
-- SELECT '权限数量', COUNT(*) FROM sys_permission
-- UNION ALL
-- SELECT '部门数量', COUNT(*) FROM sys_department
-- UNION ALL
-- SELECT '知识库数量', COUNT(*) FROM kb_knowledge_base;

-- =============================================================================
-- 脚本执行说明:
-- 1. MySQL: 直接执行本脚本
-- 2. PostgreSQL: 
--    - 移除 ENGINE=InnoDB 和 CHARSET 等MySQL特有语句
--    - 将 JSON 类型替换为 JSONB
--    - 使用 serial 或 identity 替代 AUTO_INCREMENT
--    - 调整语法差异
-- 3. 默认管理员密码: admin123 (BCrypt加密)
-- 4. 建议在生产环境中修改默认密码和token
-- =============================================================================
