"""
数据库初始化脚本 - Python版本
用于初始化数据库和创建默认数据
"""

import sys
import os

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy.orm import Session
from src.core.db.database import SessionLocal, engine, Base
from src.models import (
    Tenant, User, KnowledgeBase, Document, Permission, Role, PermissionDefinition
)
from src.core.auth.jwt_auth import get_password_hash
from src.models.role import SYSTEM_ROLES, SYSTEM_PERMISSIONS
import uuid


def init_database():
    """初始化数据库"""
    print("Creating database tables...")
    Base.metadata.create_all(bind=engine)
    print("Database tables created successfully!")


def create_default_tenant(db: Session) -> Tenant:
    """创建默认租户"""
    tenant = db.query(Tenant).filter(Tenant.code == "default").first()
    if tenant:
        print(f"Default tenant already exists: {tenant.name}")
        return tenant
    
    tenant = Tenant(
        id=uuid.uuid4(),
        name="Default Tenant",
        code="default",
        description="Default tenant for the knowledge base platform"
    )
    db.add(tenant)
    db.commit()
    db.refresh(tenant)
    print(f"Created default tenant: {tenant.name}")
    return tenant


def create_system_roles(db: Session) -> list:
    """创建系统角色"""
    roles = []
    for role_data in SYSTEM_ROLES:
        existing = db.query(Role).filter(Role.name == role_data["name"]).first()
        if not existing:
            role = Role(**role_data)
            db.add(role)
            roles.append(role)
            print(f"Created role: {role_data['name']}")
        else:
            roles.append(existing)
            print(f"Role already exists: {role_data['name']}")
    
    db.commit()
    return roles


def create_system_permissions(db: Session) -> list:
    """创建系统权限定义"""
    permissions = []
    for perm_data in SYSTEM_PERMISSIONS:
        existing = db.query(PermissionDefinition).filter(
            PermissionDefinition.code == perm_data["code"]
        ).first()
        if not existing:
            perm = PermissionDefinition(**perm_data)
            db.add(perm)
            permissions.append(perm)
            print(f"Created permission: {perm_data['code']}")
        else:
            permissions.append(existing)
            print(f"Permission already exists: {perm_data['code']}")
    
    db.commit()
    return permissions


def create_super_admin(db: Session, tenant_id: uuid.UUID) -> User:
    """创建超级管理员"""
    existing = db.query(User).filter(User.username == "admin").first()
    if existing:
        print(f"Super admin already exists: {existing.username}")
        return existing
    
    admin = User(
        id=uuid.uuid4(),
        tenant_id=tenant_id,
        username="admin",
        email="admin@example.com",
        password_hash=get_password_hash("admin123"),  # 生产环境请修改
        full_name="System Administrator",
        department="IT",
        security_level="secret",
        is_super_admin=True,
        is_tenant_admin=True,
        is_active=True
    )
    db.add(admin)
    db.commit()
    db.refresh(admin)
    print(f"Created super admin: {admin.username}")
    return admin


def assign_permissions_to_roles(db: Session):
    """分配权限给角色"""
    # 超级管理员拥有所有权限
    super_admin_role = db.query(Role).filter(Role.name == "super_admin").first()
    all_permissions = db.query(PermissionDefinition).all()
    
    if super_admin_role and all_permissions:
        for perm in all_permissions:
            if perm not in super_admin_role.permissions:
                super_admin_role.permissions.append(perm)
        db.commit()
        print("Assigned all permissions to super_admin role")


def main():
    """主函数"""
    print("=" * 50)
    print("Initializing Knowledge Base Database...")
    print("=" * 50)
    
    db = SessionLocal()
    try:
        # 1. 创建表
        init_database()
        
        # 2. 创建默认租户
        tenant = create_default_tenant(db)
        
        # 3. 创建系统角色
        create_system_roles(db)
        
        # 4. 创建系统权限
        create_system_permissions(db)
        
        # 5. 创建超级管理员
        create_super_admin(db, tenant.id)
        
        # 6. 分配权限
        assign_permissions_to_roles(db)
        
        print("=" * 50)
        print("Database initialization completed!")
        print("=" * 50)
        print("\nDefault credentials:")
        print("  Username: admin")
        print("  Password: admin123")
        print("\n⚠️  Please change the default password after first login!")
        
    except Exception as e:
        print(f"Error during initialization: {e}")
        db.rollback()
        raise
    finally:
        db.close()


if __name__ == "__main__":
    main()
