"""
企业知识库平台 - 主模块
"""

__version__ = "1.0.0"
__author__ = "Enterprise Knowledge Base Team"
