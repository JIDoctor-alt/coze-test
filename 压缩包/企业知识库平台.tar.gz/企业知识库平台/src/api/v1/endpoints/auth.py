"""
认证接口
"""
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from datetime import timedelta
from ...core.db.database import get_db
from ...core.config.settings import settings
from ...core.auth.jwt_auth import (
    authenticate_user,
    create_access_token,
    get_password_hash
)
from ...schemas.auth import LoginRequest, TokenResponse
from ...services.user_service import UserService

router = APIRouter()


@router.post("/login", response_model=TokenResponse)
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db)
):
    """
    用户登录
    
    - username: 用户名
    - password: 密码
    """
    user = authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # 更新登录状态
    user_service = UserService(db)
    user_service.update_login_status(user.id, success=True)
    
    # 创建访问令牌
    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": str(user.id), "tenant_id": str(user.tenant_id)},
        expires_delta=access_token_expires
    )
    
    return TokenResponse(
        access_token=access_token,
        token_type="bearer",
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
    )


@router.post("/register")
async def register(
    username: str,
    email: str,
    password: str,
    tenant_id: str,
    db: Session = Depends(get_db)
):
    """用户注册（需要管理员权限）"""
    from ...schemas.user import UserCreate
    from uuid import UUID
    
    user_service = UserService(db)
    
    # 检查用户名是否存在
    if user_service.get_user_by_username(username):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username already exists"
        )
    
    # 检查邮箱是否存在
    if user_service.get_user_by_email(email):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already exists"
        )
    
    # 创建用户
    user_data = UserCreate(
        username=username,
        email=email,
        password=password,
        tenant_id=UUID(tenant_id)
    )
    
    user = user_service.create_user(user_data)
    
    return {"id": str(user.id), "username": user.username}
