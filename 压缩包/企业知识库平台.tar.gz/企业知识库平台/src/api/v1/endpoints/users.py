"""
用户管理接口
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from uuid import UUID
from ...core.db.database import get_db
from ...core.auth.jwt_auth import get_current_active_user
from ...models.user import User
from ...schemas.user import UserCreate, UserUpdate, UserResponse, UserListResponse
from ...services.user_service import UserService

router = APIRouter()


@router.get("/me", response_model=UserResponse)
async def get_current_user_info(
    current_user: User = Depends(get_current_active_user)
):
    """获取当前用户信息"""
    return UserResponse(
        id=current_user.id,
        tenant_id=current_user.tenant_id,
        username=current_user.username,
        email=current_user.email,
        full_name=current_user.full_name,
        department=current_user.department,
        security_level=current_user.security_level,
        is_active=current_user.is_active,
        is_super_admin=current_user.is_super_admin,
        is_tenant_admin=current_user.is_tenant_admin,
        roles=current_user.get_role_names(),
        created_at=current_user.created_at,
        last_login_at=current_user.last_login_at
    )


@router.get("/", response_model=UserListResponse)
async def list_users(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """获取用户列表"""
    user_service = UserService(db)
    users = user_service.get_users_by_tenant(
        current_user.tenant_id, 
        skip=skip, 
        limit=limit
    )
    
    user_responses = [
        UserResponse(
            id=u.id,
            tenant_id=u.tenant_id,
            username=u.username,
            email=u.email,
            full_name=u.full_name,
            department=u.department,
            security_level=u.security_level,
            is_active=u.is_active,
            is_super_admin=u.is_super_admin,
            is_tenant_admin=u.is_tenant_admin,
            roles=u.get_role_names(),
            created_at=u.created_at,
            last_login_at=u.last_login_at
        )
        for u in users
    ]
    
    return UserListResponse(
        total=len(user_responses),
        users=user_responses
    )


@router.get("/{user_id}", response_model=UserResponse)
async def get_user(
    user_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """获取指定用户信息"""
    user_service = UserService(db)
    user = user_service.get_user_by_id(user_id)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    # 检查租户权限
    if user.tenant_id != current_user.tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    return UserResponse(
        id=user.id,
        tenant_id=user.tenant_id,
        username=user.username,
        email=user.email,
        full_name=user.full_name,
        department=user.department,
        security_level=user.security_level,
        is_active=user.is_active,
        is_super_admin=user.is_super_admin,
        is_tenant_admin=user.is_tenant_admin,
        roles=user.get_role_names(),
        created_at=user.created_at,
        last_login_at=user.last_login_at
    )


@router.post("/", response_model=UserResponse)
async def create_user(
    user_data: UserCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """创建用户"""
    # 只有租户管理员可以创建用户
    if not current_user.is_tenant_admin and not current_user.is_super_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only tenant admin can create users"
        )
    
    user_service = UserService(db)
    
    # 检查用户名是否存在
    if user_service.get_user_by_username(user_data.username):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username already exists"
        )
    
    # 检查邮箱是否存在
    if user_service.get_user_by_email(user_data.email):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already exists"
        )
    
    # 设置租户ID
    user_data.tenant_id = current_user.tenant_id
    
    user = user_service.create_user(user_data)
    
    return UserResponse(
        id=user.id,
        tenant_id=user.tenant_id,
        username=user.username,
        email=user.email,
        full_name=user.full_name,
        department=user.department,
        security_level=user.security_level,
        is_active=user.is_active,
        is_super_admin=user.is_super_admin,
        is_tenant_admin=user.is_tenant_admin,
        roles=user.get_role_names(),
        created_at=user.created_at,
        last_login_at=user.last_login_at
    )


@router.put("/{user_id}", response_model=UserResponse)
async def update_user(
    user_id: UUID,
    user_data: UserUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """更新用户"""
    user_service = UserService(db)
    user = user_service.get_user_by_id(user_id)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    # 检查权限
    if (user.tenant_id != current_user.tenant_id or
        not current_user.is_tenant_admin and not current_user.is_super_admin):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    user = user_service.update_user(user_id, user_data)
    
    return UserResponse(
        id=user.id,
        tenant_id=user.tenant_id,
        username=user.username,
        email=user.email,
        full_name=user.full_name,
        department=user.department,
        security_level=user.security_level,
        is_active=user.is_active,
        is_super_admin=user.is_super_admin,
        is_tenant_admin=user.is_tenant_admin,
        roles=user.get_role_names(),
        created_at=user.created_at,
        last_login_at=user.last_login_at
    )


@router.delete("/{user_id}")
async def delete_user(
    user_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """删除用户"""
    user_service = UserService(db)
    user = user_service.get_user_by_id(user_id)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    # 检查权限
    if not current_user.is_tenant_admin and not current_user.is_super_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    user_service.delete_user(user_id)
    
    return {"message": "User deleted successfully"}
