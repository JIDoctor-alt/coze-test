"""
知识库管理接口
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from uuid import UUID
from ...core.db.database import get_db
from ...core.auth.jwt_auth import get_current_active_user
from ...models.user import User
from ...schemas.knowledge_base import (
    KnowledgeBaseCreate,
    KnowledgeBaseUpdate,
    KnowledgeBaseResponse,
    KnowledgeBaseListResponse,
    PermissionAssign
)
from ...services.kb_service import KnowledgeBaseService

router = APIRouter()


@router.get("/", response_model=KnowledgeBaseListResponse)
async def list_knowledge_bases(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """获取知识库列表"""
    kb_service = KnowledgeBaseService(db)
    kbs = kb_service.get_knowledge_bases_by_tenant(
        current_user.tenant_id,
        user=current_user,
        skip=skip,
        limit=limit
    )
    
    kb_responses = [
        KnowledgeBaseResponse(
            id=kb.id,
            tenant_id=kb.tenant_id,
            name=kb.name,
            description=kb.description,
            embedding_model=kb.embedding_model,
            chunk_size=kb.chunk_size,
            chunk_overlap=kb.chunk_overlap,
            is_public=kb.is_public,
            owner_id=kb.owner_id,
            status=kb.status,
            doc_count=kb.doc_count,
            created_at=kb.created_at,
            updated_at=kb.updated_at
        )
        for kb in kbs
    ]
    
    return KnowledgeBaseListResponse(
        total=len(kb_responses),
        knowledge_bases=kb_responses
    )


@router.get("/{kb_id}", response_model=KnowledgeBaseResponse)
async def get_knowledge_base(
    kb_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """获取知识库详情"""
    kb_service = KnowledgeBaseService(db)
    kb = kb_service.get_knowledge_base(kb_id)
    
    if not kb:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Knowledge base not found"
        )
    
    # 检查访问权限
    if not kb_service.permission_checker.check_kb_access(current_user, kb_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    return KnowledgeBaseResponse(
        id=kb.id,
        tenant_id=kb.tenant_id,
        name=kb.name,
        description=kb.description,
        embedding_model=kb.embedding_model,
        chunk_size=kb.chunk_size,
        chunk_overlap=kb.chunk_overlap,
        is_public=kb.is_public,
        owner_id=kb.owner_id,
        status=kb.status,
        doc_count=kb.doc_count,
        created_at=kb.created_at,
        updated_at=kb.updated_at
    )


@router.post("/", response_model=KnowledgeBaseResponse)
async def create_knowledge_base(
    kb_data: KnowledgeBaseCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """创建知识库"""
    kb_service = KnowledgeBaseService(db)
    
    kb = kb_service.create_knowledge_base(
        kb_data,
        owner_id=current_user.id
    )
    
    return KnowledgeBaseResponse(
        id=kb.id,
        tenant_id=kb.tenant_id,
        name=kb.name,
        description=kb.description,
        embedding_model=kb.embedding_model,
        chunk_size=kb.chunk_size,
        chunk_overlap=kb.chunk_overlap,
        is_public=kb.is_public,
        owner_id=kb.owner_id,
        status=kb.status,
        doc_count=kb.doc_count,
        created_at=kb.created_at,
        updated_at=kb.updated_at
    )


@router.put("/{kb_id}", response_model=KnowledgeBaseResponse)
async def update_knowledge_base(
    kb_id: UUID,
    kb_data: KnowledgeBaseUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """更新知识库"""
    kb_service = KnowledgeBaseService(db)
    
    kb = kb_service.update_knowledge_base(
        kb_id,
        kb_data,
        current_user
    )
    
    if not kb:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Knowledge base not found or access denied"
        )
    
    return KnowledgeBaseResponse(
        id=kb.id,
        tenant_id=kb.tenant_id,
        name=kb.name,
        description=kb.description,
        embedding_model=kb.embedding_model,
        chunk_size=kb.chunk_size,
        chunk_overlap=kb.chunk_overlap,
        is_public=kb.is_public,
        owner_id=kb.owner_id,
        status=kb.status,
        doc_count=kb.doc_count,
        created_at=kb.created_at,
        updated_at=kb.updated_at
    )


@router.delete("/{kb_id}")
async def delete_knowledge_base(
    kb_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """删除知识库"""
    kb_service = KnowledgeBaseService(db)
    
    success = kb_service.delete_knowledge_base(kb_id, current_user)
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Knowledge base not found or access denied"
        )
    
    return {"message": "Knowledge base deleted successfully"}


@router.post("/permission")
async def assign_permission(
    perm_data: PermissionAssign,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """分配知识库权限"""
    kb_service = KnowledgeBaseService(db)
    
    # 检查调用者是否有权限管理权限
    if not kb_service.permission_checker.check_kb_permission(
        current_user, perm_data.kb_id, "manage"
    ):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    if not perm_data.user_id and not perm_data.user_group_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="user_id or user_group_id is required"
        )
    
    permission = kb_service.grant_permission(
        perm_data.kb_id,
        perm_data.user_id,
        perm_data.role,
        granted_by=current_user.id
    )
    
    return {
        "id": str(permission.id),
        "kb_id": str(permission.kb_id),
        "user_id": str(permission.user_id) if permission.user_id else None,
        "role": permission.role
    }


@router.delete("/{kb_id}/permission/{user_id}")
async def revoke_permission(
    kb_id: UUID,
    user_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """撤销知识库权限"""
    kb_service = KnowledgeBaseService(db)
    
    # 检查调用者是否有权限管理权限
    if not kb_service.permission_checker.check_kb_permission(
        current_user, kb_id, "manage"
    ):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    success = kb_service.revoke_permission(kb_id, user_id)
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Permission not found"
        )
    
    return {"message": "Permission revoked successfully"}
