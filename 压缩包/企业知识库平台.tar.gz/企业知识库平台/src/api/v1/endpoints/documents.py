"""
文档管理接口
"""
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from sqlalchemy.orm import Session
from typing import List, Optional
from uuid import UUID
from ...core.db.database import get_db
from ...core.auth.jwt_auth import get_current_active_user
from ...models.user import User
from ...schemas.document import (
    DocumentCreate,
    DocumentUpdate,
    DocumentResponse,
    DocumentListResponse
)
from ...services.document_service import DocumentService

router = APIRouter()


@router.get("/", response_model=DocumentListResponse)
async def list_documents(
    kb_id: UUID,
    skip: int = 0,
    limit: int = 100,
    status_filter: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """获取文档列表"""
    doc_service = DocumentService(db)
    
    docs = doc_service.get_documents(
        kb_id=kb_id,
        user=current_user,
        skip=skip,
        limit=limit,
        status=status_filter
    )
    
    doc_count = doc_service.get_documents_count(
        kb_id=kb_id,
        user=current_user,
        status=status_filter
    )
    
    doc_responses = [
        DocumentResponse(
            id=doc.id,
            tenant_id=doc.tenant_id,
            kb_id=doc.kb_id,
            file_name=doc.file_name,
            file_type=doc.file_type,
            file_size=doc.file_size,
            department=doc.department,
            project=doc.project,
            security_level=doc.security_level,
            tags=doc.tags or [],
            status=doc.status,
            page_count=doc.page_count,
            word_count=doc.word_count,
            created_by=doc.created_by,
            created_at=doc.created_at,
            updated_at=doc.updated_at
        )
        for doc in docs
    ]
    
    return DocumentListResponse(
        total=doc_count,
        documents=doc_responses
    )


@router.get("/{doc_id}", response_model=DocumentResponse)
async def get_document(
    doc_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """获取文档详情"""
    doc_service = DocumentService(db)
    doc = doc_service.get_document(doc_id, current_user)
    
    if not doc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Document not found or access denied"
        )
    
    return DocumentResponse(
        id=doc.id,
        tenant_id=doc.tenant_id,
        kb_id=doc.kb_id,
        file_name=doc.file_name,
        file_type=doc.file_type,
        file_size=doc.file_size,
        department=doc.department,
        project=doc.project,
        security_level=doc.security_level,
        tags=doc.tags or [],
        status=doc.status,
        page_count=doc.page_count,
        word_count=doc.word_count,
        created_by=doc.created_by,
        created_at=doc.created_at,
        updated_at=doc.updated_at
    )


@router.post("/", response_model=DocumentResponse)
async def create_document(
    kb_id: UUID,
    file: UploadFile = File(...),
    department: Optional[str] = None,
    project: Optional[str] = None,
    security_level: str = "public",
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    上传文档
    
    - kb_id: 知识库ID
    - file: 上传的文件
    - department: 部门（用于行级权限）
    - project: 项目（用于行级权限）
    - security_level: 安全等级 (public/internal/confidential/secret)
    """
    doc_service = DocumentService(db)
    
    # TODO: 实现文件上传到MinIO/OSS
    # 暂时保存文件信息
    file_info = {
        "file_path": f"/uploads/{file.filename}",
        "file_type": file.content_type,
        "file_size": 0,
        "file_hash": ""
    }
    
    doc_data = DocumentCreate(
        kb_id=kb_id,
        file_name=file.filename,
        department=department,
        project=project,
        security_level=security_level
    )
    
    doc = doc_service.create_document(
        doc_data,
        created_by=current_user.id,
        tenant_id=current_user.tenant_id,
        file_info=file_info
    )
    
    return DocumentResponse(
        id=doc.id,
        tenant_id=doc.tenant_id,
        kb_id=doc.kb_id,
        file_name=doc.file_name,
        file_type=doc.file_type,
        file_size=doc.file_size,
        department=doc.department,
        project=doc.project,
        security_level=doc.security_level,
        tags=doc.tags or [],
        status=doc.status,
        page_count=doc.page_count,
        word_count=doc.word_count,
        created_by=doc.created_by,
        created_at=doc.created_at,
        updated_at=doc.updated_at
    )


@router.put("/{doc_id}", response_model=DocumentResponse)
async def update_document(
    doc_id: UUID,
    doc_data: DocumentUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """更新文档"""
    doc_service = DocumentService(db)
    doc = doc_service.update_document(doc_id, doc_data, current_user)
    
    if not doc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Document not found or access denied"
        )
    
    return DocumentResponse(
        id=doc.id,
        tenant_id=doc.tenant_id,
        kb_id=doc.kb_id,
        file_name=doc.file_name,
        file_type=doc.file_type,
        file_size=doc.file_size,
        department=doc.department,
        project=doc.project,
        security_level=doc.security_level,
        tags=doc.tags or [],
        status=doc.status,
        page_count=doc.page_count,
        word_count=doc.word_count,
        created_by=doc.created_by,
        created_at=doc.created_at,
        updated_at=doc.updated_at
    )


@router.delete("/{doc_id}")
async def delete_document(
    doc_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """删除文档"""
    doc_service = DocumentService(db)
    success = doc_service.delete_document(doc_id, current_user)
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Document not found or access denied"
        )
    
    return {"message": "Document deleted successfully"}


@router.get("/{doc_id}/status")
async def get_document_status(
    doc_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """获取文档解析状态"""
    doc_service = DocumentService(db)
    doc = doc_service.get_document(doc_id, current_user)
    
    if not doc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Document not found or access denied"
        )
    
    return {
        "id": str(doc.id),
        "status": doc.status,
        "progress": 100 if doc.status == "completed" else 50 if doc.status == "parsing" else 0,
        "page_count": doc.page_count,
        "word_count": doc.word_count,
        "error": doc.parse_error
    }
