"""
API v1 路由
"""
from fastapi import APIRouter
from .endpoints import auth, users, knowledge_bases, documents

api_router = APIRouter()

# 注册子路由
api_router.include_router(auth.router, prefix="/auth", tags=["认证"])
api_router.include_router(users.router, prefix="/users", tags=["用户"])
api_router.include_router(knowledge_bases.router, prefix="/kb", tags=["知识库"])
api_router.include_router(documents.router, prefix="/docs", tags=["文档"])
