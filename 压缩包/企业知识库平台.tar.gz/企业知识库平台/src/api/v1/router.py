"""
API v1 主模块
"""
from . import router as api_router

__all__ = ["api_router"]
