"""
文档相关Schema
"""
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime
from uuid import UUID


class DocumentBase(BaseModel):
    """文档基础Schema"""
    file_name: str
    department: Optional[str] = None
    project: Optional[str] = None
    security_level: str = "public"
    tags: List[str] = []


class DocumentCreate(DocumentBase):
    """创建文档"""
    kb_id: UUID


class DocumentUpdate(BaseModel):
    """更新文档"""
    department: Optional[str] = None
    project: Optional[str] = None
    security_level: Optional[str] = None
    tags: Optional[List[str]] = None


class DocumentResponse(DocumentBase):
    """文档响应"""
    id: UUID
    tenant_id: UUID
    kb_id: UUID
    file_type: Optional[str] = None
    file_size: Optional[int] = None
    status: str
    page_count: Optional[int] = None
    word_count: Optional[int] = None
    created_by: Optional[UUID] = None
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class DocumentListResponse(BaseModel):
    """文档列表响应"""
    total: int
    documents: List[DocumentResponse]


class DocumentChunkResponse(BaseModel):
    """文档切片响应"""
    id: UUID
    doc_id: UUID
    chunk_index: int
    content: str
    page_num: Optional[int] = None
    
    class Config:
        from_attributes = True
