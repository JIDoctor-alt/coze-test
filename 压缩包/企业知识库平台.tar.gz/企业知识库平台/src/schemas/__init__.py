"""
Pydantic Schema 模式定义
"""
from .auth import *
from .user import *
from .knowledge_base import *
from .document import *

__all__ = [
    # auth
    "LoginRequest",
    "TokenResponse",
    # user
    "UserCreate",
    "UserUpdate", 
    "UserResponse",
    "UserListResponse",
    # knowledge_base
    "KnowledgeBaseCreate",
    "KnowledgeBaseUpdate",
    "KnowledgeBaseResponse",
    "KnowledgeBaseListResponse",
    "PermissionAssign",
    # document
    "DocumentCreate",
    "DocumentResponse",
    "DocumentListResponse",
]
