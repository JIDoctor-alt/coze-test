"""
用户相关Schema
"""
from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List
from datetime import datetime
from uuid import UUID


class UserBase(BaseModel):
    """用户基础Schema"""
    username: str = Field(..., min_length=3, max_length=100)
    email: EmailStr
    full_name: Optional[str] = None
    department: Optional[str] = None
    security_level: str = "public"


class UserCreate(UserBase):
    """创建用户"""
    password: str = Field(..., min_length=6)
    tenant_id: UUID


class UserUpdate(BaseModel):
    """更新用户"""
    email: Optional[EmailStr] = None
    full_name: Optional[str] = None
    department: Optional[str] = None
    security_level: Optional[str] = None
    is_active: Optional[bool] = None


class UserResponse(UserBase):
    """用户响应"""
    id: UUID
    tenant_id: UUID
    is_active: bool
    is_super_admin: bool
    is_tenant_admin: bool
    roles: List[str] = []
    created_at: datetime
    last_login_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True


class UserListResponse(BaseModel):
    """用户列表响应"""
    total: int
    users: List[UserResponse]
