"""
知识库相关Schema
"""
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime
from uuid import UUID


class KnowledgeBaseBase(BaseModel):
    """知识库基础Schema"""
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    embedding_model: str = "text-embedding-ada-002"
    chunk_size: int = 512
    chunk_overlap: int = 50
    is_public: str = "private"


class KnowledgeBaseCreate(KnowledgeBaseBase):
    """创建知识库"""
    pass


class KnowledgeBaseUpdate(BaseModel):
    """更新知识库"""
    name: Optional[str] = None
    description: Optional[str] = None
    config: Optional[Dict[str, Any]] = None
    status: Optional[str] = None
    is_public: Optional[str] = None


class KnowledgeBaseResponse(KnowledgeBaseBase):
    """知识库响应"""
    id: UUID
    tenant_id: UUID
    owner_id: Optional[UUID] = None
    status: str
    doc_count: int
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class KnowledgeBaseListResponse(BaseModel):
    """知识库列表响应"""
    total: int
    knowledge_bases: List[KnowledgeBaseResponse]


class PermissionAssign(BaseModel):
    """权限分配"""
    kb_id: UUID
    user_id: Optional[UUID] = None
    user_group_id: Optional[UUID] = None
    role: str = Field(..., description="角色: owner/editor/viewer/guest")
