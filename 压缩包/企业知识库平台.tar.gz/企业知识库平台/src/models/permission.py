"""
企业知识库平台 - 权限模型
"""
import uuid
from sqlalchemy import Column, String, DateTime, ForeignKey, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from datetime import datetime
from src.core.db.database import Base


class Permission(Base):
    """知识库权限模型
    
    实现RBAC的关联表，记录用户/用户组在知识库上的角色
    """
    __tablename__ = "permission"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    # 权限范围
    kb_id = Column(UUID(as_uuid=True), ForeignKey('knowledge_base.id'), nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey('user.id'), nullable=True)
    user_group_id = Column(UUID(as_uuid=True), ForeignKey('user_group.id'), nullable=True)
    
    # 角色 (owner/editor/viewer/guest)
    role = Column(String(50), nullable=False)
    
    # 自定义权限（扩展）
    custom_permissions = Column(String(500))  # JSON格式的自定义权限
    
    # 时间戳
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(UUID(as_uuid=True), ForeignKey('user.id'))
    
    # 约束
    __table_args__ = (
        UniqueConstraint('kb_id', 'user_id', name='unique_kb_user_permission'),
        UniqueConstraint('kb_id', 'user_group_id', name='unique_kb_usergroup_permission'),
    )
    
    # 关系
    knowledge_base = relationship("KnowledgeBase", back_populates="permissions")
    user = relationship("User", foreign_keys=[user_id], back_populates="permissions")
    creator = relationship("User", foreign_keys=[created_by])
    
    def __repr__(self):
        return f"<Permission kb={self.kb_id} user={self.user_id} role={self.role}>"


class UserGroup(Base):
    """用户组模型"""
    __tablename__ = "user_group"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(UUID(as_uuid=True), ForeignKey('tenant.id'), nullable=False)
    name = Column(String(100), nullable=False)
    description = Column(String(500))
    
    # 时间戳
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关系
    tenant = relationship("Tenant")
    
    def __repr__(self):
        return f"<UserGroup {self.name}>"
