"""
企业知识库平台 - 用户模型
"""
import uuid
from sqlalchemy import Column, String, DateTime, Boolean, ForeignKey, Table
from sqlalchemy.dialects.postgresql import UUID, JSON
from sqlalchemy.orm import relationship
from datetime import datetime
from src.core.db.database import Base


# 用户-角色关联表
user_roles = Table(
    'user_roles',
    Base.metadata,
    Column('user_id', UUID(as_uuid=True), ForeignKey('user.id'), primary_key=True),
    Column('role_id', UUID(as_uuid=True), ForeignKey('role.id'), primary_key=True),
    Column('created_at', DateTime, default=datetime.utcnow)
)


class User(Base):
    """用户模型"""
    __tablename__ = "user"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(UUID(as_uuid=True), ForeignKey('tenant.id'), nullable=False)
    username = Column(String(100), unique=True, nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    
    # 用户信息
    full_name = Column(String(100))
    phone = Column(String(20))
    avatar = Column(String(500))
    department = Column(String(100))  # 主部门
    position = Column(String(100))  # 职位
    
    # 安全等级 (public/internal/confidential/secret)
    security_level = Column(String(20), default="public")
    
    # 用户属性 (JSON格式存储扩展属性)
    attributes = Column(JSON, default=dict)
    
    # 状态
    is_active = Column(Boolean, default=True)
    is_super_admin = Column(Boolean, default=False)  # 系统超级管理员
    is_tenant_admin = Column(Boolean, default=False)  # 租户管理员
    is_deleted = Column(Boolean, default=False)
    
    # 安全相关
    failed_login_attempts = Column(String(10), default=0)
    locked_until = Column(DateTime, nullable=True)
    
    # 时间戳
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login_at = Column(DateTime, nullable=True)
    
    # 关系
    tenant = relationship("Tenant", back_populates="users")
    roles = relationship("Role", secondary=user_roles, back_populates="users")
    created_documents = relationship("Document", back_populates="creator")
    permissions = relationship("Permission", back_populates="user")
    
    def __repr__(self):
        return f"<User {self.username}>"
    
    def has_role(self, role_name: str) -> bool:
        """检查用户是否拥有指定角色"""
        return any(role.name == role_name for role in self.roles)
    
    def get_role_names(self) -> list:
        """获取用户的所有角色名"""
        return [role.name for role in self.roles]
