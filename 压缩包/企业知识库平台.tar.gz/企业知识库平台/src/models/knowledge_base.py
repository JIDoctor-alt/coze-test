"""
企业知识库平台 - 知识库模型
"""
import uuid
from sqlalchemy import Column, String, DateTime, Text, ForeignKey, Integer
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from datetime import datetime
from src.core.db.database import Base


class KnowledgeBase(Base):
    """知识库模型"""
    __tablename__ = "knowledge_base"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(UUID(as_uuid=True), ForeignKey('tenant.id'), nullable=False)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    
    # 知识库配置
    config = Column(JSONB, default=dict)  # 包含向量模型、切片策略等
    embedding_model = Column(String(100), default="text-embedding-ada-002")
    chunk_size = Column(Integer, default=512)
    chunk_overlap = Column(Integer, default=50)
    
    # 所有者
    owner_id = Column(UUID(as_uuid=True), ForeignKey('user.id'))
    
    # 状态
    status = Column(String(20), default="active")  # active/archived
    
    # 可见性
    is_public = Column(String(10), default="private")  # private/internal/public
    
    # 统计
    doc_count = Column(Integer, default=0)
    
    # 时间戳
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关系
    tenant = relationship("Tenant", back_populates="knowledge_bases")
    owner = relationship("User", foreign_keys=[owner_id])
    documents = relationship("Document", back_populates="knowledge_base")
    permissions = relationship("Permission", back_populates="knowledge_base")
    
    def __repr__(self):
        return f"<KnowledgeBase {self.name}>"
