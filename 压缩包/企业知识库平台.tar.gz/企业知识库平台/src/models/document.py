"""
企业知识库平台 - 文档模型
"""
import uuid
from sqlalchemy import Column, String, DateTime, Text, ForeignKey, Integer, BigInteger
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from datetime import datetime
from src.core.db.database import Base


class Document(Base):
    """文档模型"""
    __tablename__ = "document"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(UUID(as_uuid=True), ForeignKey('tenant.id'), nullable=False)
    kb_id = Column(UUID(as_uuid=True), ForeignKey('knowledge_base.id'), nullable=False)
    
    # 文件信息
    file_name = Column(String(500), nullable=False)
    file_path = Column(String(1000))  # MinIO/OSS存储路径
    file_type = Column(String(50))  # pdf/docx/xlsx/pptx/txt/markdown
    file_size = Column(BigInteger)  # 文件大小(字节)
    file_hash = Column(String(64))  # MD5/SHA256
    
    # 解析状态
    status = Column(String(20), default="pending")  
    # pending -> parsing -> completed / failed
    # 解析状态：pending-待解析, parsing-解析中, completed-已完成, failed-失败
    
    # 解析结果
    parse_error = Column(Text)  # 解析错误信息
    page_count = Column(Integer)  # 页数
    word_count = Column(Integer)  # 字数
    
    # 行级权限属性 (ABAC)
    department = Column(String(100))  # 所属部门
    project = Column(String(100))  # 所属项目
    security_level = Column(String(20), default="public")  
    # public/internal/confidential/secret
    
    # 元数据 (使用 doc_metadata 避免与 SQLAlchemy 保留名冲突)
    tags = Column(JSONB, default=list)
    doc_metadata = Column(JSONB, default=dict)  # 扩展元数据
    
    # 位置信息
    parent_id = Column(UUID(as_uuid=True), ForeignKey('document.id'))  # 父文档（目录）
    folder_path = Column(String(1000))  # 文件夹路径
    
    # 创建者
    created_by = Column(UUID(as_uuid=True), ForeignKey('user.id'))
    
    # 时间戳
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    parsed_at = Column(DateTime, nullable=True)  # 解析完成时间
    
    # 关系
    knowledge_base = relationship("KnowledgeBase", back_populates="documents")
    creator = relationship("User", foreign_keys=[created_by], back_populates="created_documents")
    chunks = relationship("DocumentChunk", back_populates="document", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Document {self.file_name}>"


class DocumentChunk(Base):
    """文档切片模型"""
    __tablename__ = "document_chunk"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    doc_id = Column(UUID(as_uuid=True), ForeignKey('document.id'), nullable=False)
    kb_id = Column(UUID(as_uuid=True), ForeignKey('knowledge_base.id'), nullable=False)
    tenant_id = Column(UUID(as_uuid=True), ForeignKey('tenant.id'), nullable=False)
    
    # 切片信息
    chunk_index = Column(Integer, nullable=False)  # 切片序号
    content = Column(Text, nullable=False)
    content_length = Column(Integer)  # 内容长度
    
    # 向量信息
    vector_id = Column(String(100))  # 向量库中的ID (ES/Milvus)
    
    # 位置信息
    page_num = Column(Integer)  # 起始页码
    position = Column(String(50))  # 位置信息 (title/paragraph/table/figure)
    
    # 权限属性（从文档继承）
    department = Column(String(100))
    project = Column(String(100))
    security_level = Column(String(20), default="public")
    
    # 元数据 (使用 chunk_meta 避免与 SQLAlchemy 保留名冲突)
    chunk_meta = Column(JSONB, default=dict)
    
    # 时间戳
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # 关系
    document = relationship("Document", back_populates="chunks")
    
    def __repr__(self):
        return f"<DocumentChunk {self.id} - {self.chunk_index}>"
