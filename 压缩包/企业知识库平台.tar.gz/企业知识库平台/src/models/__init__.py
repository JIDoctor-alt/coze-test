"""
数据库模型
"""
from .tenant import Tenant
from .user import User
from .knowledge_base import KnowledgeBase
from .document import Document, DocumentChunk
from .permission import Permission
from .role import Role, PermissionDefinition

__all__ = [
    "Tenant",
    "User", 
    "KnowledgeBase",
    "Document",
    "DocumentChunk",
    "Permission",
    "Role",
    "PermissionDefinition"
]
