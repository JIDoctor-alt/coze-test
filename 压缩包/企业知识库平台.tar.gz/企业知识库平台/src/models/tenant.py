"""
企业知识库平台 - 租户模型
"""
import uuid
from sqlalchemy import Column, String, DateTime, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from datetime import datetime
from src.core.db.database import Base


class Tenant(Base):
    """租户模型"""
    __tablename__ = "tenant"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    code = Column(String(100), unique=True, nullable=False)  # 租户编码
    description = Column(Text)
    status = Column(String(20), default="active")  # active/inactive/suspended
    settings = Column(Text)  # JSON配置
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关系
    users = relationship("User", back_populates="tenant")
    knowledge_bases = relationship("KnowledgeBase", back_populates="tenant")
    
    def __repr__(self):
        return f"<Tenant {self.name}>"
