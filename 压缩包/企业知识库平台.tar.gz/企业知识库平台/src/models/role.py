"""
企业知识库平台 - 角色模型
"""
import uuid
from sqlalchemy import Column, String, DateTime, ForeignKey, Table, Boolean
from sqlalchemy.dialects.postgresql import UUID, JSON
from sqlalchemy.orm import relationship
from datetime import datetime
from src.core.db.database import Base


# 角色-权限关联表
role_permissions = Table(
    'role_permissions',
    Base.metadata,
    Column('role_id', UUID(as_uuid=True), ForeignKey('role.id'), primary_key=True),
    Column('permission_id', UUID(as_uuid=True), ForeignKey('permission_definition.id'), primary_key=True),
    Column('created_at', DateTime, default=datetime.utcnow)
)


class Role(Base):
    """角色模型"""
    __tablename__ = "role"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(UUID(as_uuid=True), ForeignKey('tenant.id'), nullable=True)  # NULL表示系统级角色
    name = Column(String(50), unique=True, nullable=False)
    display_name = Column(String(100), nullable=False)
    description = Column(String(500))
    
    # 角色类型
    role_type = Column(String(20), default="custom")  
    # system-系统预置, tenant-租户级, custom-自定义
    
    # 是否可删除
    is_system = Column(Boolean, default=False)
    
    # 时间戳
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关系
    tenant = relationship("Tenant")
    users = relationship("User", secondary="user_roles", back_populates="roles")
    permissions = relationship("PermissionDefinition", secondary=role_permissions, back_populates="roles")
    
    def __repr__(self):
        return f"<Role {self.name}>"


class PermissionDefinition(Base):
    """权限定义模型"""
    __tablename__ = "permission_definition"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    # 权限标识
    code = Column(String(100), unique=True, nullable=False)  # 如: kb.create, doc.read
    name = Column(String(100), nullable=False)
    description = Column(String(500))
    
    # 权限分类
    category = Column(String(50))  # system/knowledge_base/document
    
    # 层级
    level = Column(String(20))  # system/tenant/kb/doc
    
    # 时间戳
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # 关系
    roles = relationship("Role", secondary=role_permissions, back_populates="permissions")
    
    def __repr__(self):
        return f"<PermissionDefinition {self.code}>"


# 预定义系统级角色
SYSTEM_ROLES = [
    {
        "name": "super_admin",
        "display_name": "超级管理员",
        "description": "系统最高权限，可管理所有租户和资源",
        "role_type": "system",
        "is_system": True
    },
    {
        "name": "tenant_admin",
        "display_name": "租户管理员",
        "description": "租户内最高权限，可管理租户内所有资源",
        "role_type": "system",
        "is_system": True
    },
    {
        "name": "kb_admin",
        "display_name": "知识库管理员",
        "description": "知识库管理员，可管理知识库配置和用户权限",
        "role_type": "system",
        "is_system": True
    },
    {
        "name": "editor",
        "display_name": "编辑者",
        "description": "可上传、编辑文档",
        "role_type": "system",
        "is_system": True
    },
    {
        "name": "viewer",
        "display_name": "查看者",
        "description": "可查看和检索文档",
        "role_type": "system",
        "is_system": True
    },
    {
        "name": "guest",
        "display_name": "访客",
        "description": "仅可查看公开内容",
        "role_type": "system",
        "is_system": True
    }
]

# 预定义权限
SYSTEM_PERMISSIONS = [
    # 系统级权限
    {"code": "system.manage", "name": "系统管理", "category": "system", "level": "system"},
    {"code": "tenant.manage", "name": "租户管理", "category": "system", "level": "tenant"},
    
    # 知识库权限
    {"code": "kb.create", "name": "创建知识库", "category": "knowledge_base", "level": "tenant"},
    {"code": "kb.manage", "name": "管理知识库", "category": "knowledge_base", "level": "kb"},
    {"code": "kb.configure", "name": "配置知识库", "category": "knowledge_base", "level": "kb"},
    {"code": "kb.permission", "name": "管理知识库权限", "category": "knowledge_base", "level": "kb"},
    
    # 文档权限
    {"code": "doc.upload", "name": "上传文档", "category": "document", "level": "kb"},
    {"code": "doc.read", "name": "查看文档", "category": "document", "level": "kb"},
    {"code": "doc.write", "name": "编辑文档", "category": "document", "level": "kb"},
    {"code": "doc.delete", "name": "删除文档", "category": "document", "level": "kb"},
    {"code": "doc.permission", "name": "管理文档权限", "category": "document", "level": "doc"},
]
