"""
用户服务

提供用户的完整业务逻辑：
1. 用户 CRUD
2. 用户认证
3. 用户权限加载
4. 用户组管理
"""

from typing import List, Dict, Any, Optional
from uuid import UUID
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_
from datetime import datetime
import re

from ..models.user import User, user_roles
from ..models.tenant import Tenant
from ..models.role import Role
from ..models.permission import Permission
from ..schemas.user import UserCreate, UserUpdate
from .permission_service import (
    PermissionService,
    UserPermissionAttributes,
    TenantContext
)
try:
    from ..core.auth.jwt_auth import get_password_hash, verify_password
except ImportError:
    # Fallback functions when passlib is not available
    import hashlib
    def get_password_hash(password: str) -> str:
        return hashlib.sha256(password.encode()).hexdigest()
    def verify_password(plain_password: str, hashed_password: str) -> bool:
        return hashlib.sha256(plain_password.encode()).hexdigest() == hashed_password


class UserService:
    """
    用户服务
    
    处理用户的完整生命周期和认证逻辑
    """
    
    def __init__(self, db: Session):
        self.db = db
        self.permission_service = PermissionService(db)
    
    # ========================================================================
    # 用户 CRUD
    # ========================================================================
    
    def create_user(
        self,
        user_data: UserCreate,
        created_by: Optional[UUID] = None
    ) -> User:
        """
        创建用户
        
        Args:
            user_data: 用户创建数据
            created_by: 创建者ID
            
        Returns:
            User: 创建的用户
        """
        # 验证租户存在
        tenant = self.db.query(Tenant).filter(
            Tenant.id == user_data.tenant_id
        ).first()
        
        if not tenant:
            raise ValueError(f"Tenant not found: {user_data.tenant_id}")
        
        # 检查用户名唯一性
        if self.get_user_by_username(user_data.username):
            raise ValueError(f"Username already exists: {user_data.username}")
        
        # 检查邮箱唯一性
        if self.get_user_by_email(user_data.email):
            raise ValueError(f"Email already exists: {user_data.email}")
        
        # 验证密码强度
        self._validate_password(user_data.password)
        
        # 创建用户
        user = User(
            username=user_data.username,
            email=user_data.email,
            password_hash=get_password_hash(user_data.password),
            tenant_id=user_data.tenant_id,
            full_name=user_data.full_name,
            department=user_data.department,
            security_level=user_data.security_level,
            is_active=True
        )
        
        self.db.add(user)
        self.db.flush()
        
        # 分配默认角色（viewer）
        self._assign_default_role(user.id, user_data.tenant_id)
        
        self.db.commit()
        self.db.refresh(user)
        
        return user
    
    def get_user_by_id(
        self,
        user_id: UUID,
        include_inactive: bool = False
    ) -> Optional[User]:
        """
        根据ID获取用户
        
        Args:
            user_id: 用户ID
            include_inactive: 是否包含已停用的用户
            
        Returns:
            User: 用户对象
        """
        query = self.db.query(User).filter(User.id == user_id)
        
        if not include_inactive:
            query = query.filter(User.is_active == True)
        
        return query.first()
    
    def get_user_by_username(
        self,
        username: str,
        include_deleted: bool = False
    ) -> Optional[User]:
        """
        根据用户名获取用户
        
        Args:
            username: 用户名
            include_deleted: 是否包含已删除的用户
            
        Returns:
            User: 用户对象
        """
        query = self.db.query(User).filter(User.username == username)
        
        if not include_deleted:
            query = query.filter(User.is_deleted == False)
        
        return query.first()
    
    def get_user_by_email(
        self,
        email: str,
        include_deleted: bool = False
    ) -> Optional[User]:
        """
        根据邮箱获取用户
        
        Args:
            email: 邮箱
            include_deleted: 是否包含已删除的用户
            
        Returns:
            User: 用户对象
        """
        query = self.db.query(User).filter(User.email == email)
        
        if not include_deleted:
            query = query.filter(User.is_deleted == False)
        
        return query.first()
    
    def get_users(
        self,
        tenant_id: UUID,
        skip: int = 0,
        limit: int = 100,
        is_active: Optional[bool] = None,
        department: Optional[str] = None,
        search_keyword: Optional[str] = None
    ) -> List[User]:
        """
        获取用户列表
        
        Args:
            tenant_id: 租户ID
            skip: 跳过数量
            limit: 返回数量
            is_active: 状态过滤
            department: 部门过滤
            search_keyword: 搜索关键词
            
        Returns:
            List[User]: 用户列表
        """
        query = self.db.query(User).filter(
            User.tenant_id == tenant_id,
            User.is_deleted == False
        )
        
        # 状态过滤
        if is_active is not None:
            query = query.filter(User.is_active == is_active)
        
        # 部门过滤
        if department:
            query = query.filter(User.department == department)
        
        # 关键词搜索
        if search_keyword:
            query = query.filter(
                or_(
                    User.username.ilike(f"%{search_keyword}%"),
                    User.full_name.ilike(f"%{search_keyword}%"),
                    User.email.ilike(f"%{search_keyword}%")
                )
            )
        
        return query.order_by(User.created_at.desc()).offset(skip).limit(limit).all()
    
    def get_users_count(
        self,
        tenant_id: UUID,
        is_active: Optional[bool] = None,
        department: Optional[str] = None
    ) -> int:
        """获取用户总数"""
        query = self.db.query(User).filter(
            User.tenant_id == tenant_id,
            User.is_deleted == False
        )
        
        if is_active is not None:
            query = query.filter(User.is_active == is_active)
        
        if department:
            query = query.filter(User.department == department)
        
        return query.count()
    
    def update_user(
        self,
        user_id: UUID,
        user_data: UserUpdate,
        updated_by: Optional[UUID] = None
    ) -> Optional[User]:
        """
        更新用户
        
        Args:
            user_id: 用户ID
            user_data: 更新数据
            updated_by: 更新者ID
            
        Returns:
            User: 更新后的用户
        """
        user = self.get_user_by_id(user_id)
        if not user:
            return None
        
        # 检查邮箱唯一性
        if user_data.email and user_data.email != user.email:
            if self.get_user_by_email(user_data.email):
                raise ValueError(f"Email already exists: {user_data.email}")
        
        # 更新字段
        update_data = user_data.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            if value is not None:
                setattr(user, key, value)
        
        user.updated_at = datetime.utcnow()
        self.db.commit()
        self.db.refresh(user)
        
        return user
    
    def delete_user(
        self,
        user_id: UUID,
        deleted_by: Optional[UUID] = None,
        soft_delete: bool = True
    ) -> bool:
        """
        删除用户
        
        Args:
            user_id: 用户ID
            deleted_by: 删除者ID
            soft_delete: 是否软删除
            
        Returns:
            bool: 是否成功
        """
        user = self.get_user_by_id(user_id)
        if not user:
            return False
        
        # 不能删除自己
        current_user = TenantContext.get_user_attrs()
        if current_user and str(current_user.user_id) == str(user_id):
            raise ValueError("Cannot delete yourself")
        
        if soft_delete:
            user.is_deleted = True
            user.is_active = False
            user.updated_at = datetime.utcnow()
        else:
            # 硬删除 - 需要先清理关联数据
            self._hard_delete_user(user)
        
        self.db.commit()
        return True
    
    # ========================================================================
    # 用户认证
    # ========================================================================
    
    def authenticate(
        self,
        username: str,
        password: str
    ) -> Optional[User]:
        """
        用户认证
        
        Args:
            username: 用户名
            password: 密码
            
        Returns:
            User: 认证成功的用户，失败返回 None
        """
        # 获取用户
        user = self.get_user_by_username(username)
        if not user:
            self._record_failed_login(None, username)
            return None
        
        # 检查账户状态
        if not user.is_active:
            return None
        
        # 检查是否被锁定
        if user.locked_until and user.locked_until > datetime.utcnow():
            return None
        
        # 验证密码
        if not verify_password(password, user.password_hash):
            self._record_failed_login(user)
            return None
        
        # 更新登录状态
        self._record_successful_login(user)
        
        return user
    
    def change_password(
        self,
        user_id: UUID,
        old_password: str,
        new_password: str
    ) -> bool:
        """
        修改密码
        
        Args:
            user_id: 用户ID
            old_password: 旧密码
            new_password: 新密码
            
        Returns:
            bool: 是否成功
        """
        user = self.get_user_by_id(user_id)
        if not user:
            return False
        
        # 验证旧密码
        if not verify_password(old_password, user.password_hash):
            return False
        
        # 验证新密码强度
        self._validate_password(new_password)
        
        # 更新密码
        user.password_hash = get_password_hash(new_password)
        user.updated_at = datetime.utcnow()
        
        # 重置登录失败次数
        user.failed_login_attempts = "0"
        user.locked_until = None
        
        self.db.commit()
        return True
    
    def reset_password(
        self,
        user_id: UUID,
        new_password: str,
        reset_by: Optional[UUID] = None
    ) -> bool:
        """
        重置密码（管理员操作）
        
        Args:
            user_id: 用户ID
            new_password: 新密码
            reset_by: 重置操作人
            
        Returns:
            bool: 是否成功
        """
        user = self.get_user_by_id(user_id)
        if not user:
            return False
        
        # 验证新密码强度
        self._validate_password(new_password)
        
        user.password_hash = get_password_hash(new_password)
        user.updated_at = datetime.utcnow()
        
        # 重置登录失败次数
        user.failed_login_attempts = "0"
        user.locked_until = None
        
        self.db.commit()
        return True
    
    # ========================================================================
    # 用户权限
    # ========================================================================
    
    def load_user_permissions(
        self,
        user_id: UUID
    ) -> UserPermissionAttributes:
        """
        加载用户的完整权限
        
        Args:
            user_id: 用户ID
            
        Returns:
            UserPermissionAttributes: 用户权限属性
        """
        user = self.get_user_by_id(user_id)
        if not user:
            raise ValueError(f"User not found: {user_id}")
        
        return self.permission_service.load_user_permissions(
            str(user_id),
            str(user.tenant_id)
        )
    
    def get_user_roles(self, user_id: UUID) -> List[str]:
        """
        获取用户的角色列表
        
        Args:
            user_id: 用户ID
            
        Returns:
            List[str]: 角色名称列表
        """
        roles = self.db.query(Role.name).join(
            user_roles, user_roles.c.role_id == Role.id
        ).filter(
            user_roles.c.user_id == user_id
        ).all()
        
        return [r[0] for r in roles]
    
    def assign_role(
        self,
        user_id: UUID,
        role_name: str,
        assigned_by: Optional[UUID] = None
    ) -> bool:
        """
        分配角色
        
        Args:
            user_id: 用户ID
            role_name: 角色名称
            assigned_by: 分配者
            
        Returns:
            bool: 是否成功
        """
        user = self.get_user_by_id(user_id)
        if not user:
            return False
        
        role = self.db.query(Role).filter(Role.name == role_name).first()
        if not role:
            raise ValueError(f"Role not found: {role_name}")
        
        # 检查是否已分配
        existing = self.db.query(user_roles).filter(
            and_(
                user_roles.c.user_id == user_id,
                user_roles.c.role_id == role.id
            )
        ).first()
        
        if existing:
            return True  # 已分配
        
        # 分配角色
        self.db.execute(
            user_roles.insert().values(
                user_id=user_id,
                role_id=role.id,
                created_at=datetime.utcnow()
            )
        )
        self.db.commit()
        
        return True
    
    def remove_role(
        self,
        user_id: UUID,
        role_name: str
    ) -> bool:
        """
        移除角色
        
        Args:
            user_id: 用户ID
            role_name: 角色名称
            
        Returns:
            bool: 是否成功
        """
        role = self.db.query(Role).filter(Role.name == role_name).first()
        if not role:
            return False
        
        result = self.db.query(user_roles).filter(
            and_(
                user_roles.c.user_id == user_id,
                user_roles.c.role_id == role.id
            )
        ).delete()
        
        self.db.commit()
        return result > 0
    
    def get_user_kb_permissions(
        self,
        user_id: UUID
    ) -> List[Dict[str, Any]]:
        """
        获取用户的知识库权限列表
        
        Args:
            user_id: 用户ID
            
        Returns:
            List[Dict]: 知识库权限列表
        """
        from ..models.knowledge_base import KnowledgeBase
        
        permissions = self.db.query(
            Permission, KnowledgeBase
        ).join(
            KnowledgeBase, KnowledgeBase.id == Permission.kb_id
        ).filter(
            Permission.user_id == user_id
        ).all()
        
        return [
            {
                "kb_id": str(p[0].kb_id),
                "kb_name": p[1].name,
                "role": p[0].role,
                "created_at": p[0].created_at
            }
            for p in permissions
        ]
    
    # ========================================================================
    # 用户状态管理
    # ========================================================================
    
    def activate_user(self, user_id: UUID) -> bool:
        """激活用户"""
        user = self.get_user_by_id(user_id, include_inactive=True)
        if not user:
            return False
        
        user.is_active = True
        user.updated_at = datetime.utcnow()
        self.db.commit()
        
        return True
    
    def deactivate_user(self, user_id: UUID) -> bool:
        """停用用户"""
        user = self.get_user_by_id(user_id)
        if not user:
            return False
        
        user.is_active = False
        user.updated_at = datetime.utcnow()
        self.db.commit()
        
        return True
    
    def lock_user(self, user_id: UUID, until: datetime) -> bool:
        """锁定用户"""
        user = self.get_user_by_id(user_id)
        if not user:
            return False
        
        user.locked_until = until
        self.db.commit()
        
        return True
    
    def unlock_user(self, user_id: UUID) -> bool:
        """解锁用户"""
        user = self.get_user_by_id(user_id, include_inactive=True)
        if not user:
            return False
        
        user.locked_until = None
        user.failed_login_attempts = "0"
        self.db.commit()
        
        return True
    
    # ========================================================================
    # 用户信息
    # ========================================================================
    
    def get_departments(
        self,
        tenant_id: UUID
    ) -> List[str]:
        """
        获取租户下的部门列表
        
        Args:
            tenant_id: 租户ID
            
        Returns:
            List[str]: 部门列表
        """
        departments = self.db.query(User.department).filter(
            User.tenant_id == tenant_id,
            User.is_deleted == False,
            User.department.isnot(None)
        ).distinct().all()
        
        return [d[0] for d in departments if d[0]]
    
    def search_users(
        self,
        tenant_id: UUID,
        keyword: str,
        limit: int = 10
    ) -> List[Dict[str, Any]]:
        """
        搜索用户
        
        Args:
            tenant_id: 租户ID
            keyword: 搜索关键词
            limit: 返回数量
            
        Returns:
            List[Dict]: 用户列表
        """
        users = self.db.query(User).filter(
            User.tenant_id == tenant_id,
            User.is_deleted == False,
            User.is_active == True,
            or_(
                User.username.ilike(f"%{keyword}%"),
                User.full_name.ilike(f"%{keyword}%"),
                User.email.ilike(f"%{keyword}%")
            )
        ).limit(limit).all()
        
        return [
            {
                "id": str(user.id),
                "username": user.username,
                "full_name": user.full_name,
                "email": user.email,
                "department": user.department
            }
            for user in users
        ]
    
    # ========================================================================
    # 辅助方法
    # ========================================================================
    
    def _validate_password(self, password: str) -> bool:
        """
        验证密码强度
        
        Args:
            password: 密码
            
        Raises:
            ValueError: 密码不符合要求
        """
        if len(password) < 6:
            raise ValueError("Password must be at least 6 characters")
        
        if len(password) > 128:
            raise ValueError("Password must be at most 128 characters")
        
        return True
    
    def _assign_default_role(
        self,
        user_id: UUID,
        tenant_id: UUID
    ):
        """分配默认角色"""
        # 查找 viewer 角色
        viewer_role = self.db.query(Role).filter(
            Role.name == "viewer",
            or_(Role.tenant_id == tenant_id, Role.tenant_id == None)
        ).first()
        
        if viewer_role:
            self.db.execute(
                user_roles.insert().values(
                    user_id=user_id,
                    role_id=viewer_role.id,
                    created_at=datetime.utcnow()
                )
            )
    
    def _record_failed_login(self, user: Optional[User], username: str = None):
        """记录登录失败"""
        if user:
            failed_count = int(user.failed_login_attempts or 0) + 1
            user.failed_login_attempts = str(failed_count)
            
            # 连续失败5次后锁定30分钟
            if failed_count >= 5:
                from datetime import timedelta
                user.locked_until = datetime.utcnow() + timedelta(minutes=30)
            
            self.db.commit()
    
    def _record_successful_login(self, user: User):
        """记录登录成功"""
        user.failed_login_attempts = "0"
        user.locked_until = None
        user.last_login_at = datetime.utcnow()
        self.db.commit()
    
    def _hard_delete_user(self, user: User):
        """硬删除用户"""
        # 删除用户角色关联
        self.db.query(user_roles).filter(
            user_roles.c.user_id == user.id
        ).delete(synchronize_session=False)
        
        # 删除用户权限
        self.db.query(Permission).filter(
            Permission.user_id == str(user.id)
        ).delete(synchronize_session=False)
        
        # 删除用户
        self.db.delete(user)


class UserGroupService:
    """
    用户组服务
    
    管理用户组和组成员
    """
    
    def __init__(self, db: Session):
        self.db = db
    
    def create_group(
        self,
        tenant_id: UUID,
        name: str,
        description: Optional[str] = None
    ):
        """创建用户组"""
        from ..models.permission import UserGroup
        
        group = UserGroup(
            tenant_id=tenant_id,
            name=name,
            description=description
        )
        
        self.db.add(group)
        self.db.commit()
        self.db.refresh(group)
        
        return group
    
    def add_member(
        self,
        group_id: UUID,
        user_id: UUID
    ) -> bool:
        """添加组成员"""
        from ..models.permission import UserGroup
        
        # 检查组成员关联表是否存在
        # TODO: 实现组成员管理
        return True
    
    def remove_member(
        self,
        group_id: UUID,
        user_id: UUID
    ) -> bool:
        """移除组成员"""
        # TODO: 实现组成员管理
        return True
    
    def get_members(
        self,
        group_id: UUID
    ) -> List[User]:
        """获取组成员列表"""
        # TODO: 实现组成员管理
        return []
