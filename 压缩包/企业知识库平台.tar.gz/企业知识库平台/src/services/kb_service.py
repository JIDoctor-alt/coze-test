"""
知识库服务
"""
from typing import Optional, List
from uuid import UUID
from sqlalchemy.orm import Session
from sqlalchemy import and_
from datetime import datetime
from ...models.knowledge_base import KnowledgeBase
from ...models.permission import Permission
from ...models.user import User
from ...schemas.knowledge_base import KnowledgeBaseCreate, KnowledgeBaseUpdate
from ...core.security.row_permission import PermissionChecker


class KnowledgeBaseService:
    """知识库服务"""
    
    def __init__(self, db: Session):
        self.db = db
        self.permission_checker = PermissionChecker(db)
    
    def create_knowledge_base(
        self, 
        kb_data: KnowledgeBaseCreate, 
        owner_id: UUID
    ) -> KnowledgeBase:
        """创建知识库"""
        kb = KnowledgeBase(
            name=kb_data.name,
            description=kb_data.description,
            tenant_id=owner_id,  # TODO: 从用户获取tenant_id
            owner_id=owner_id,
            embedding_model=kb_data.embedding_model,
            chunk_size=kb_data.chunk_size,
            chunk_overlap=kb_data.chunk_overlap,
            is_public=kb_data.is_public,
            config={
                "embedding_model": kb_data.embedding_model,
                "chunk_size": kb_data.chunk_size,
                "chunk_overlap": kb_data.chunk_overlap
            }
        )
        self.db.add(kb)
        self.db.commit()
        self.db.refresh(kb)
        
        # 创建者自动成为owner
        self.grant_permission(kb.id, owner_id, "owner")
        
        return kb
    
    def get_knowledge_base(self, kb_id: UUID) -> Optional[KnowledgeBase]:
        """获取知识库"""
        return self.db.query(KnowledgeBase).filter(
            KnowledgeBase.id == kb_id
        ).first()
    
    def get_knowledge_bases_by_tenant(
        self, 
        tenant_id: UUID,
        user: Optional[User] = None,
        skip: int = 0, 
        limit: int = 100
    ) -> List[KnowledgeBase]:
        """获取租户下的知识库列表"""
        query = self.db.query(KnowledgeBase).filter(
            KnowledgeBase.tenant_id == tenant_id,
            KnowledgeBase.status == "active"
        )
        
        # 如果不是超级管理员，需要过滤权限
        if user and not user.is_super_admin:
            # 获取用户有权限访问的知识库ID
            accessible_kb_ids = self._get_accessible_kb_ids(user, tenant_id)
            query = query.filter(KnowledgeBase.id.in_(accessible_kb_ids))
        
        return query.offset(skip).limit(limit).all()
    
    def _get_accessible_kb_ids(self, user: User, tenant_id: UUID) -> List[UUID]:
        """获取用户可访问的知识库ID列表"""
        # 获取直接授权的知识库
        direct_kbs = self.db.query(Permission.kb_id).filter(
            Permission.user_id == user.id
        ).all()
        
        # 获取公开访问的知识库
        public_kbs = self.db.query(KnowledgeBase.id).filter(
            KnowledgeBase.tenant_id == tenant_id,
            KnowledgeBase.is_public == "public"
        ).all()
        
        # 合并并去重
        kb_ids = set([kb[0] for kb in direct_kbs] + [kb[0] for kb in public_kbs])
        return list(kb_ids)
    
    def update_knowledge_base(
        self, 
        kb_id: UUID, 
        kb_data: KnowledgeBaseUpdate,
        user: User
    ) -> Optional[KnowledgeBase]:
        """更新知识库"""
        # 检查权限
        if not self.permission_checker.check_kb_permission(user, kb_id, "manage"):
            return None
        
        kb = self.get_knowledge_base(kb_id)
        if not kb:
            return None
        
        update_data = kb_data.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            if value is not None:
                setattr(kb, key, value)
        
        kb.updated_at = datetime.utcnow()
        self.db.commit()
        self.db.refresh(kb)
        return kb
    
    def delete_knowledge_base(self, kb_id: UUID, user: User) -> bool:
        """删除知识库"""
        if not self.permission_checker.check_kb_permission(user, kb_id, "delete"):
            return False
        
        kb = self.get_knowledge_base(kb_id)
        if not kb:
            return False
        
        kb.status = "archived"
        kb.updated_at = datetime.utcnow()
        self.db.commit()
        return True
    
    def grant_permission(
        self, 
        kb_id: UUID, 
        user_id: UUID, 
        role: str,
        granted_by: UUID = None
    ) -> Permission:
        """授予用户知识库权限"""
        # 检查是否已存在权限
        existing = self.db.query(Permission).filter(
            and_(
                Permission.kb_id == kb_id,
                Permission.user_id == user_id
            )
        ).first()
        
        if existing:
            existing.role = role
            existing.updated_at = datetime.utcnow()
            self.db.commit()
            self.db.refresh(existing)
            return existing
        
        permission = Permission(
            kb_id=kb_id,
            user_id=user_id,
            role=role,
            created_by=granted_by
        )
        self.db.add(permission)
        self.db.commit()
        self.db.refresh(permission)
        return permission
    
    def revoke_permission(self, kb_id: UUID, user_id: UUID) -> bool:
        """撤销用户权限"""
        permission = self.db.query(Permission).filter(
            and_(
                Permission.kb_id == kb_id,
                Permission.user_id == user_id
            )
        ).first()
        
        if permission:
            self.db.delete(permission)
            self.db.commit()
            return True
        return False
    
    def get_kb_permissions(self, kb_id: UUID) -> List[Permission]:
        """获取知识库的所有权限"""
        return self.db.query(Permission).filter(
            Permission.kb_id == kb_id
        ).all()
