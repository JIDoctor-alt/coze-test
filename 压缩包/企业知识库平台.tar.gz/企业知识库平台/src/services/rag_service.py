"""
RAG 服务 - 向量检索与智能问答

提供功能：
1. 向量检索服务（带权限过滤）
2. 混合检索（向量+关键词）
3. 对话服务（多轮对话）
4. RAG 生成
"""

from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
from sqlalchemy.orm import Session
from datetime import datetime
import json

from ..models.document import DocumentChunk, Document
from ..models.knowledge_base import KnowledgeBase
from .permission_service import (
    PermissionService,
    UserPermissionAttributes,
    TenantContext
)


@dataclass
class SearchResult:
    """检索结果"""
    chunk_id: str
    doc_id: str
    kb_id: str
    content: str
    score: float
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # 来源信息
    file_name: Optional[str] = None
    page_num: Optional[int] = None
    position: Optional[str] = None


@dataclass
class ChatMessage:
    """对话消息"""
    role: str  # user/assistant/system
    content: str
    created_at: datetime = field(default_factory=datetime.utcnow)
    references: List[SearchResult] = field(default_factory=list)


@dataclass
class ChatSession:
    """对话会话"""
    session_id: str
    user_id: str
    tenant_id: str
    kb_ids: List[str]
    created_at: datetime
    updated_at: datetime
    messages: List[ChatMessage] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


class RAGService:
    """
    RAG 服务 - 实现带权限控制的混合检索和智能问答
    
    功能：
    1. 向量检索（Vector Search）
    2. 关键词检索（BM25/Full-text）
    3. 混合检索与重排序
    4. 多轮对话
    5. RAG 生成
    """
    
    def __init__(self, db: Session):
        self.db = db
        self.permission_service = PermissionService(db)
    
    # ========================================================================
    # 向量检索
    # ========================================================================
    
    def vector_search(
        self,
        query: str,
        kb_ids: List[str],
        user_attrs: UserPermissionAttributes,
        top_k: int = 10,
        embedding_model: str = "text-embedding-ada-002"
    ) -> List[SearchResult]:
        """
        向量检索
        
        Args:
            query: 检索query
            kb_ids: 知识库ID列表
            user_attrs: 用户权限属性
            top_k: 返回结果数量
            embedding_model:  embedding模型
            
        Returns:
            List[SearchResult]: 检索结果
        """
        # 构建权限过滤条件
        filters = self.permission_service.build_vector_search_filters(
            user_attrs, kb_ids
        )
        
        # TODO: 调用 embedding 模型获取 query 向量
        # query_vector = self._get_embedding(query, embedding_model)
        
        # TODO: 调用向量数据库检索
        # results = vector_db.search(
        #     collection=self._get_collection_name(kb_ids[0]) if kb_ids else "default",
        #     vector=query_vector,
        #     top_k=top_k,
        #     filter=filters
        # )
        
        # 临时返回空结果
        return []
    
    def keyword_search(
        self,
        query: str,
        kb_ids: List[str],
        user_attrs: UserPermissionAttributes,
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        关键词检索（全文检索）
        
        Args:
            query: 检索query
            kb_ids: 知识库ID列表
            user_attrs: 用户权限属性
            top_k: 返回结果数量
            
        Returns:
            List[SearchResult]: 检索结果
        """
        # 构建 SQL 过滤条件
        filters = self.permission_service.build_document_filters(
            user_attrs, kb_ids[0] if kb_ids else None
        )
        
        # 查询切片
        query_obj = self.db.query(DocumentChunk).filter(
            DocumentChunk.kb_id.in_(kb_ids) if kb_ids else True,
            DocumentChunk.content.ilike(f"%{query}%")
        )
        
        if filters:
            query_obj = query_obj.filter(*filters)
        
        chunks = query_obj.limit(top_k).all()
        
        # 转换为 SearchResult
        results = []
        for chunk in chunks:
            # 计算简单的相关度分数
            score = self._calculate_keyword_score(query, chunk.content)
            
            results.append(SearchResult(
                chunk_id=str(chunk.id),
                doc_id=str(chunk.doc_id),
                kb_id=str(chunk.kb_id),
                content=chunk.content,
                score=score,
                metadata=chunk.metadata or {},
                page_num=chunk.page_num,
                position=chunk.position
            ))
        
        return results
    
    def hybrid_search(
        self,
        query: str,
        kb_ids: List[str],
        user_attrs: UserPermissionAttributes,
        top_k: int = 10,
        vector_weight: float = 0.7,
        keyword_weight: float = 0.3
    ) -> List[SearchResult]:
        """
        混合检索 - 结合向量检索和关键词检索
        
        Args:
            query: 检索query
            kb_ids: 知识库ID列表
            user_attrs: 用户权限属性
            top_k: 返回结果数量
            vector_weight: 向量检索权重
            keyword_weight: 关键词检索权重
            
        Returns:
            List[SearchResult]: 混合检索结果
        """
        # 并行执行向量检索和关键词检索
        vector_results = self.vector_search(
            query, kb_ids, user_attrs, top_k * 2
        )
        keyword_results = self.keyword_search(
            query, kb_ids, user_attrs, top_k * 2
        )
        
        # 合并结果
        merged = self._merge_search_results(
            vector_results,
            keyword_results,
            vector_weight,
            keyword_weight
        )
        
        # 重排序和截取
        merged.sort(key=lambda x: x.score, reverse=True)
        
        return merged[:top_k]
    
    def search(
        self,
        query: str,
        kb_ids: Optional[List[str]] = None,
        user_attrs: Optional[UserPermissionAttributes] = None,
        top_k: int = 10,
        search_type: str = "hybrid"
    ) -> List[SearchResult]:
        """
        统一检索接口
        
        Args:
            query: 检索query
            kb_ids: 知识库ID列表（可选）
            user_attrs: 用户权限属性（可选）
            top_k: 返回结果数量
            search_type: 检索类型 (vector/keyword/hybrid)
            
        Returns:
            List[SearchResult]: 检索结果
        """
        # 如果没有指定知识库，使用用户可访问的所有知识库
        if not kb_ids and user_attrs:
            kb_ids = self.permission_service.get_accessible_kb_ids(
                user_attrs, user_attrs.tenant_id
            )
        
        if not kb_ids:
            return []
        
        if search_type == "vector":
            return self.vector_search(query, kb_ids, user_attrs, top_k)
        elif search_type == "keyword":
            return self.keyword_search(query, kb_ids, user_attrs, top_k)
        else:  # hybrid
            return self.hybrid_search(query, kb_ids, user_attrs, top_k)
    
    # ========================================================================
    # 智能问答
    # ========================================================================
    
    def chat(
        self,
        query: str,
        kb_ids: Optional[List[str]] = None,
        user_attrs: Optional[UserPermissionAttributes] = None,
        session_id: Optional[str] = None,
        top_k: int = 5,
        temperature: float = 0.7,
        max_tokens: int = 1000
    ) -> Dict[str, Any]:
        """
        智能问答
        
        Args:
            query: 用户问题
            kb_ids: 知识库ID列表
            user_attrs: 用户权限属性
            session_id: 会话ID（用于多轮对话）
            top_k: 检索的文档块数量
            temperature: LLM 温度参数
            max_tokens: 最大生成 token 数
            
        Returns:
            Dict: 问答结果，包含 answer 和 references
        """
        # 1. 检索相关文档（带权限过滤）
        search_results = self.search(
            query=query,
            kb_ids=kb_ids,
            user_attrs=user_attrs,
            top_k=top_k,
            search_type="hybrid"
        )
        
        # 2. 获取对话历史（用于多轮对话）
        conversation_history = []
        if session_id:
            conversation_history = self._get_conversation_history(session_id)
        
        # 3. 构建 Prompt
        prompt = self._build_prompt(query, search_results, conversation_history)
        
        # 4. 调用 LLM 生成答案
        # answer = self._generate_answer(
        #     prompt=prompt,
        #     temperature=temperature,
        #     max_tokens=max_tokens
        # )
        
        # 临时返回空结果
        return {
            "answer": "",
            "references": [
                {
                    "chunk_id": r.chunk_id,
                    "content": r.content[:200] + "..." if len(r.content) > 200 else r.content,
                    "score": r.score,
                    "file_name": r.file_name,
                    "page_num": r.page_num
                }
                for r in search_results
            ],
            "session_id": session_id,
            "sources_count": len(search_results)
        }
    
    def create_session(
        self,
        user_id: str,
        tenant_id: str,
        kb_ids: List[str],
        metadata: Optional[Dict[str, Any]] = None
    ) -> ChatSession:
        """
        创建对话会话
        
        Args:
            user_id: 用户ID
            tenant_id: 租户ID
            kb_ids: 知识库ID列表
            metadata: 元数据
            
        Returns:
            ChatSession: 对话会话
        """
        import uuid
        
        session = ChatSession(
            session_id=str(uuid.uuid4()),
            user_id=user_id,
            tenant_id=tenant_id,
            kb_ids=kb_ids,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
            metadata=metadata or {}
        )
        
        # TODO: 保存到数据库或缓存
        # self._save_session(session)
        
        return session
    
    def get_session(self, session_id: str) -> Optional[ChatSession]:
        """获取对话会话"""
        # TODO: 从数据库或缓存获取
        return None
    
    def delete_session(self, session_id: str) -> bool:
        """删除对话会话"""
        # TODO: 从数据库或缓存删除
        return True
    
    # ========================================================================
    # RAG 生成
    # ========================================================================
    
    def generate_summary(
        self,
        doc_id: str,
        user_attrs: Optional[UserPermissionAttributes] = None
    ) -> str:
        """
        生成文档摘要
        
        Args:
            doc_id: 文档ID
            user_attrs: 用户权限属性
            
        Returns:
            str: 摘要内容
        """
        # 获取文档切片
        chunks = self.db.query(DocumentChunk).filter(
            DocumentChunk.doc_id == doc_id
        ).limit(10).all()
        
        if not chunks:
            return ""
        
        # 合并切片内容
        content = "\n\n".join([c.content for c in chunks])
        
        # TODO: 调用 LLM 生成摘要
        # prompt = f"请为以下内容生成简洁摘要（不超过200字）：\n\n{content}"
        # summary = self._generate_answer(prompt)
        
        return ""
    
    def extract_key_points(
        self,
        kb_id: str,
        user_attrs: Optional[UserPermissionAttributes] = None,
        limit: int = 10
    ) -> List[str]:
        """
        提取知识库的关键知识点
        
        Args:
            kb_id: 知识库ID
            user_attrs: 用户权限属性
            limit: 返回数量
            
        Returns:
            List[str]: 关键知识点列表
        """
        # 获取知识库切片
        query = self.db.query(DocumentChunk).filter(
            DocumentChunk.kb_id == kb_id
        )
        
        if user_attrs:
            filters = self.permission_service.build_document_filters(
                user_attrs, kb_id
            )
            if filters:
                query = query.filter(*filters)
        
        chunks = query.limit(limit * 2).all()
        
        # TODO: 调用 LLM 提取关键点
        # content = "\n\n".join([c.content for c in chunks])
        # prompt = f"从以下内容中提取{limit}个关键知识点：\n\n{content}"
        # key_points = self._generate_answer(prompt)
        
        return []
    
    # ========================================================================
    # 辅助方法
    # ========================================================================
    
    def _merge_search_results(
        self,
        vector_results: List[SearchResult],
        keyword_results: List[SearchResult],
        vector_weight: float,
        keyword_weight: float
    ) -> List[SearchResult]:
        """合并向量检索和关键词检索结果"""
        # 构建 ID 到结果的映射
        result_map: Dict[str, SearchResult] = {}
        
        # 归一化向量检索分数
        max_vector_score = max((r.score for r in vector_results), default=1)
        for r in vector_results:
            normalized_score = r.score / max_vector_score if max_vector_score > 0 else 0
            result_map[r.chunk_id] = SearchResult(
                chunk_id=r.chunk_id,
                doc_id=r.doc_id,
                kb_id=r.kb_id,
                content=r.content,
                score=normalized_score * vector_weight,
                metadata=r.metadata,
                file_name=r.file_name,
                page_num=r.page_num,
                position=r.position
            )
        
        # 归一化关键词检索分数并合并
        max_keyword_score = max((r.score for r in keyword_results), default=1)
        for r in keyword_results:
            normalized_score = r.score / max_keyword_score if max_keyword_score > 0 else 0
            if r.chunk_id in result_map:
                # 已有结果，累加分数
                existing = result_map[r.chunk_id]
                existing.score += normalized_score * keyword_weight
            else:
                result_map[r.chunk_id] = SearchResult(
                    chunk_id=r.chunk_id,
                    doc_id=r.doc_id,
                    kb_id=r.kb_id,
                    content=r.content,
                    score=normalized_score * keyword_weight,
                    metadata=r.metadata,
                    file_name=r.file_name,
                    page_num=r.page_num,
                    position=r.position
                )
        
        return list(result_map.values())
    
    def _calculate_keyword_score(self, query: str, content: str) -> float:
        """计算关键词相关度分数（简单的 TF-IDF 变体）"""
        query_terms = set(query.lower().split())
        content_lower = content.lower()
        
        # 词项匹配数
        match_count = sum(1 for term in query_terms if term in content_lower)
        
        # 相对密度
        density = match_count / len(query_terms) if query_terms else 0
        
        # 位置得分（出现在前面的权重更高）
        position_score = 0
        first_pos = content_lower.find(query)
        if first_pos >= 0:
            position_score = max(0, 1 - first_pos / len(content))
        
        return (density * 0.6 + position_score * 0.4)
    
    def _build_prompt(
        self,
        query: str,
        search_results: List[SearchResult],
        conversation_history: List[ChatMessage]
    ) -> str:
        """构建 RAG Prompt"""
        # 系统提示
        system_prompt = """你是一个专业的知识库问答助手。请根据提供的参考内容回答用户的问题。

要求：
1. 回答要准确、简洁
2. 如果参考内容中没有相关信息，请明确说明"根据当前知识库无法回答这个问题"
3. 引用参考内容时要指明来源
4. 保持回答的专业性和客观性
"""
        
        # 构建参考内容
        references = []
        for idx, result in enumerate(search_results, 1):
            ref_text = f"[{idx}] {result.content}"
            if result.file_name:
                ref_text += f" (来源: {result.file_name}"
                if result.page_num:
                    ref_text += f", 第{result.page_num}页"
                ref_text += ")"
            references.append(ref_text)
        
        references_text = "\n\n".join(references) if references else "暂无相关参考内容"
        
        # 构建对话历史
        history_text = ""
        for msg in conversation_history[-5:]:  # 只使用最近5条
            if msg.role == "user":
                history_text += f"\n用户: {msg.content}"
            else:
                history_text += f"\n助手: {msg.content}"
        
        # 完整 Prompt
        prompt = f"""{system_prompt}

{history_text}

参考内容：
{references_text}

用户问题: {query}

请根据参考内容回答用户的问题。
"""
        
        return prompt
    
    def _get_conversation_history(
        self,
        session_id: str
    ) -> List[ChatMessage]:
        """获取对话历史"""
        # TODO: 从数据库或缓存获取
        return []
    
    def _get_embedding(
        self,
        text: str,
        model: str = "text-embedding-ada-002"
    ) -> List[float]:
        """
        获取文本 embedding
        
        Args:
            text: 文本内容
            model: embedding 模型
            
        Returns:
            List[float]: embedding 向量
        """
        # TODO: 调用 embedding API
        # 临时返回随机向量
        import random
        return [random.random() for _ in range(1536)]
    
    def _generate_answer(
        self,
        prompt: str,
        temperature: float = 0.7,
        max_tokens: int = 1000
    ) -> str:
        """
        调用 LLM 生成答案
        
        Args:
            prompt: 输入 prompt
            temperature: 温度参数
            max_tokens: 最大 token 数
            
        Returns:
            str: 生成的答案
        """
        # TODO: 调用 LLM API
        return ""


class VectorStoreClient:
    """
    向量存储客户端接口
    
    定义向量存储的统一操作接口
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.client = None
    
    def connect(self):
        """连接向量存储"""
        raise NotImplementedError
    
    def disconnect(self):
        """断开连接"""
        raise NotImplementedError
    
    def search(
        self,
        collection: str,
        vector: List[float],
        top_k: int,
        filter: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """向量检索"""
        raise NotImplementedError
    
    def add(
        self,
        collection: str,
        vectors: List[Dict[str, Any]]
    ) -> List[str]:
        """添加向量"""
        raise NotImplementedError
    
    def delete(
        self,
        collection: str,
        ids: List[str]
    ) -> bool:
        """删除向量"""
        raise NotImplementedError
    
    def create_collection(
        self,
        collection: str,
        dimension: int,
        metadata_schema: Optional[Dict[str, Any]] = None
    ) -> bool:
        """创建 Collection"""
        raise NotImplementedError


class ElasticsearchVectorClient(VectorStoreClient):
    """Elasticsearch 向量客户端实现"""
    
    def connect(self):
        import os
        host = self.config.get("host", "localhost")
        port = self.config.get("port", 9200)
        # self.client = Elasticsearch([f"http://{host}:{port}"])
    
    def search(self, collection: str, vector: List[float], top_k: int, filter=None):
        # TODO: 实现 ES 向量搜索
        return []
    
    def add(self, collection: str, vectors: List[Dict[str, Any]]):
        # TODO: 实现 ES 添加向量
        return []
    
    def delete(self, collection: str, ids: List[str]):
        # TODO: 实现 ES 删除向量
        return True


class MilvusVectorClient(VectorStoreClient):
    """Milvus 向量客户端实现"""
    
    def connect(self):
        # TODO: 实现 Milvus 连接
        pass
    
    def search(self, collection: str, vector: List[float], top_k: int, filter=None):
        # TODO: 实现 Milvus 搜索
        return []
    
    def add(self, collection: str, vectors: List[Dict[str, Any]]):
        # TODO: 实现 Milvus 添加向量
        return []
    
    def delete(self, collection: str, ids: List[str]):
        # TODO: 实现 Milvus 删除向量
        return True
