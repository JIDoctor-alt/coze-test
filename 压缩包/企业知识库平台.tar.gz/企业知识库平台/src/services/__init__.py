"""
服务层模块

提供核心业务逻辑服务
"""

from .permission_service import (
    PermissionService,
    PermissionCode,
    RoleCode,
    DataScope,
    TenantContext,
    UserPermissionAttributes,
    PermissionContextManager,
)
from .user_service import UserService, UserGroupService
from .knowledge_base_service import KnowledgeBaseService, KnowledgeBaseFileHandler
from .document_service import DocumentService, DocumentParser
from .rag_service import RAGService, SearchResult, ChatSession, ChatMessage

__all__ = [
    # 权限服务
    "PermissionService",
    "PermissionCode",
    "RoleCode",
    "DataScope",
    "TenantContext",
    "UserPermissionAttributes",
    "PermissionContextManager",
    
    # 用户服务
    "UserService",
    "UserGroupService",
    
    # 知识库服务
    "KnowledgeBaseService",
    "KnowledgeBaseFileHandler",
    
    # 文档服务
    "DocumentService",
    "DocumentParser",
    
    # RAG 服务
    "RAGService",
    "SearchResult",
    "ChatSession",
    "ChatMessage",
]
