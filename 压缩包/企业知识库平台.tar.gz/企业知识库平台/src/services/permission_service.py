"""
权限服务 - RBAC+ABAC 混合权限模型

实现功能：
1. 权限校验核心逻辑
2. 租户上下文管理
3. 角色权限管理
4. 数据权限范围控制

参考: 06-权限体系与数据隔离设计.md
"""

from typing import List, Dict, Any, Optional, Set
from uuid import UUID
from dataclasses import dataclass, field
from enum import Enum
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func
import threading


# ============================================================================
# 权限标识定义
# ============================================================================

class PermissionCode:
    """权限标识常量"""
    # 系统级权限
    SYSTEM_MANAGE = "system:manage"
    TENANT_MANAGE = "tenant:manage"
    
    # 知识库权限
    KB_CREATE = "kb:create"
    KB_READ = "kb:read"
    KB_UPDATE = "kb:update"
    KB_DELETE = "kb:delete"
    KB_MANAGE = "kb:manage"
    KB_CONFIG = "kb:config"
    KB_PERMISSION = "kb:permission"
    
    # 文档权限
    DOC_UPLOAD = "doc:upload"
    DOC_READ = "doc:read"
    DOC_WRITE = "doc:write"
    DOC_DELETE = "doc:delete"
    DOC_SHARE = "doc:share"
    DOC_PERMISSION = "doc:permission"
    
    # RAG权限
    RAG_SEARCH = "rag:search"
    RAG_CHAT = "rag:chat"


class RoleCode:
    """角色标识常量"""
    SUPER_ADMIN = "super_admin"
    TENANT_ADMIN = "tenant_admin"
    KB_ADMIN = "kb_admin"
    EDITOR = "editor"
    VIEWER = "viewer"
    GUEST = "guest"


class DataScope(Enum):
    """数据权限范围"""
    ALL = 1           # 全部数据
    CUSTOM = 2        # 自定义数据
    DEPT_ONLY = 3     # 本部门数据
    DEPT_AND_CHILD = 4  # 本部门及下级
    SELF_ONLY = 5    # 仅本人数据
    TAG_FILTER = 6    # 标签过滤


# ============================================================================
# 租户上下文管理
# ============================================================================

class TenantContext:
    """
    租户上下文管理器
    
    使用 ThreadLocal 存储当前请求的租户信息，
    确保在同一线程内的所有操作都能访问到正确的租户上下文。
    """
    
    _local = threading.local()
    
    @classmethod
    def set_context(
        cls,
        tenant_id: str,
        user_id: str,
        user_attrs: Optional['UserPermissionAttributes'] = None
    ):
        """
        设置租户上下文
        
        Args:
            tenant_id: 租户ID
            user_id: 用户ID
            user_attrs: 用户权限属性
        """
        cls._local.tenant_id = tenant_id
        cls._local.user_id = user_id
        cls._local.user_attrs = user_attrs
    
    @classmethod
    def get_tenant_id(cls) -> Optional[str]:
        """获取当前租户ID"""
        return getattr(cls._local, 'tenant_id', None)
    
    @classmethod
    def get_user_id(cls) -> Optional[str]:
        """获取当前用户ID"""
        return getattr(cls._local, 'user_id', None)
    
    @classmethod
    def get_user_attrs(cls) -> Optional['UserPermissionAttributes']:
        """获取当前用户权限属性"""
        return getattr(cls._local, 'user_attrs', None)
    
    @classmethod
    def clear(cls):
        """清除租户上下文"""
        cls._local.tenant_id = None
        cls._local.user_id = None
        cls._local.user_attrs = None
    
    @classmethod
    def is_set(cls) -> bool:
        """检查上下文是否已设置"""
        return getattr(cls._local, 'tenant_id', None) is not None


# ============================================================================
# 数据结构定义
# ============================================================================

@dataclass
class UserPermissionAttributes:
    """
    用户权限属性 - ABAC 决策核心
    
    包含权限判断所需的所有用户属性
    """
    user_id: str
    tenant_id: str
    username: str
    
    # ABAC 属性
    department: Optional[str] = None
    departments: List[str] = field(default_factory=list)  # 可访问的部门列表
    projects: List[str] = field(default_factory=list)    # 可参与的项目
    security_level: str = "public"                       # 用户安全等级
    tags: List[str] = field(default_factory=list)       # 可访问的标签
    data_scope: DataScope = DataScope.DEPT_ONLY          # 数据权限范围
    
    # RBAC 属性
    roles: List[str] = field(default_factory=list)      # 角色列表
    direct_permissions: Set[str] = field(default_factory=set)  # 直接授予的权限
    kb_permissions: Dict[str, str] = field(default_factory=dict)  # 知识库级别权限 {kb_id: role}
    
    # 管理员标识
    is_super_admin: bool = False
    is_tenant_admin: bool = False
    
    def has_role(self, role: str) -> bool:
        """检查是否拥有指定角色"""
        return role in self.roles
    
    def has_permission(self, permission: str) -> bool:
        """检查是否拥有指定权限"""
        # 直接权限检查
        if permission in self.direct_permissions:
            return True
        
        # 超级管理员拥有所有权限
        if self.is_super_admin:
            return True
        
        # 租户管理员拥有租户内所有权限
        if self.is_tenant_admin and not permission.startswith("system:"):
            return True
        
        # 角色权限检查
        return self._check_role_permission(permission)
    
    def get_kb_role(self, kb_id: str) -> Optional[str]:
        """获取用户在指定知识库的角色"""
        return self.kb_permissions.get(kb_id)
    
    def can_access_kb(self, kb_id: str) -> bool:
        """检查是否可以访问指定知识库"""
        if self.is_super_admin:
            return True
        if self.is_tenant_admin:
            return True
        return kb_id in self.kb_permissions
    
    def _check_role_permission(self, permission: str) -> bool:
        """根据角色检查权限"""
        role_permissions_map = {
            RoleCode.SUPER_ADMIN: [
                PermissionCode.SYSTEM_MANAGE,
                PermissionCode.TENANT_MANAGE,
                PermissionCode.KB_CREATE, PermissionCode.KB_READ,
                PermissionCode.KB_UPDATE, PermissionCode.KB_DELETE,
                PermissionCode.KB_MANAGE, PermissionCode.KB_CONFIG,
                PermissionCode.KB_PERMISSION,
                PermissionCode.DOC_UPLOAD, PermissionCode.DOC_READ,
                PermissionCode.DOC_WRITE, PermissionCode.DOC_DELETE,
                PermissionCode.DOC_SHARE, PermissionCode.DOC_PERMISSION,
                PermissionCode.RAG_SEARCH, PermissionCode.RAG_CHAT,
            ],
            RoleCode.TENANT_ADMIN: [
                PermissionCode.TENANT_MANAGE,
                PermissionCode.KB_CREATE, PermissionCode.KB_READ,
                PermissionCode.KB_UPDATE, PermissionCode.KB_DELETE,
                PermissionCode.KB_MANAGE, PermissionCode.KB_CONFIG,
                PermissionCode.KB_PERMISSION,
                PermissionCode.DOC_UPLOAD, PermissionCode.DOC_READ,
                PermissionCode.DOC_WRITE, PermissionCode.DOC_DELETE,
                PermissionCode.DOC_SHARE, PermissionCode.DOC_PERMISSION,
                PermissionCode.RAG_SEARCH, PermissionCode.RAG_CHAT,
            ],
            RoleCode.KB_ADMIN: [
                PermissionCode.KB_READ, PermissionCode.KB_UPDATE,
                PermissionCode.KB_MANAGE, PermissionCode.KB_CONFIG,
                PermissionCode.KB_PERMISSION,
                PermissionCode.DOC_UPLOAD, PermissionCode.DOC_READ,
                PermissionCode.DOC_WRITE, PermissionCode.DOC_DELETE,
                PermissionCode.DOC_SHARE, PermissionCode.DOC_PERMISSION,
                PermissionCode.RAG_SEARCH, PermissionCode.RAG_CHAT,
            ],
            RoleCode.EDITOR: [
                PermissionCode.DOC_UPLOAD, PermissionCode.DOC_READ,
                PermissionCode.DOC_WRITE,
                PermissionCode.RAG_SEARCH, PermissionCode.RAG_CHAT,
            ],
            RoleCode.VIEWER: [
                PermissionCode.DOC_READ,
                PermissionCode.RAG_SEARCH, PermissionCode.RAG_CHAT,
            ],
            RoleCode.GUEST: [
                PermissionCode.DOC_READ,  # 仅限公开文档
                PermissionCode.RAG_SEARCH,
            ],
        }
        
        for role in self.roles:
            perms = role_permissions_map.get(role, [])
            if permission in perms:
                return True
        return False


@dataclass
class PermissionContext:
    """权限校验上下文"""
    resource_type: str           # 资源类型: kb, doc, etc.
    resource_id: str             # 资源ID
    action: str                   # 操作: read, write, delete, etc.
    resource_attributes: Dict[str, Any] = field(default_factory=dict)  # 资源属性


# ============================================================================
# 权限服务
# ============================================================================

class PermissionService:
    """
    权限服务 - 实现 RBAC+ABAC 混合权限模型
    
    核心功能：
    1. 权限校验 - check_permission()
    2. 知识库权限管理 - manage_kb_permission()
    3. 用户权限加载 - load_user_permissions()
    4. 数据权限过滤 - build_data_filters()
    """
    
    # 知识库角色对应的操作权限
    KB_ROLE_ACTIONS = {
        "owner": ["read", "write", "delete", "manage", "config", "permission"],
        "editor": ["read", "write", "upload"],
        "viewer": ["read"],
        "guest": ["read_public"],
    }
    
    # 安全等级层级
    SECURITY_LEVELS = {
        "public": 1,
        "internal": 2,
        "confidential": 3,
        "secret": 4,
    }
    
    def __init__(self, db: Session):
        self.db = db
    
    # ========================================================================
    # 权限校验
    # ========================================================================
    
    def check_permission(
        self,
        user_attrs: UserPermissionAttributes,
        permission: str,
        resource_type: Optional[str] = None,
        resource_id: Optional[str] = None
    ) -> bool:
        """
        检查用户权限
        
        Args:
            user_attrs: 用户权限属性
            permission: 所需权限
            resource_type: 资源类型（可选）
            resource_id: 资源ID（可选）
            
        Returns:
            bool: 是否有权限
        """
        # 1. 超级管理员拥有所有权限
        if user_attrs.is_super_admin:
            return True
        
        # 2. 基础权限检查
        if not user_attrs.has_permission(permission):
            return False
        
        # 3. 资源级别权限检查（如果指定了资源）
        if resource_type and resource_id:
            return self._check_resource_permission(
                user_attrs, resource_type, resource_id, permission
            )
        
        return True
    
    def _check_resource_permission(
        self,
        user_attrs: UserPermissionAttributes,
        resource_type: str,
        resource_id: str,
        permission: str
    ) -> bool:
        """检查资源级别的权限"""
        if resource_type == "kb":
            return self._check_kb_permission(user_attrs, resource_id, permission)
        elif resource_type == "doc":
            return self._check_doc_permission(user_attrs, resource_id, permission)
        return False
    
    def _check_kb_permission(
        self,
        user_attrs: UserPermissionAttributes,
        kb_id: str,
        permission: str
    ) -> bool:
        """检查知识库权限"""
        # 租户管理员可访问租户内所有知识库
        if user_attrs.is_tenant_admin:
            return True
        
        # 检查直接的知识库权限
        kb_role = user_attrs.get_kb_role(kb_id)
        if not kb_role:
            return False
        
        # 获取角色允许的操作
        allowed_actions = self.KB_ROLE_ACTIONS.get(kb_role, [])
        
        # 映射权限到操作
        permission_action_map = {
            PermissionCode.KB_READ: "read",
            PermissionCode.DOC_READ: "read",
            PermissionCode.KB_UPDATE: "write",
            PermissionCode.DOC_WRITE: "write",
            PermissionCode.DOC_UPLOAD: "upload",
            PermissionCode.KB_DELETE: "delete",
            PermissionCode.DOC_DELETE: "delete",
            PermissionCode.KB_MANAGE: "manage",
            PermissionCode.KB_CONFIG: "config",
            PermissionCode.KB_PERMISSION: "permission",
            PermissionCode.DOC_SHARE: "share",
            PermissionCode.DOC_PERMISSION: "permission",
        }
        
        required_action = permission_action_map.get(permission)
        if required_action:
            # owner 角色拥有所有操作权限
            if kb_role == "owner":
                return True
            return required_action in allowed_actions
        
        return False
    
    def _check_doc_permission(
        self,
        user_attrs: UserPermissionAttributes,
        doc_id: str,
        permission: str
    ) -> bool:
        """检查文档权限 - 需要查询文档信息进行ABAC判断"""
        from ...models.document import Document
        
        # 获取文档
        doc = self.db.query(Document).filter(
            Document.id == doc_id
        ).first()
        
        if not doc:
            return False
        
        # 检查租户
        if str(doc.tenant_id) != user_attrs.tenant_id:
            return False
        
        # 检查知识库权限
        if not user_attrs.can_access_kb(str(doc.kb_id)):
            return False
        
        # ABAC 属性检查
        return self._check_doc_abac(user_attrs, doc)
    
    def _check_doc_abac(
        self,
        user_attrs: UserPermissionAttributes,
        doc
    ) -> bool:
        """检查文档的ABAC属性"""
        # 部门检查
        if user_attrs.departments and doc.department:
            if doc.department not in user_attrs.departments:
                return False
        
        # 项目检查
        if user_attrs.projects and doc.project:
            if doc.project not in user_attrs.projects:
                return False
        
        # 安全等级检查 - 用户只能访问 <= 自己安全等级的文档
        user_level = self.SECURITY_LEVELS.get(
            user_attrs.security_level, 1
        )
        doc_level = self.SECURITY_LEVELS.get(
            doc.security_level or "public", 1
        )
        
        return doc_level <= user_level
    
    # ========================================================================
    # 权限加载
    # ========================================================================
    
    def load_user_permissions(self, user_id: str, tenant_id: str) -> UserPermissionAttributes:
        """
        加载用户的完整权限属性
        
        Args:
            user_id: 用户ID
            tenant_id: 租户ID
            
        Returns:
            UserPermissionAttributes: 用户权限属性
        """
        from ...models.user import User
        from ...models.permission import Permission
        from ...models.role import Role, user_roles
        
        # 获取用户信息
        user = self.db.query(User).filter(User.id == user_id).first()
        if not user:
            raise ValueError(f"User not found: {user_id}")
        
        # 获取用户角色
        roles = self.db.query(Role.name).join(
            user_roles, user_roles.c.role_id == Role.id
        ).filter(
            user_roles.c.user_id == user_id
        ).all()
        role_names = [r[0] for r in roles]
        
        # 获取直接权限
        direct_perms = self.db.query(Permission).filter(
            Permission.user_id == user_id
        ).all()
        
        # 构建知识库权限映射
        kb_permissions = {}
        direct_permissions = set()
        
        for perm in direct_perms:
            if perm.kb_id:
                kb_permissions[str(perm.kb_id)] = perm.role
            if perm.custom_permissions:
                direct_permissions.update(
                    perm.custom_permissions.split(",")
                )
        
        return UserPermissionAttributes(
            user_id=str(user.id),
            tenant_id=str(tenant_id),
            username=user.username,
            department=user.department,
            departments=[user.department] if user.department else [],
            security_level=user.security_level or "public",
            roles=role_names,
            direct_permissions=direct_permissions,
            kb_permissions=kb_permissions,
            is_super_admin=user.is_super_admin,
            is_tenant_admin=user.is_tenant_admin,
        )
    
    # ========================================================================
    # 知识库权限管理
    # ========================================================================
    
    def grant_kb_permission(
        self,
        kb_id: str,
        user_id: str,
        role: str,
        granted_by: Optional[str] = None
    ) -> bool:
        """
        授予用户知识库权限
        
        Args:
            kb_id: 知识库ID
            user_id: 用户ID
            role: 角色 (owner/editor/viewer/guest)
            granted_by: 授权人ID
            
        Returns:
            bool: 是否成功
        """
        from ...models.permission import Permission
        
        # 验证角色有效性
        valid_roles = ["owner", "editor", "viewer", "guest"]
        if role not in valid_roles:
            raise ValueError(f"Invalid role: {role}")
        
        # 检查是否已存在
        existing = self.db.query(Permission).filter(
            and_(
                Permission.kb_id == kb_id,
                Permission.user_id == user_id
            )
        ).first()
        
        if existing:
            existing.role = role
            existing.updated_at = func.now()
        else:
            permission = Permission(
                kb_id=kb_id,
                user_id=user_id,
                role=role,
                created_by=granted_by
            )
            self.db.add(permission)
        
        self.db.commit()
        return True
    
    def revoke_kb_permission(self, kb_id: str, user_id: str) -> bool:
        """
        撤销用户知识库权限
        
        Args:
            kb_id: 知识库ID
            user_id: 用户ID
            
        Returns:
            bool: 是否成功
        """
        from ...models.permission import Permission
        
        result = self.db.query(Permission).filter(
            and_(
                Permission.kb_id == kb_id,
                Permission.user_id == user_id
            )
        ).delete()
        
        self.db.commit()
        return result > 0
    
    def get_kb_members(self, kb_id: str) -> List[Dict[str, Any]]:
        """
        获取知识库成员列表
        
        Args:
            kb_id: 知识库ID
            
        Returns:
            List[Dict]: 成员列表
        """
        from ...models.permission import Permission
        from ...models.user import User
        
        members = self.db.query(
            User.id, User.username, User.full_name, User.email,
            Permission.role, Permission.created_at
        ).join(
            Permission, Permission.user_id == User.id
        ).filter(
            Permission.kb_id == kb_id
        ).all()
        
        return [
            {
                "user_id": str(m[0]),
                "username": m[1],
                "full_name": m[2],
                "email": m[3],
                "role": m[4],
                "joined_at": m[5],
            }
            for m in members
        ]
    
    # ========================================================================
    # 数据权限过滤
    # ========================================================================
    
    def build_document_filters(
        self,
        user_attrs: UserPermissionAttributes,
        kb_id: Optional[str] = None
    ) -> List[Any]:
        """
        构建文档查询的权限过滤条件
        
        用于 SQLAlchemy 查询时的行级权限过滤
        
        Args:
            user_attrs: 用户权限属性
            kb_id: 知识库ID（可选）
            
        Returns:
            List[Any]: 过滤条件列表
        """
        from ...models.document import Document
        
        conditions = []
        
        # 超级管理员不过滤
        if user_attrs.is_super_admin:
            return conditions
        
        # 1. 租户隔离（必须）
        conditions.append(Document.tenant_id == user_attrs.tenant_id)
        
        # 2. 知识库过滤
        if kb_id:
            conditions.append(Document.kb_id == kb_id)
        
        # 3. 部门过滤（ABAC）
        if user_attrs.departments:
            conditions.append(
                or_(
                    Document.department.is_(None),
                    Document.department.in_(user_attrs.departments),
                    Document.department == ""
                )
            )
        
        # 4. 项目过滤（ABAC）
        if user_attrs.projects:
            conditions.append(
                or_(
                    Document.project.is_(None),
                    Document.project.in_(user_attrs.projects),
                    Document.project == ""
                )
            )
        
        # 5. 安全等级过滤
        user_level = self.SECURITY_LEVELS.get(
            user_attrs.security_level, 1
        )
        allowed_levels = [
            level for level, value in self.SECURITY_LEVELS.items()
            if value <= user_level
        ]
        conditions.append(Document.security_level.in_(allowed_levels))
        
        return conditions
    
    def build_vector_search_filters(
        self,
        user_attrs: UserPermissionAttributes,
        kb_ids: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        构建向量数据库检索的权限过滤条件
        
        用于 Elasticsearch/Milvus 等向量库的元数据过滤
        
        Args:
            user_attrs: 用户权限属性
            kb_ids: 知识库ID列表
            
        Returns:
            Dict: 向量库过滤条件
        """
        # 超级管理员不过滤
        if user_attrs.is_super_admin:
            return {}
        
        filters = {
            "bool": {
                "must": [
                    {"term": {"tenant_id": user_attrs.tenant_id}}
                ]
            }
        }
        
        must_clauses = filters["bool"]["must"]
        
        # 知识库过滤
        if kb_ids:
            # 合并用户有权限访问的知识库
            allowed_kb_ids = [
                kb_id for kb_id in kb_ids
                if user_attrs.can_access_kb(kb_id)
            ]
            if allowed_kb_ids:
                must_clauses.append({"terms": {"kb_id": allowed_kb_ids}})
            else:
                # 用户没有任何知识库权限，返回空结果
                must_clauses.append({"term": {"kb_id": "__no_access__"}})
        
        # 部门过滤
        if user_attrs.departments:
            must_clauses.append({
                "bool": {
                    "should": [
                        {"terms": {"department": user_attrs.departments}},
                        {"bool": {"must_not": {"exists": {"field": "department"}}}}
                    ],
                    "minimum_should_match": 1
                }
            })
        
        # 项目过滤
        if user_attrs.projects:
            must_clauses.append({
                "bool": {
                    "should": [
                        {"terms": {"project": user_attrs.projects}},
                        {"bool": {"must_not": {"exists": {"field": "project"}}}}
                    ],
                    "minimum_should_match": 1
                }
            })
        
        # 安全等级过滤
        user_level = self.SECURITY_LEVELS.get(user_attrs.security_level, 1)
        allowed_levels = [
            level for level, value in self.SECURITY_LEVELS.items()
            if value <= user_level
        ]
        must_clauses.append({"terms": {"security_level": allowed_levels}})
        
        return filters
    
    # ========================================================================
    # 辅助方法
    # ========================================================================
    
    def get_accessible_kb_ids(
        self,
        user_attrs: UserPermissionAttributes,
        tenant_id: str
    ) -> List[str]:
        """
        获取用户可访问的知识库ID列表
        
        Args:
            user_attrs: 用户权限属性
            tenant_id: 租户ID
            
        Returns:
            List[str]: 可访问的知识库ID列表
        """
        from ...models.knowledge_base import KnowledgeBase
        from ...models.permission import Permission
        
        # 超级管理员可访问所有
        if user_attrs.is_super_admin:
            kbs = self.db.query(KnowledgeBase.id).filter(
                KnowledgeBase.tenant_id == tenant_id,
                KnowledgeBase.status == "active"
            ).all()
            return [str(kb[0]) for kb in kbs]
        
        # 租户管理员可访问租户内所有
        if user_attrs.is_tenant_admin:
            kbs = self.db.query(KnowledgeBase.id).filter(
                KnowledgeBase.tenant_id == tenant_id,
                KnowledgeBase.status == "active"
            ).all()
            return [str(kb[0]) for kb in kbs]
        
        # 获取直接授权的知识库
        accessible = set(user_attrs.kb_permissions.keys())
        
        # 获取公开访问的知识库
        public_kbs = self.db.query(KnowledgeBase.id).filter(
            KnowledgeBase.tenant_id == tenant_id,
            KnowledgeBase.status == "active",
            KnowledgeBase.is_public == "public"
        ).all()
        accessible.update(str(kb[0]) for kb in public_kbs)
        
        return list(accessible)


class PermissionContextManager:
    """
    权限上下文管理器
    
    提供便捷的上下文管理功能
    """
    
    def __init__(self, db: Session):
        self.db = db
        self.permission_service = PermissionService(db)
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        TenantContext.clear()
        return False
    
    def set_user_context(self, user_id: str, tenant_id: str):
        """设置用户上下文"""
        user_attrs = self.permission_service.load_user_permissions(
            user_id, tenant_id
        )
        TenantContext.set_context(tenant_id, user_id, user_attrs)
        return user_attrs
    
    def get_current_user_attrs(self) -> Optional[UserPermissionAttributes]:
        """获取当前用户属性"""
        return TenantContext.get_user_attrs()
