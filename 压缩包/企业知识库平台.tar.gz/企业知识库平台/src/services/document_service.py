"""
文档服务

提供文档的完整业务逻辑：
1. 文档上传、解析、存储
2. 文档权限管理
3. 文档切片管理
4. 向量索引管理
"""

from typing import List, Dict, Any, Optional, BinaryIO
from uuid import UUID
from sqlalchemy.orm import Session
from sqlalchemy import and_, func
from datetime import datetime
import hashlib
import os
import json

from ..models.document import Document, DocumentChunk
from ..models.knowledge_base import KnowledgeBase
from ..models.user import User
from ..schemas.document import DocumentCreate, DocumentUpdate
from .permission_service import (
    PermissionService,
    PermissionCode,
    TenantContext,
    UserPermissionAttributes
)


class DocumentService:
    """
    文档服务
    
    处理文档的完整生命周期
    """
    
    # 文档状态
    STATUS_PENDING = "pending"       # 待处理
    STATUS_PARSING = "parsing"      # 解析中
    STATUS_COMPLETED = "completed"  # 已完成
    STATUS_FAILED = "failed"         # 失败
    
    def __init__(self, db: Session):
        self.db = db
        self.permission_service = PermissionService(db)
    
    # ========================================================================
    # 文档 CRUD
    # ========================================================================
    
    def create_document(
        self,
        doc_data: DocumentCreate,
        created_by: UUID,
        tenant_id: UUID,
        file_info: Optional[Dict[str, Any]] = None
    ) -> Document:
        """
        创建文档记录
        
        Args:
            doc_data: 文档创建数据
            created_by: 创建者ID
            tenant_id: 租户ID
            file_info: 文件信息（可选）
            
        Returns:
            Document: 创建的文档
        """
        # 验证知识库存在
        kb = self.db.query(KnowledgeBase).filter(
            KnowledgeBase.id == doc_data.kb_id
        ).first()
        
        if not kb:
            raise ValueError(f"Knowledge base not found: {doc_data.kb_id}")
        
        # 创建文档记录
        doc = Document(
            kb_id=doc_data.kb_id,
            tenant_id=tenant_id,
            file_name=doc_data.file_name,
            department=doc_data.department,
            project=doc_data.project,
            security_level=doc_data.security_level,
            tags=doc_data.tags,
            created_by=created_by,
            status=self.STATUS_PENDING
        )
        
        # 设置文件信息
        if file_info:
            doc.file_path = file_info.get("file_path")
            doc.file_type = file_info.get("file_type")
            doc.file_size = file_info.get("file_size")
            doc.file_hash = file_info.get("file_hash")
        
        self.db.add(doc)
        self.db.flush()
        
        # 更新知识库文档计数
        self._update_kb_doc_count(doc.kb_id)
        
        self.db.commit()
        self.db.refresh(doc)
        
        return doc
    
    def get_document(
        self,
        doc_id: UUID,
        user_attrs: Optional[UserPermissionAttributes] = None
    ) -> Optional[Document]:
        """
        获取文档详情
        
        Args:
            doc_id: 文档ID
            user_attrs: 用户权限属性
            
        Returns:
            Document: 文档对象
        """
        doc = self.db.query(Document).filter(
            Document.id == doc_id
        ).first()
        
        if not doc:
            return None
        
        # 权限校验
        if user_attrs:
            if not self._check_document_access(user_attrs, doc):
                return None
        
        return doc
    
    def get_documents(
        self,
        kb_id: UUID,
        user_attrs: Optional[UserPermissionAttributes] = None,
        skip: int = 0,
        limit: int = 100,
        status: Optional[str] = None,
        department: Optional[str] = None,
        search_keyword: Optional[str] = None
    ) -> List[Document]:
        """
        获取文档列表
        
        Args:
            kb_id: 知识库ID
            user_attrs: 用户权限属性
            skip: 跳过数量
            limit: 返回数量
            status: 状态过滤
            department: 部门过滤
            search_keyword: 搜索关键词
            
        Returns:
            List[Document]: 文档列表
        """
        # 权限检查
        if user_attrs and not self._check_kb_access(user_attrs, kb_id):
            return []
        
        query = self.db.query(Document).filter(Document.kb_id == kb_id)
        
        # 行级权限过滤
        if user_attrs:
            filters = self.permission_service.build_document_filters(
                user_attrs, str(kb_id)
            )
            if filters:
                query = query.filter(*filters)
        
        # 状态过滤
        if status:
            query = query.filter(Document.status == status)
        
        # 部门过滤
        if department:
            query = query.filter(Document.department == department)
        
        # 关键词搜索
        if search_keyword:
            query = query.filter(Document.file_name.ilike(f"%{search_keyword}%"))
        
        return query.order_by(
            Document.created_at.desc()
        ).offset(skip).limit(limit).all()
    
    def get_documents_count(
        self,
        kb_id: UUID,
        user_attrs: Optional[UserPermissionAttributes] = None,
        status: Optional[str] = None
    ) -> int:
        """获取文档数量"""
        if user_attrs and not self._check_kb_access(user_attrs, kb_id):
            return 0
        
        query = self.db.query(Document).filter(Document.kb_id == kb_id)
        
        if user_attrs:
            filters = self.permission_service.build_document_filters(
                user_attrs, str(kb_id)
            )
            if filters:
                query = query.filter(*filters)
        
        if status:
            query = query.filter(Document.status == status)
        
        return query.count()
    
    def update_document(
        self,
        doc_id: UUID,
        doc_data: DocumentUpdate,
        user_attrs: UserPermissionAttributes
    ) -> Optional[Document]:
        """
        更新文档
        
        Args:
            doc_id: 文档ID
            doc_data: 更新数据
            user_attrs: 用户权限属性
            
        Returns:
            Document: 更新后的文档
        """
        doc = self.get_document(doc_id, user_attrs)
        if not doc:
            return None
        
        # 权限检查
        if not self._check_document_write(user_attrs, doc):
            return None
        
        # 更新字段
        update_data = doc_data.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            if value is not None:
                setattr(doc, key, value)
        
        # 如果更新了标签，同步更新元数据
        if doc_data.tags is not None:
            doc.metadata = {**doc.metadata, "tags": doc_data.tags}
        
        doc.updated_at = datetime.utcnow()
        self.db.commit()
        self.db.refresh(doc)
        
        return doc
    
    def delete_document(
        self,
        doc_id: UUID,
        user_attrs: UserPermissionAttributes,
        hard_delete: bool = False
    ) -> bool:
        """
        删除文档
        
        Args:
            doc_id: 文档ID
            user_attrs: 用户权限属性
            hard_delete: 是否硬删除
            
        Returns:
            bool: 是否成功
        """
        doc = self.get_document(doc_id, user_attrs)
        if not doc:
            return False
        
        # 权限检查
        if not self._check_document_delete(user_attrs, doc):
            return False
        
        kb_id = doc.kb_id
        
        if hard_delete:
            # 删除切片
            self.db.query(DocumentChunk).filter(
                DocumentChunk.doc_id == doc_id
            ).delete(synchronize_session=False)
            
            # 删除文档
            self.db.delete(doc)
        else:
            # 软删除 - 归档文档
            doc.status = "archived"
            doc.updated_at = datetime.utcnow()
        
        self.db.commit()
        
        # 更新知识库计数
        self._update_kb_doc_count(kb_id)
        
        return True
    
    # ========================================================================
    # 文档状态管理
    # ========================================================================
    
    def update_document_status(
        self,
        doc_id: UUID,
        status: str,
        error: Optional[str] = None,
        page_count: Optional[int] = None,
        word_count: Optional[int] = None
    ) -> Optional[Document]:
        """
        更新文档状态
        
        Args:
            doc_id: 文档ID
            status: 新状态
            error: 错误信息（失败时）
            page_count: 页数
            word_count: 字数
            
        Returns:
            Document: 更新后的文档
        """
        doc = self.db.query(Document).filter(Document.id == doc_id).first()
        if not doc:
            return None
        
        doc.status = status
        
        if error:
            doc.parse_error = error
        
        if page_count is not None:
            doc.page_count = page_count
        
        if word_count is not None:
            doc.word_count = word_count
        
        if status == self.STATUS_COMPLETED:
            doc.parsed_at = datetime.utcnow()
        
        doc.updated_at = datetime.utcnow()
        self.db.commit()
        self.db.refresh(doc)
        
        # 更新知识库计数
        self._update_kb_doc_count(doc.kb_id)
        
        return doc
    
    def mark_as_parsing(self, doc_id: UUID) -> Optional[Document]:
        """标记文档为解析中"""
        return self.update_document_status(doc_id, self.STATUS_PARSING)
    
    def mark_as_completed(
        self,
        doc_id: UUID,
        page_count: Optional[int] = None,
        word_count: Optional[int] = None
    ) -> Optional[Document]:
        """标记文档为已完成"""
        return self.update_document_status(
            doc_id, self.STATUS_COMPLETED,
            page_count=page_count, word_count=word_count
        )
    
    def mark_as_failed(
        self,
        doc_id: UUID,
        error: str
    ) -> Optional[Document]:
        """标记文档为失败"""
        return self.update_document_status(
            doc_id, self.STATUS_FAILED, error=error
        )
    
    # ========================================================================
    # 文档切片管理
    # ========================================================================
    
    def create_chunks(
        self,
        doc_id: UUID,
        chunks: List[Dict[str, Any]]
    ) -> List[DocumentChunk]:
        """
        创建文档切片
        
        Args:
            doc_id: 文档ID
            chunks: 切片数据列表
            
        Returns:
            List[DocumentChunk]: 创建的切片列表
        """
        # 获取文档信息
        doc = self.db.query(Document).filter(Document.id == doc_id).first()
        if not doc:
            raise ValueError(f"Document not found: {doc_id}")
        
        created_chunks = []
        
        for idx, chunk_data in enumerate(chunks):
            chunk = DocumentChunk(
                doc_id=doc_id,
                kb_id=doc.kb_id,
                tenant_id=doc.tenant_id,
                chunk_index=chunk_data.get("chunk_index", idx),
                content=chunk_data["content"],
                content_length=len(chunk_data["content"]),
                page_num=chunk_data.get("page_num"),
                position=chunk_data.get("position", "paragraph"),
                department=chunk_data.get("department", doc.department),
                project=chunk_data.get("project", doc.project),
                security_level=chunk_data.get("security_level", doc.security_level),
                metadata=chunk_data.get("metadata", {})
            )
            
            self.db.add(chunk)
            created_chunks.append(chunk)
        
        self.db.flush()
        
        # 批量更新切片的向量ID（如果有向量服务）
        for chunk in created_chunks:
            chunk.vector_id = str(chunk.id)  # 临时使用本地ID
        
        self.db.commit()
        
        return created_chunks
    
    def get_chunks(
        self,
        doc_id: UUID,
        user_attrs: Optional[UserPermissionAttributes] = None
    ) -> List[DocumentChunk]:
        """
        获取文档切片
        
        Args:
            doc_id: 文档ID
            user_attrs: 用户权限属性
            
        Returns:
            List[DocumentChunk]: 切片列表
        """
        # 检查文档访问权限
        if user_attrs:
            if not self._check_document_access(user_attrs, doc_id):
                return []
        
        return self.db.query(DocumentChunk).filter(
            DocumentChunk.doc_id == doc_id
        ).order_by(DocumentChunk.chunk_index).all()
    
    def get_chunks_by_kb(
        self,
        kb_id: UUID,
        user_attrs: Optional[UserPermissionAttributes] = None,
        skip: int = 0,
        limit: int = 100
    ) -> List[DocumentChunk]:
        """
        获取知识库下所有文档的切片
        
        Args:
            kb_id: 知识库ID
            user_attrs: 用户权限属性
            skip: 跳过数量
            limit: 返回数量
            
        Returns:
            List[DocumentChunk]: 切片列表
        """
        if user_attrs and not self._check_kb_access(user_attrs, kb_id):
            return []
        
        query = self.db.query(DocumentChunk).filter(
            DocumentChunk.kb_id == kb_id
        )
        
        # 行级权限过滤
        if user_attrs:
            # 获取用户可访问的部门
            allowed_depts = user_attrs.departments
            if allowed_depts:
                query = query.filter(
                    (DocumentChunk.department.is_(None)) |
                    (DocumentChunk.department.in_(allowed_depts))
                )
            
            # 安全等级过滤
            user_level = self._get_security_level_value(user_attrs.security_level)
            query = query.filter(
                func.jsonb_extract_path_text(
                    DocumentChunk.security_level, ''
                ).in_(["public", "internal"])
            )
        
        return query.order_by(
            DocumentChunk.created_at.desc()
        ).offset(skip).limit(limit).all()
    
    def delete_chunks(self, doc_id: UUID) -> int:
        """
        删除文档的所有切片
        
        Args:
            doc_id: 文档ID
            
        Returns:
            int: 删除的切片数量
        """
        result = self.db.query(DocumentChunk).filter(
            DocumentChunk.doc_id == doc_id
        ).delete(synchronize_session=False)
        
        self.db.commit()
        return result
    
    # ========================================================================
    # 批量操作
    # ========================================================================
    
    def batch_update_status(
        self,
        doc_ids: List[UUID],
        status: str
    ) -> int:
        """
        批量更新文档状态
        
        Args:
            doc_ids: 文档ID列表
            status: 新状态
            
        Returns:
            int: 更新的数量
        """
        result = self.db.query(Document).filter(
            Document.id.in_(doc_ids)
        ).update(
            {"status": status, "updated_at": datetime.utcnow()},
            synchronize_session=False
        )
        
        self.db.commit()
        return result
    
    def batch_delete(
        self,
        doc_ids: List[UUID],
        user_attrs: UserPermissionAttributes
    ) -> Dict[str, Any]:
        """
        批量删除文档
        
        Args:
            doc_ids: 文档ID列表
            user_attrs: 用户权限属性
            
        Returns:
            Dict: 删除结果统计
        """
        success_count = 0
        fail_count = 0
        failed_ids = []
        
        for doc_id in doc_ids:
            if self.delete_document(doc_id, user_attrs):
                success_count += 1
            else:
                fail_count += 1
                failed_ids.append(str(doc_id))
        
        return {
            "success_count": success_count,
            "fail_count": fail_count,
            "failed_ids": failed_ids
        }
    
    # ========================================================================
    # 向量索引
    # ========================================================================
    
    def update_chunk_vector_id(
        self,
        chunk_id: UUID,
        vector_id: str
    ) -> Optional[DocumentChunk]:
        """更新切片的向量ID"""
        chunk = self.db.query(DocumentChunk).filter(
            DocumentChunk.id == chunk_id
        ).first()
        
        if chunk:
            chunk.vector_id = vector_id
            self.db.commit()
            self.db.refresh(chunk)
        
        return chunk
    
    def sync_chunks_to_vector_store(
        self,
        doc_id: UUID,
        vector_store_client: Any = None
    ) -> Dict[str, Any]:
        """
        同步文档切片到向量存储
        
        Args:
            doc_id: 文档ID
            vector_store_client: 向量存储客户端
            
        Returns:
            Dict: 同步结果
        """
        if not vector_store_client:
            # 如果没有向量存储客户端，返回成功
            return {"synced": 0, "message": "No vector store client provided"}
        
        chunks = self.db.query(DocumentChunk).filter(
            DocumentChunk.doc_id == doc_id
        ).all()
        
        synced_count = 0
        failed_count = 0
        
        for chunk in chunks:
            try:
                # 构建向量数据
                vector_data = {
                    "id": str(chunk.id),
                    "content": chunk.content,
                    "metadata": {
                        "doc_id": str(chunk.doc_id),
                        "kb_id": str(chunk.kb_id),
                        "tenant_id": str(chunk.tenant_id),
                        "chunk_index": chunk.chunk_index,
                        "page_num": chunk.page_num,
                        "position": chunk.position,
                        "department": chunk.department,
                        "project": chunk.project,
                        "security_level": chunk.security_level,
                    }
                }
                
                # 添加到向量存储
                # vector_store_client.add(vector_data)
                synced_count += 1
                
            except Exception as e:
                failed_count += 1
        
        return {
            "synced": synced_count,
            "failed": failed_count,
            "total": len(chunks)
        }
    
    # ========================================================================
    # 辅助方法
    # ========================================================================
    
    def _check_document_access(
        self,
        user_attrs: UserPermissionAttributes,
        doc: Document
    ) -> bool:
        """检查文档访问权限"""
        # 超级管理员
        if user_attrs.is_super_admin:
            return True
        
        # 租户管理员
        if user_attrs.is_tenant_admin:
            return True
        
        # 检查知识库权限
        if not user_attrs.can_access_kb(str(doc.kb_id)):
            return False
        
        # ABAC 检查
        # 部门检查
        if user_attrs.departments and doc.department:
            if doc.department not in user_attrs.departments:
                return False
        
        # 安全等级检查
        user_level = self._get_security_level_value(user_attrs.security_level)
        doc_level = self._get_security_level_value(doc.security_level or "public")
        
        return doc_level <= user_level
    
    def _check_document_write(
        self,
        user_attrs: UserPermissionAttributes,
        doc: Document
    ) -> bool:
        """检查文档写入权限"""
        if user_attrs.is_super_admin or user_attrs.is_tenant_admin:
            return True
        
        kb_role = user_attrs.get_kb_role(str(doc.kb_id))
        return kb_role in ["owner", "editor"]
    
    def _check_document_delete(
        self,
        user_attrs: UserPermissionAttributes,
        doc: Document
    ) -> bool:
        """检查文档删除权限"""
        if user_attrs.is_super_admin or user_attrs.is_tenant_admin:
            return True
        
        kb_role = user_attrs.get_kb_role(str(doc.kb_id))
        return kb_role in ["owner", "editor"]
    
    def _check_kb_access(
        self,
        user_attrs: UserPermissionAttributes,
        kb_id: UUID
    ) -> bool:
        """检查知识库访问权限"""
        if user_attrs.is_super_admin or user_attrs.is_tenant_admin:
            return True
        return user_attrs.can_access_kb(str(kb_id))
    
    def _update_kb_doc_count(self, kb_id: UUID):
        """更新知识库文档计数"""
        kb = self.db.query(KnowledgeBase).filter(
            KnowledgeBase.id == kb_id
        ).first()
        
        if kb:
            kb.doc_count = self.db.query(Document).filter(
                Document.kb_id == kb_id,
                Document.status == self.STATUS_COMPLETED
            ).count()
            self.db.commit()
    
    def _get_security_level_value(self, level: str) -> int:
        """获取安全等级数值"""
        level_map = {
            "public": 1,
            "internal": 2,
            "confidential": 3,
            "secret": 4
        }
        return level_map.get(level, 1)


class DocumentParser:
    """
    文档解析器
    
    将各种格式的文档解析为文本和切片
    """
    
    # 解析配置
    DEFAULT_CHUNK_SIZE = 512
    DEFAULT_CHUNK_OVERLAP = 50
    
    def __init__(
        self,
        chunk_size: int = DEFAULT_CHUNK_SIZE,
        chunk_overlap: int = DEFAULT_CHUNK_OVERLAP
    ):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
    
    def parse(
        self,
        file_path: str,
        file_type: str
    ) -> Dict[str, Any]:
        """
        解析文档
        
        Args:
            file_path: 文件路径
            file_type: 文件类型
            
        Returns:
            Dict: 解析结果
        """
        parser_map = {
            "pdf": self._parse_pdf,
            "word": self._parse_word,
            "excel": self._parse_excel,
            "ppt": self._parse_ppt,
            "text": self._parse_text,
            "markdown": self._parse_markdown,
            "html": self._parse_html,
        }
        
        parser = parser_map.get(file_type)
        if not parser:
            raise ValueError(f"Unsupported file type: {file_type}")
        
        return parser(file_path)
    
    def chunk_text(
        self,
        text: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """
        将文本切分为块
        
        Args:
            text: 文本内容
            metadata: 元数据
            
        Returns:
            List[Dict]: 切片列表
        """
        chunks = []
        
        # 简单的固定大小切分
        start = 0
        chunk_index = 0
        
        while start < len(text):
            end = min(start + self.chunk_size, len(text))
            
            # 如果不是最后一块，尝试在句子边界切分
            if end < len(text):
                # 寻找最近的句子结束符
                for sep in ['。', '！', '？', '.', '!', '?', '\n']:
                    last_sep = text.rfind(sep, start, end)
                    if last_sep > start:
                        end = last_sep + 1
                        break
            
            chunk = {
                "chunk_index": chunk_index,
                "content": text[start:end].strip(),
                "metadata": metadata or {}
            }
            
            chunks.append(chunk)
            
            # 移动窗口（考虑重叠）
            start = end - self.chunk_overlap
            chunk_index += 1
        
        return chunks
    
    def _parse_pdf(self, file_path: str) -> Dict[str, Any]:
        """解析 PDF"""
        # TODO: 实现 PDF 解析
        return {"text": "", "page_count": 0, "chunks": []}
    
    def _parse_word(self, file_path: str) -> Dict[str, Any]:
        """解析 Word"""
        # TODO: 实现 Word 解析
        return {"text": "", "page_count": 0, "chunks": []}
    
    def _parse_excel(self, file_path: str) -> Dict[str, Any]:
        """解析 Excel"""
        # TODO: 实现 Excel 解析
        return {"text": "", "page_count": 0, "chunks": []}
    
    def _parse_ppt(self, file_path: str) -> Dict[str, Any]:
        """解析 PPT"""
        # TODO: 实现 PPT 解析
        return {"text": "", "page_count": 0, "chunks": []}
    
    def _parse_text(self, file_path: str) -> Dict[str, Any]:
        """解析纯文本"""
        with open(file_path, 'r', encoding='utf-8') as f:
            text = f.read()
        
        chunks = self.chunk_text(text)
        
        return {
            "text": text,
            "page_count": 1,
            "word_count": len(text),
            "chunks": chunks
        }
    
    def _parse_markdown(self, file_path: str) -> Dict[str, Any]:
        """解析 Markdown"""
        with open(file_path, 'r', encoding='utf-8') as f:
            text = f.read()
        
        chunks = self.chunk_text(text)
        
        return {
            "text": text,
            "page_count": 1,
            "word_count": len(text),
            "chunks": chunks
        }
    
    def _parse_html(self, file_path: str) -> Dict[str, Any]:
        """解析 HTML"""
        # TODO: 实现 HTML 解析
        return {"text": "", "page_count": 0, "chunks": []}
