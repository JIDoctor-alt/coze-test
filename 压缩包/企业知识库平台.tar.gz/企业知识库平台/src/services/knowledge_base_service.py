"""
知识库服务

提供知识库的完整 CRUD 操作和权限管理功能：
1. 知识库 CRUD 操作
2. 知识库权限校验
3. 文档上传处理
4. 知识库成员管理
"""

from typing import List, Dict, Any, Optional
from uuid import UUID
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_
from datetime import datetime
import hashlib
import os

from ..models.knowledge_base import KnowledgeBase
from ..models.document import Document
from ..models.permission import Permission
from ..models.user import User
from ..schemas.knowledge_base import (
    KnowledgeBaseCreate, 
    KnowledgeBaseUpdate,
    PermissionAssign
)
from .permission_service import (
    PermissionService, 
    PermissionCode, 
    RoleCode,
    TenantContext,
    UserPermissionAttributes
)


class KnowledgeBaseService:
    """
    知识库服务
    
    提供知识库的完整业务逻辑处理
    """
    
    # 知识库角色对应的文档操作权限
    KB_ROLE_DOC_PERMISSIONS = {
        "owner": ["upload", "read", "write", "delete", "share"],
        "editor": ["upload", "read", "write"],
        "viewer": ["read"],
        "guest": ["read_public"],
    }
    
    def __init__(self, db: Session):
        self.db = db
        self.permission_service = PermissionService(db)
    
    # ========================================================================
    # 基础 CRUD 操作
    # ========================================================================
    
    def create_knowledge_base(
        self,
        kb_data: KnowledgeBaseCreate,
        owner_id: UUID,
        tenant_id: UUID
    ) -> KnowledgeBase:
        """
        创建知识库
        
        Args:
            kb_data: 知识库创建数据
            owner_id: 所有者用户ID
            tenant_id: 租户ID
            
        Returns:
            KnowledgeBase: 创建的知识库
        """
        # 创建知识库
        kb = KnowledgeBase(
            name=kb_data.name,
            description=kb_data.description,
            tenant_id=tenant_id,
            owner_id=owner_id,
            embedding_model=kb_data.embedding_model,
            chunk_size=kb_data.chunk_size,
            chunk_overlap=kb_data.chunk_overlap,
            is_public=kb_data.is_public,
            config={
                "embedding_model": kb_data.embedding_model,
                "chunk_size": kb_data.chunk_size,
                "chunk_overlap": kb_data.chunk_overlap,
            },
            status="active"
        )
        
        self.db.add(kb)
        self.db.flush()  # 获取ID
        
        # 创建者自动成为 owner
        self._grant_owner_permission(kb.id, owner_id, tenant_id)
        
        self.db.commit()
        self.db.refresh(kb)
        
        return kb
    
    def get_knowledge_base(
        self,
        kb_id: UUID,
        user_attrs: Optional[UserPermissionAttributes] = None
    ) -> Optional[KnowledgeBase]:
        """
        获取知识库详情
        
        Args:
            kb_id: 知识库ID
            user_attrs: 用户权限属性（用于权限校验）
            
        Returns:
            KnowledgeBase: 知识库对象
        """
        kb = self.db.query(KnowledgeBase).filter(
            KnowledgeBase.id == kb_id,
            KnowledgeBase.status == "active"
        ).first()
        
        if not kb:
            return None
        
        # 权限校验
        if user_attrs:
            if not self._check_kb_access(user_attrs, kb):
                return None
        
        return kb
    
    def get_knowledge_bases(
        self,
        tenant_id: UUID,
        user_attrs: Optional[UserPermissionAttributes] = None,
        skip: int = 0,
        limit: int = 100,
        search_keyword: Optional[str] = None
    ) -> List[KnowledgeBase]:
        """
        获取知识库列表
        
        Args:
            tenant_id: 租户ID
            user_attrs: 用户权限属性（可选，不传则返回所有）
            skip: 跳过数量
            limit: 返回数量
            search_keyword: 搜索关键词
            
        Returns:
            List[KnowledgeBase]: 知识库列表
        """
        query = self.db.query(KnowledgeBase).filter(
            KnowledgeBase.tenant_id == tenant_id,
            KnowledgeBase.status == "active"
        )
        
        # 搜索过滤
        if search_keyword:
            query = query.filter(
                or_(
                    KnowledgeBase.name.ilike(f"%{search_keyword}%"),
                    KnowledgeBase.description.ilike(f"%{search_keyword}%")
                )
            )
        
        # 权限过滤
        if user_attrs:
            accessible_kb_ids = self._get_accessible_kb_ids(user_attrs, tenant_id)
            if accessible_kb_ids:
                query = query.filter(KnowledgeBase.id.in_(accessible_kb_ids))
            else:
                return []  # 无权限访问任何知识库
        
        return query.order_by(
            KnowledgeBase.created_at.desc()
        ).offset(skip).limit(limit).all()
    
    def get_knowledge_bases_count(
        self,
        tenant_id: UUID,
        user_attrs: Optional[UserPermissionAttributes] = None,
        search_keyword: Optional[str] = None
    ) -> int:
        """获取知识库总数"""
        query = self.db.query(KnowledgeBase).filter(
            KnowledgeBase.tenant_id == tenant_id,
            KnowledgeBase.status == "active"
        )
        
        if search_keyword:
            query = query.filter(
                or_(
                    KnowledgeBase.name.ilike(f"%{search_keyword}%"),
                    KnowledgeBase.description.ilike(f"%{search_keyword}%")
                )
            )
        
        if user_attrs:
            accessible_kb_ids = self._get_accessible_kb_ids(user_attrs, tenant_id)
            if accessible_kb_ids:
                query = query.filter(KnowledgeBase.id.in_(accessible_kb_ids))
            else:
                return 0
        
        return query.count()
    
    def update_knowledge_base(
        self,
        kb_id: UUID,
        kb_data: KnowledgeBaseUpdate,
        user_attrs: UserPermissionAttributes
    ) -> Optional[KnowledgeBase]:
        """
        更新知识库
        
        Args:
            kb_id: 知识库ID
            kb_data: 更新数据
            user_attrs: 用户权限属性
            
        Returns:
            KnowledgeBase: 更新后的知识库
        """
        # 权限检查
        if not self._check_kb_permission(user_attrs, kb_id, "manage"):
            return None
        
        kb = self.get_knowledge_base(kb_id)
        if not kb:
            return None
        
        # 更新字段
        update_data = kb_data.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            if value is not None:
                setattr(kb, key, value)
        
        # 更新配置
        if kb_data.config:
            kb.config = {**kb.config, **kb_data.config}
        
        kb.updated_at = datetime.utcnow()
        self.db.commit()
        self.db.refresh(kb)
        
        return kb
    
    def delete_knowledge_base(
        self,
        kb_id: UUID,
        user_attrs: UserPermissionAttributes,
        soft_delete: bool = True
    ) -> bool:
        """
        删除知识库
        
        Args:
            kb_id: 知识库ID
            user_attrs: 用户权限属性
            soft_delete: 是否软删除（默认True）
            
        Returns:
            bool: 是否成功
        """
        # 权限检查
        if not self._check_kb_permission(user_attrs, kb_id, "delete"):
            return False
        
        kb = self.get_knowledge_base(kb_id)
        if not kb:
            return False
        
        if soft_delete:
            kb.status = "archived"
            kb.updated_at = datetime.utcnow()
            self.db.commit()
        else:
            # 硬删除 - 需要先删除相关数据
            self._hard_delete_knowledge_base(kb)
        
        return True
    
    # ========================================================================
    # 权限管理
    # ========================================================================
    
    def grant_permission(
        self,
        kb_id: UUID,
        user_id: UUID,
        role: str,
        granted_by: Optional[UUID] = None
    ) -> Optional[Permission]:
        """
        授予用户知识库权限
        
        Args:
            kb_id: 知识库ID
            user_id: 用户ID
            role: 角色 (owner/editor/viewer/guest)
            granted_by: 授权人ID
            
        Returns:
            Permission: 创建的权限记录
        """
        # 检查授权人权限
        current_user_attrs = TenantContext.get_user_attrs()
        if current_user_attrs:
            if not self._check_kb_permission(current_user_attrs, str(kb_id), "permission"):
                return None
        
        # 验证角色
        valid_roles = ["owner", "editor", "viewer", "guest"]
        if role not in valid_roles:
            raise ValueError(f"Invalid role: {role}")
        
        # 检查是否已存在
        existing = self.db.query(Permission).filter(
            and_(
                Permission.kb_id == str(kb_id),
                Permission.user_id == str(user_id)
            )
        ).first()
        
        if existing:
            existing.role = role
            existing.updated_at = datetime.utcnow()
            self.db.commit()
            self.db.refresh(existing)
            return existing
        
        permission = Permission(
            kb_id=str(kb_id),
            user_id=str(user_id),
            role=role,
            created_by=str(granted_by) if granted_by else None
        )
        self.db.add(permission)
        self.db.commit()
        self.db.refresh(permission)
        
        return permission
    
    def revoke_permission(
        self,
        kb_id: UUID,
        user_id: UUID
    ) -> bool:
        """
        撤销用户权限
        
        Args:
            kb_id: 知识库ID
            user_id: 用户ID
            
        Returns:
            bool: 是否成功
        """
        current_user_attrs = TenantContext.get_user_attrs()
        if current_user_attrs:
            if not self._check_kb_permission(current_user_attrs, str(kb_id), "permission"):
                return False
        
        # 不能撤销 owner 的权限
        existing = self.db.query(Permission).filter(
            and_(
                Permission.kb_id == str(kb_id),
                Permission.user_id == str(user_id)
            )
        ).first()
        
        if existing and existing.role == "owner":
            return False
        
        result = self.db.query(Permission).filter(
            and_(
                Permission.kb_id == str(kb_id),
                Permission.user_id == str(user_id)
            )
        ).delete()
        
        self.db.commit()
        return result > 0
    
    def get_permissions(self, kb_id: UUID) -> List[Dict[str, Any]]:
        """
        获取知识库的所有权限
        
        Args:
            kb_id: 知识库ID
            
        Returns:
            List[Dict]: 权限列表
        """
        from ..models.user import User
        
        permissions = self.db.query(
            Permission, User
        ).join(
            User, User.id == Permission.user_id
        ).filter(
            Permission.kb_id == str(kb_id)
        ).all()
        
        return [
            {
                "id": str(p[0].id),
                "user_id": str(p[0].user_id),
                "username": p[1].username,
                "full_name": p[1].full_name,
                "email": p[1].email,
                "role": p[0].role,
                "created_at": p[0].created_at,
            }
            for p in permissions
        ]
    
    def get_members(self, kb_id: UUID) -> List[Dict[str, Any]]:
        """
        获取知识库成员列表
        
        Args:
            kb_id: 知识库ID
            
        Returns:
            List[Dict]: 成员列表
        """
        return self.get_permissions(kb_id)
    
    # ========================================================================
    # 文档管理
    # ========================================================================
    
    def get_documents(
        self,
        kb_id: UUID,
        user_attrs: Optional[UserPermissionAttributes] = None,
        skip: int = 0,
        limit: int = 100,
        status: Optional[str] = None
    ) -> List[Document]:
        """
        获取知识库下的文档列表
        
        Args:
            kb_id: 知识库ID
            user_attrs: 用户权限属性（用于行级权限过滤）
            skip: 跳过数量
            limit: 返回数量
            status: 文档状态过滤
            
        Returns:
            List[Document]: 文档列表
        """
        # 检查知识库访问权限
        if user_attrs and not self._check_kb_access(user_attrs, kb_id):
            return []
        
        query = self.db.query(Document).filter(
            Document.kb_id == kb_id
        )
        
        # 行级权限过滤
        if user_attrs:
            filters = self.permission_service.build_document_filters(
                user_attrs, str(kb_id)
            )
            if filters:
                query = query.filter(*filters)
        
        # 状态过滤
        if status:
            query = query.filter(Document.status == status)
        
        return query.order_by(
            Document.created_at.desc()
        ).offset(skip).limit(limit).all()
    
    def get_documents_count(
        self,
        kb_id: UUID,
        user_attrs: Optional[UserPermissionAttributes] = None,
        status: Optional[str] = None
    ) -> int:
        """获取文档数量"""
        if user_attrs and not self._check_kb_access(user_attrs, kb_id):
            return 0
        
        query = self.db.query(Document).filter(Document.kb_id == kb_id)
        
        if user_attrs:
            filters = self.permission_service.build_document_filters(
                user_attrs, str(kb_id)
            )
            if filters:
                query = query.filter(*filters)
        
        if status:
            query = query.filter(Document.status == status)
        
        return query.count()
    
    # ========================================================================
    # 统计信息
    # ========================================================================
    
    def get_statistics(self, kb_id: UUID) -> Dict[str, Any]:
        """
        获取知识库统计信息
        
        Args:
            kb_id: 知识库ID
            
        Returns:
            Dict: 统计信息
        """
        # 文档统计
        total_docs = self.db.query(Document).filter(
            Document.kb_id == kb_id
        ).count()
        
        completed_docs = self.db.query(Document).filter(
            Document.kb_id == kb_id,
            Document.status == "completed"
        ).count()
        
        failed_docs = self.db.query(Document).filter(
            Document.kb_id == kb_id,
            Document.status == "failed"
        ).count()
        
        # 成员统计
        members_count = self.db.query(Permission).filter(
            Permission.kb_id == str(kb_id)
        ).count()
        
        return {
            "total_documents": total_docs,
            "completed_documents": completed_docs,
            "failed_documents": failed_docs,
            "pending_documents": total_docs - completed_docs - failed_docs,
            "members_count": members_count,
        }
    
    # ========================================================================
    # 内部辅助方法
    # ========================================================================
    
    def _grant_owner_permission(
        self,
        kb_id: UUID,
        user_id: UUID,
        tenant_id: UUID
    ):
        """授予所有者权限"""
        permission = Permission(
            kb_id=str(kb_id),
            user_id=str(user_id),
            role="owner",
            created_by=str(user_id)
        )
        self.db.add(permission)
    
    def _check_kb_access(
        self,
        user_attrs: UserPermissionAttributes,
        kb_id: UUID
    ) -> bool:
        """检查知识库访问权限"""
        # 超级管理员
        if user_attrs.is_super_admin:
            return True
        
        # 租户管理员
        if user_attrs.is_tenant_admin:
            return True
        
        # 检查直接权限
        return user_attrs.can_access_kb(str(kb_id))
    
    def _check_kb_permission(
        self,
        user_attrs: UserPermissionAttributes,
        kb_id: UUID,
        action: str
    ) -> bool:
        """检查知识库操作权限"""
        # 超级管理员
        if user_attrs.is_super_admin:
            return True
        
        # 租户管理员
        if user_attrs.is_tenant_admin:
            return True
        
        # 检查知识库角色权限
        kb_role = user_attrs.get_kb_role(str(kb_id))
        if not kb_role:
            return False
        
        allowed_actions = self.KB_ROLE_DOC_PERMISSIONS.get(kb_role, [])
        
        # owner 拥有所有权限
        if kb_role == "owner":
            return True
        
        return action in allowed_actions
    
    def _get_accessible_kb_ids(
        self,
        user_attrs: UserPermissionAttributes,
        tenant_id: UUID
    ) -> List[str]:
        """获取可访问的知识库ID列表"""
        return self.permission_service.get_accessible_kb_ids(
            user_attrs, str(tenant_id)
        )
    
    def _hard_delete_knowledge_base(self, kb: KnowledgeBase):
        """硬删除知识库（级联删除相关数据）"""
        # 删除文档切片
        from ..models.document import DocumentChunk
        self.db.query(DocumentChunk).filter(
            DocumentChunk.kb_id == kb.id
        ).delete(synchronize_session=False)
        
        # 删除文档
        self.db.query(Document).filter(
            Document.kb_id == kb.id
        ).delete(synchronize_session=False)
        
        # 删除权限
        self.db.query(Permission).filter(
            Permission.kb_id == str(kb.id)
        ).delete(synchronize_session=False)
        
        # 删除知识库
        self.db.delete(kb)
        self.db.commit()


class KnowledgeBaseFileHandler:
    """
    知识库文件处理器
    
    处理文档上传、存储和管理
    """
    
    # 支持的文件类型
    SUPPORTED_FILE_TYPES = {
        "pdf": ".pdf",
        "word": ".docx",
        "excel": ".xlsx",
        "ppt": ".pptx",
        "text": ".txt",
        "markdown": ".md",
        "html": ".html",
    }
    
    # 文件大小限制 (100MB)
    MAX_FILE_SIZE = 100 * 1024 * 1024
    
    def __init__(self, db: Session):
        self.db = db
    
    def validate_file(
        self,
        file_name: str,
        file_size: int,
        content_type: str
    ) -> Dict[str, Any]:
        """
        验证上传文件
        
        Args:
            file_name: 文件名
            file_size: 文件大小
            content_type: 文件类型
            
        Returns:
            Dict: 验证结果
            
        Raises:
            ValueError: 文件验证失败
        """
        # 检查文件大小
        if file_size > self.MAX_FILE_SIZE:
            raise ValueError(
                f"File size exceeds limit: {file_size} > {self.MAX_FILE_SIZE}"
            )
        
        # 检查文件扩展名
        file_ext = os.path.splitext(file_name)[1].lower()
        allowed_exts = list(self.SUPPORTED_FILE_TYPES.values())
        
        if file_ext not in allowed_exts:
            raise ValueError(
                f"Unsupported file type: {file_ext}. "
                f"Allowed: {', '.join(allowed_exts)}"
            )
        
        # 获取文件类型
        file_type = self._get_file_type(file_ext)
        
        return {
            "valid": True,
            "file_type": file_type,
            "file_ext": file_ext,
            "file_size": file_size,
        }
    
    def calculate_file_hash(
        self,
        file_content: bytes
    ) -> str:
        """
        计算文件哈希
        
        Args:
            file_content: 文件内容
            
        Returns:
            str: SHA256 哈希值
        """
        return hashlib.sha256(file_content).hexdigest()
    
    def generate_storage_path(
        self,
        tenant_id: str,
        kb_id: str,
        file_name: str
    ) -> str:
        """
        生成存储路径
        
        Args:
            tenant_id: 租户ID
            kb_id: 知识库ID
            file_name: 文件名
            
        Returns:
            str: 存储路径
        """
        # 使用时间戳和哈希生成唯一文件名
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        file_hash = self.calculate_file_hash(file_name.encode())[:8]
        safe_name = "".join(
            c for c in file_name 
            if c.isalnum() or c in ".-_"
        )
        
        return f"tenants/{tenant_id}/kb/{kb_id}/{timestamp}_{file_hash}_{safe_name}"
    
    def _get_file_type(self, file_ext: str) -> str:
        """根据扩展名获取文件类型"""
        type_map = {
            ".pdf": "pdf",
            ".docx": "word",
            ".doc": "word",
            ".xlsx": "excel",
            ".xls": "excel",
            ".pptx": "ppt",
            ".ppt": "ppt",
            ".txt": "text",
            ".md": "markdown",
            ".html": "html",
        }
        return type_map.get(file_ext, "unknown")
