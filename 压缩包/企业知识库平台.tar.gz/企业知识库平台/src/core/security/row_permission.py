"""
企业知识库平台 - 行级权限过滤器模块
RBAC + ABAC 混合权限模型实现

功能：
1. 用户属性提取
2. 行级权限条件构建
3. RAG检索时的权限过滤
"""

from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func
from src.models.user import User
from src.models.document import Document


class SecurityLevel(Enum):
    """安全等级枚举"""
    PUBLIC = "public"        # 公开
    INTERNAL = "internal"    # 内部
    CONFIDENTIAL = "confidential"  # 机密
    SECRET = "secret"        # 秘密
    
    @classmethod
    def get_level_value(cls, level: str) -> int:
        """获取等级数值，用于比较"""
        level_map = {
            cls.PUBLIC.value: 1,
            cls.INTERNAL.value: 2,
            cls.CONFIDENTIAL.value: 3,
            cls.SECRET.value: 4
        }
        return level_map.get(level, 1)


@dataclass
class UserAttributes:
    """
    用户属性 - ABAC模型的核心
    包含用户在ABAC决策时需要的所有属性
    """
    user_id: str
    tenant_id: str
    username: str
    department: Optional[str]
    departments: List[str]  # 可访问的部门列表
    projects: List[str]    # 可参与的项目
    security_level: str     # 用户的安全等级
    roles: List[str]       # 用户角色列表
    is_super_admin: bool   # 是否超级管理员
    is_tenant_admin: bool  # 是否租户管理员


class RowPermissionFilter:
    """
    行级权限过滤器
    
    实现RBAC+ABAC混合模型的行级权限控制
    在数据查询时自动注入权限过滤条件
    """
    
    # 知识库级别的角色权限
    KB_ROLES = {
        "owner": ["read", "write", "delete", "manage"],
        "editor": ["read", "write"],
        "viewer": ["read"],
        "guest": ["read_public"]
    }
    
    # 安全等级对应的权限
    SECURITY_LEVEL_HIERARCHY = {
        "public": 1,
        "internal": 2,
        "confidential": 3,
        "secret": 4
    }
    
    def __init__(self, db: Session):
        self.db = db
    
    def get_user_attributes(self, user: User) -> UserAttributes:
        """
        从用户对象提取ABAC属性
        
        Args:
            user: 用户模型对象
            
        Returns:
            UserAttributes: 用户属性对象
        """
        # 获取用户的部门列表
        departments = self._get_user_departments(user)
        
        # 获取用户的项目列表
        projects = self._get_user_projects(user)
        
        # 判断是否为管理员
        is_super_admin = user.is_super_admin if hasattr(user, 'is_super_admin') else False
        is_tenant_admin = user.is_tenant_admin if hasattr(user, 'is_tenant_admin') else False
        
        # 获取用户的角色
        roles = self._get_user_roles(user)
        
        return UserAttributes(
            user_id=str(user.id),
            tenant_id=str(user.tenant_id),
            username=user.username,
            department=user.department,
            departments=departments,
            projects=projects,
            security_level=user.security_level or "public",
            roles=roles,
            is_super_admin=is_super_admin,
            is_tenant_admin=is_tenant_admin
        )
    
    def _get_user_departments(self, user: User) -> List[str]:
        """获取用户可访问的部门列表"""
        # 如果用户有department字段，直接使用
        if user.department:
            return [user.department]
        # TODO: 从用户组关系中获取
        return []
    
    def _get_user_projects(self, user: User) -> List[str]:
        """获取用户参与的项目列表"""
        # TODO: 从用户-项目关联表中获取
        return []
    
    def _get_user_roles(self, user: User) -> List[str]:
        """获取用户在知识库中的角色"""
        # TODO: 从permission表中获取
        return []
    
    def build_document_filters(
        self,
        user_attrs: UserAttributes,
        kb_id: Optional[str] = None
    ) -> List[Any]:
        """
        构建文档查询的行级权限过滤条件
        
        实现逻辑：
        1. 超级管理员：不过滤，返回所有
        2. 租户管理员：只过滤租户
        3. 普通用户：按部门、项目、安全等级过滤
        
        Args:
            user_attrs: 用户属性
            kb_id: 知识库ID（可选）
            
        Returns:
            List[Any]: SQLAlchemy过滤条件列表
        """
        conditions = []
        
        # 超级管理员：不过滤
        if user_attrs.is_super_admin:
            return []
        
        # 1. 租户隔离（必须）
        conditions.append(Document.tenant_id == user_attrs.tenant_id)
        
        # 2. 知识库过滤（如果指定了）
        if kb_id:
            conditions.append(Document.kb_id == kb_id)
        
        # 3. 部门过滤（ABAC）
        if user_attrs.departments:
            conditions.append(
                or_(
                    Document.department.is_(None),
                    Document.department.in_(user_attrs.departments),
                    Document.department == ""
                )
            )
        
        # 4. 项目过滤（ABAC）
        if user_attrs.projects:
            conditions.append(
                or_(
                    Document.project.is_(None),
                    Document.project.in_(user_attrs.projects),
                    Document.project == ""
                )
            )
        
        # 5. 安全等级过滤（ABAC）- 用户只能访问低于或等于自己安全等级的文档
        user_level = self.SECURITY_LEVEL_HIERARCHY.get(
            user_attrs.security_level, 
            self.SECURITY_LEVEL_HIERARCHY["public"]
        )
        
        # 允许的安全等级
        allowed_levels = [
            level for level, value in self.SECURITY_LEVEL_HIERARCHY.items()
            if value <= user_level
        ]
        conditions.append(Document.security_level.in_(allowed_levels))
        
        return conditions
    
    def build_vector_search_filters(
        self,
        user_attrs: UserAttributes,
        kb_ids: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        构建向量数据库检索时的权限过滤条件
        
        用于Elasticsearch/Milvus等向量库的元数据过滤
        
        Args:
            user_attrs: 用户属性
            kb_ids: 知识库ID列表（可选）
            
        Returns:
            Dict: 向量库的过滤条件字典
        """
        # 超级管理员：不过滤
        if user_attrs.is_super_admin:
            return {}
        
        filters = {
            "bool": {
                "must": [
                    {"term": {"tenant_id": user_attrs.tenant_id}}
                ]
            }
        }
        
        # 知识库过滤
        if kb_ids:
            filters["bool"]["must"].append(
                {"terms": {"kb_id": kb_ids}}
            )
        
        # 部门过滤
        if user_attrs.departments:
            filters["bool"]["must"].append(
                {
                    "bool": {
                        "should": [
                            {"terms": {"department": user_attrs.departments}},
                            {"bool": {"must_not": {"exists": {"field": "department"}}}}
                        ],
                        "minimum_should_match": 1
                    }
                }
            )
        
        # 项目过滤
        if user_attrs.projects:
            filters["bool"]["must"].append(
                {
                    "bool": {
                        "should": [
                            {"terms": {"project": user_attrs.projects}},
                            {"bool": {"must_not": {"exists": {"field": "project"}}}}
                        ],
                        "minimum_should_match": 1
                    }
                }
            )
        
        # 安全等级过滤
        user_level = self.SECURITY_LEVEL_HIERARCHY.get(
            user_attrs.security_level,
            self.SECURITY_LEVEL_HIERARCHY["public"]
        )
        
        allowed_levels = [
            level for level, value in self.SECURITY_LEVEL_HIERARCHY.items()
            if value <= user_level
        ]
        filters["bool"]["must"].append(
            {"terms": {"security_level": allowed_levels}}
        )
        
        return filters
    
    def filter_documents(
        self,
        user: User,
        query,
        kb_id: Optional[str] = None
    ):
        """
        对文档查询应用行级权限过滤
        
        Args:
            user: 当前用户
            query: SQLAlchemy查询对象
            kb_id: 知识库ID（可选）
            
        Returns:
            过滤后的查询对象
        """
        user_attrs = self.get_user_attributes(user)
        conditions = self.build_document_filters(user_attrs, kb_id)
        
        if conditions:
            return query.filter(and_(*conditions))
        return query
    
    def check_document_access(
        self,
        user: User,
        document_id: str
    ) -> bool:
        """
        检查用户是否有权访问指定文档
        
        Args:
            user: 当前用户
            document_id: 文档ID
            
        Returns:
            bool: 是否有权限
        """
        user_attrs = self.get_user_attributes(user)
        
        # 超级管理员有所有权限
        if user_attrs.is_super_admin:
            return True
        
        # 获取文档
        doc = self.db.query(Document).filter(
            Document.id == document_id
        ).first()
        
        if not doc:
            return False
        
        # 检查租户
        if doc.tenant_id != user_attrs.tenant_id:
            return False
        
        # 检查部门
        if user_attrs.departments and doc.department:
            if doc.department not in user_attrs.departments:
                return False
        
        # 检查项目
        if user_attrs.projects and doc.project:
            if doc.project not in user_attrs.projects:
                return False
        
        # 检查安全等级
        doc_level = self.SECURITY_LEVEL_HIERARCHY.get(
            doc.security_level or "public",
            1
        )
        user_level = self.SECURITY_LEVEL_HIERARCHY.get(
            user_attrs.security_level,
            1
        )
        
        return doc_level <= user_level


class PermissionChecker:
    """
    权限检查器
    用于检查用户在特定资源上的操作权限
    """
    
    def __init__(self, db: Session):
        self.db = db
        self.row_filter = RowPermissionFilter(db)
    
    def check_kb_permission(
        self,
        user: User,
        kb_id: str,
        required_permission: str
    ) -> bool:
        """
        检查用户在知识库上的权限
        
        Args:
            user: 当前用户
            kb_id: 知识库ID
            required_permission: 所需权限 (read/write/delete/manage)
            
        Returns:
            bool: 是否有权限
        """
        user_attrs = self.row_filter.get_user_attributes(user)
        
        # 超级管理员拥有所有权限
        if user_attrs.is_super_admin:
            return True
        
        # 租户管理员在租户内有所有权限
        if user_attrs.is_tenant_admin:
            return True
        
        # TODO: 从permission表中检查具体权限
        # 暂时返回False，后续实现
        return False
    
    def check_kb_access(self, user: User, kb_id: str) -> bool:
        """检查用户是否有权访问知识库"""
        return self.check_kb_permission(user, kb_id, "read")
