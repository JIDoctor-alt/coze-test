"""
企业知识库平台 - 核心模块
"""
from .config.settings import settings

__all__ = ["settings"]
